"""units.py

 Methoden und Eigenschaften für das Rechnen mit Einheiten:

Klassen:

 + L1    [Längenmaße]
 + L2    [Flächenmaße]
 + L3    [Volumenmaße]
 + M     [Gewichtsmaße]
 + N     [Hilfsklasse für linksseitige Skalare]
 + T1    [Zeitmaße]
 + U(T1) [Uhrzeiten]
 + T2    [Zeitmaße hoch 2]
 + TT    [Temperaturen]
 + G     [zusammengesetzte Objekte]
 + B(G)  [Beschleunigung]
 + F1(G) [Kraft]
 + P(G)  [Leistung]
 + V(G)  [Geschwindigkeit]
 + W(G)  [Kraft]

globale Methoden:

__format_e(n)                  Formatiert eine Zahl in Scientific Notation
                               (intern).
__ueberschrift(text,z="-")     Dient zum Ausgeben von Überschriften bei der
                               Ausgabe (intern).
_repr_aus(s)                   Formatiert eine Zahl als String in Scientific
                               Notation oder mit Rundung (intern).
_str_aus(s)                    Formatiert eine Zahl als String in Scientific
                               Notation oder mit Rundung (intern).
allUnits(l)                    Listet alle berücksichtigten Einheiten (für L1,
                               L2, L3, M, T1, T2) auf.
au(l)                          Alias für allUnits(l)
alle(l,m=...)                  Listet alle Instanzen der Klassen (L1, L2, L3,
                               M, N, T1, T2, TT, G, U, V, B, F1, P, W) auf.
beispiel(e)                    Liefert Beispiele für die globalen Methoden des
                               Moduls.
clear(f)                       Löscht alle Instanzen einer Klasse.
dok(f)                         Liefert Informationen zu f (Methode oder Klasse).
getClassNames()                Liefert die Namen aller Klassen im Modul als
                               Liste.
gcn()                          Alias für getClassNames()
getFunctionNames()             Liefert die Namen aller globalen Methoden im Modul
                               als Liste.
gfn()                          Alias für getFunctionNames()
globalInfo(m)                  Gibt Informationen über Klassen, Methoden und
                               Variablen/Eigenschaften im Modul aus.
gi(m)                          Alias für globalInfo(m)
setVar(e=float, r=int, s=bool, t=char)  Ermöglicht das nachträgliche Setzen der
                               globalen Variablen eps, science, rndg, trennz.
sv(e=float, r=int, s=bool, t=char) Alias für
                               setVar(e=float, r=int, s=bool, t=char)
sign(s)                        Liefert das Vorzeichen eines numerischen
                               Werts/einer Instanz.
typ(o)                         Gibt den Typ von o aus.

frequenz(wert)                 Generiert eine G-Instanz mit dem Wert wert [Hz].
joule(wert)                    Generiert eine W-Instanz (Arbeit) mit dem Wert
                               wert [J].
kelvin(wert)                   Generiert eine TT-Instanz (Temperatur) mit dem
                               Wert wert [K].
kilogramm(wert)                Generiert eine M-Instanz (Gewicht) mit dem Wert
                               wert [kg].
meter(wert)                    Generiert eine L1-Instanz (Länge) mit dem Wert
                               wert [m].
meterS(wert)                   Generiert eine V-Instanz (Geschwindigkeit) mit
                               dem Wert wert [m/s].
mS(wert)                       Alias für meterS(wert)
meterS2(wert)                  Generiert eine B-Instanz (Beschleunigung) mit
                               dem Wert wert [m/s2].
mS2(wert)                      Alias für meterS2(wert)
meter2(wert)                   Generiert eine L2-Instanz (Fläche) mit dem Wert
                               wert [m2].
meter3(wert)                   Generiert eine L3-Instanz (Volumen) mit dem Wert
                               wert [m3].
newton(wert)                   Generiert eine F1-Instanz (Kraft) mit dem Wert
                               wert [N].
PS(wert)                       Generiert eine P-Instanz (Leistung) mit dem Wert
                               wert [PS].
sekunde(wert)                  Generiert eine T1-Instanz (Temperatur) mit dem
                               Wert wert [s].
sekunde2(wert)                 Generiert eine T2-Instanz mit dem Wert wert [s2].
watt(wert)                     Generiert eine P-Instanz (Leistung) mit dem Wert
                               wert [W].

Aliase:

au                             Alias für allUnits
gcn                            Alias für getClassNames
gfn                            Alias für getFunctionNames
gi                             Alias für globalInfo
mS                             Alias für meterS (Geschwindigkeit)
mS2                            Alias für meterS2 (Beschleuinigung)
sv                             Alias für setVar
 
Anwendungen:
 
druck(k, f)         Berechnet Druck (=Kraft/Fläche).     
gprocm3(m, vol)     Berechnet g/cm3.
impuls(m, v)        Berechnet Impuls (=Masse*Geschwindigkeit).
literpro100km(vol, s) Berechnet liter/(100km).
literprom2(l, f)    Berechnet liter/m2.
longweightsToM(l)   Erzeugt aus der Liste [lton, cwt, qu, stone, lb, oz, dr,
                    grain] eine M-Instanz (Gewicht).
mpros(s, t)         Berechnet m/s.
mgprodl(m, vol)     Berechnet mg/dl.
myfiToL1(l)         Erzeugt aus der Liste [mi, yd, ft, inch] eine L1-Instanz
                    (Länge).
Upromin(anz, t)     Berechnet Umdrehung/min.
ymdToT1(l)          Erzeugt aus der Liste [zy, zmo, zd, zh, zmi, zs] eine
                    T1-Instanz (Zeit)."""

# noch realisieren:
# - Maßeinheiten für F1, W, P
# - Klasse Stromstärke
# - Klasse Druck=kraft/Fläche
# - Klasse Impuls=Masse*Geschwindigkeit

# History
# 1.0.0: 2017-04-22: erste funktionierende Version
# 1.1.0: 2017-04-22: info() realisiert
# 1.2.0: 2017-04-22: L1Liste und alle() realisiert
# 1.3.0: 2017-04-22: xx realisiert
# 1.4.0: 2017-04-23: allUnits() realisiert
# 2.0.0: 2017-04-23: Class L2 realisiert
# 2.1.0: 2017-04-24: Beschreibung der Maßeinheiten (L1, L2, L3)
# 3.0.0: 2017-04-24: Class L3 realisiert
# 3.1.0: 2017-04-24: Scientific Notation kann eingeschaltet werden
# 3.2.0: 2017-04-24: globalInfo() realisiert
# 3.3.0: 2017-04-25: alle __doc__ überarbeitet
# 3.4.0: 2017-04-26: L --> L1 (und alles, was damit zusammenhängt) überarbeitet
# 3.5.0: 2017-04-27: neue globale Methoden: getFunctionNames, getClassNames
# 4.0.0: 2017-04-27: Class M realisiert
# 4.1.0: 2017-04-28: Methode setVar()
# 4.2.0: 2017-04-28: L2.__pow__ auch für **(1/2) und L3.__pow__ auch für **(1/3)
# 4.3.0: 2017-04-28: allUnits() überarbeitet
# 4.4.0: 2017-04-28: globalInfo() überarbeitet
# 4.5.0: 2017-04-30: neu: description() in allen Klassen
# 5.0.0: 2017-05-02: Class T1 realisiert
# 5.1.0: 2017-05-03: setVar() überarbeitet
# 5.2.0: 2017-05-03: Zahl der Fehlermeldungen verkleinert; fehlerhafte Operanden werden angezeigt
# 6.0.0: 2017-05-05: Klasse G realisiert
# 6.1.0: 2017-05-07: Klasse G überarbeitet
# 7.0.0: 2017-05-08: Klasse TT realisiert
# 7.1.0: 2017-05-09: science in allen x.info() berücksichtigt
# 7.2.0: 2017-05-09: __pow__ in allen Klassen überarbeitet
# 7.3.0: 2017-05-09: Klasse N überarbeitet
# 7.4.0: 2017-05-11: in allen Klassen: __neg__ bzw. __pos__
# 7.5.0: 2017-05-11: G erneut überarbeitet
# 7.6.0: 2017-05-12: rechtsseitige Multiplikation für alle Klassen überarbeitet
# 7.7.0: 2017-05-12: rechtsseitige Division für alle Klassen überarbeitet
# 7.8.0: 2017-05-13: to() in G
# 7.9.0: 2017-05-15: Trennzeichen zw. Maß und Maßeinheit in __str__ und __repr__ spezifizierbar
# 7.10.0: 2017-05-23: Einheiten generell als interne Variable gekennzeichnet, auch für andere interne Größen
# 7.11.0: 2017-05-29: Methode beispiel() für alle Klassen
# 7.12.0: 2017-06-01: globale Methoden: km_h(), literprom2(), mpros(), mi_h(), strecke()
# 7.13.0: 2017-06-06: globale Methoden m.toLongweights(), l.toMyfi(); noch einmal t.toYMD()
# 7.14.0: 2017-06-12: neue globale Methoden _str_aus(), _repr_aus(); Konzept mit science und rndg überarbeitet
# 7.15.0: 2017-06-24: externe Bezeichner für interne der Art _aa, ...; Anpassung bei Methoden und Dokumentation
# 7.16.0: 2017-06-26: globale Methoden: Upromin(), literpro100km(); Beispiele dazu
# 7.17.0: 2017-09-30: neue globale Methode sign(); Beispiel dazu
# 7.18.0: 2017-09-30: Methoden toMyfi(), toLongweights() und toYMD () jetzt auch für neg. Werte
# 7.19.0: 2017-10-02: neu: Einheit Karat (ct)
# 8.0.0: 2017-10-04: neu: Klasse U (Subklasse von T1)
# 8.1.0: 2017-10-08: überall überarbeitet: classInfo()
# 8.2.0: 2017-10-09: Klasse U: __mul__, __truediv__ und beispiel überarbeitet/neu
# 8.3.0: 2017-10-12: Addition und Subtraktion in G realisiert
# 8.4.0: 2017-10-18: neue Methode toU in T1
# 9.0.0: 2017-10-18: neue Klassen B, V, W, P und F1 (Unterklassen zu G)
# 9.1.0: 2017-10-20: Operationen (+, -, /, *) in B, V, W, P und F1
# 9.2.0: 2017-10-23: V, B, F1, W, P: linksseitige/rechtsseitige Multiplikation mit N
# 9.3.0: 2017-10-23: V, B, F1, W, P: rechtsseitige Division durch N, int, float
# 9.4.0: 2017-10-23: V, B, F1, W, P: __str__, __repr__
# 9.5.0: 2017-10-23: in allen Klassen: __abs__
# 9.6.0: 2017-10-24: beispiel für V, B, F1, W, P
# 9.7.0: 2017-10-25: weitere globale Beispiele
# 9.8.0: 2017-10-25: __truediv__ in allen Klassen für alle Typen erweitert
# 9.9.0: 2017-10-26: __mul__ in allen Klassen für alle Typen erweitert
# 9.10.0: 2018-04-28: _ im Namen globaler Methoden entfernt
# 9.11.0: 2018-04-29: in F1, B, V, W und P die Operatoren <, >, <=, >=, ==, != realisiert
# 9.12.0: 2018-05-01: in weiteren Methodennamen das _ entfernt
# 9.13.0: 2018-05-03: in allen Klassen: Eigenschaften jetzt separat bei classInfo aufrufbar
# 9.14.0: 2018-05-20: sign jetzt auch für Instanzen + Methode PS
# 9.15.0: 2018-07-17: neu: Methode frequenz; beispiel erweitert
# 9.16.0: 2018-07-26: neu: Methode clear

_version = "9.16.2"     # letzte Versionsnummer (nicht direkt bekannt, wenn das Modul importiert wird)
_date    = "2018-07-29" # Datum der letzte Änderung (nicht direkt bekannt, wenn das Modul importiert wird)
_modul   = "units.py"   # Name des Moduls
 
import re               # reguläre Ausdrücke
import math             # mathematische Ausdrücke

# ----------------------------------------------------------
# Listen, Dictionaries; Sammeln der entsprechenden Instanzen

BListe    = [] # Liste: alle B-Instanzen  (Beschleunigung)
F1Liste   = [] # Liste: alle F1-Instanzen (Kraft)
GListe    = [] # Liste: alle G-Instanzen  (zusammengesetzt)
L1Liste   = [] # Liste: alle L1-Instanzen (Länge)
L2Liste   = [] # Liste: alle L2-Instanzen (Fläche)
L3Liste   = [] # Liste: alle L3-Instanzen (Körper)
MListe    = [] # Liste: alle M-Instanzen  (Volumen)
NListe    = [] # Liste: alle N-Instanzen  (linksseitiger Skalar)
PListe    = [] # Liste: alle P-Instanzen  (Leistung)
T1Liste   = [] # Liste: alle T1-Instanzen (Zeit)
T2Liste   = [] # Liste: alle T2-Instanzen (Zeit hoch 2)
TTListe   = [] # Liste: alle TT-Instanzen (Temperatur)
UListe    = [] # Liste: alle U-Instanzen  (Uhrzeit)
VListe    = [] # Liste: alle V-Instanzen  (Geschwindigkeit)
WListe    = [] # Liste: alle W-Instanzen  (Arbeit)

# folgende Größen sind nicht unmittelbar bekannt, wenn das Modul importiert wird:
_gewichte = {} # Dictionary: Maße für M-Instanzen  (Gewichtsmaße)
_lengths1 = {} # Dictionary: Maße für L1-Instanzen (Längenmaße)
_lengths2 = {} # Dictionary: Maße für L2-Instanzen (Flächenmaße)
_lengths3 = {} # Dictionary: Maße für L3-Instanzen (Volumenmaße)
_time1    = {} # Dictionary: Maße für T1-Instanzen (Zeitmaße)
_time2    = {} # Dictionary: Maße für T2-Instanzen (Zeitmaße hoch 2)

_descript = {} # Dictionary: Beschreibung der Maßeinheiten

# ----------------------------------------------------------
# Einheiten für L1-Instanzen (Längen)
# folgende Größen sind nicht direkt bekannt, wenn das Modul importiert wird:
#
# Längen, metrische Maße
_aa  = "aa";  _lengths1[_aa]  =  1e-10  # Ångström
_am  = "am";  _lengths1[_am]  =  1e-18  # atto meter
_cm  = "cm";  _lengths1[_cm]  =  1e-2   # centi meter
_dm  = "dm";  _lengths1[_dm]  =  1e-1   # dezi meter
_fm  = "fm";  _lengths1[_fm]  =  1e-15  # femto meter
_Gm  = "Gm";  _lengths1[_Gm]  =  1e9    # Giga meter
_hkm = "hkm"; _lengths1[_hkm] =  1e5    # 100 kilo meter
_km  = "km";  _lengths1[_km]  =  1e3    # kilo meter
_m   = "m";   _lengths1[_m]   =  1      # meter
_mm  = "mm";  _lengths1[_mm]  =  1e-3   # milli meter
_Mm  = "Mm";  _lengths1[_Mm]  =  1e6    # Mega meter
_my  = "my";  _lengths1[_my]  =  1e-6   # mikro meter
_nm  = "nm";  _lengths1[_nm]  =  1e-9   # nano meter
_pm  = "pm";  _lengths1[_pm]  =  1e-12  # pico meter
_Pm  = "Pm";  _lengths1[_Pm]  =  1e15   # Peta meter
_Tm  = "Tm";  _lengths1[_Tm]  =  1e12   # Tera meter

# Längen, amerikanische Maße
_ft   = "ft";   _lengths1[_ft]   = 0.3048    # foot
_inch = "inch"; _lengths1[_inch] = 0.02540   # Inch (Zoll)
_mi   = "mi";   _lengths1[_mi]   = 1609.3440 # mile
_sm   = "sm";   _lengths1[_sm]   = 1852      # Seemeile
_yd   = "yd";   _lengths1[_yd]   = 0.9144    # yard
_Zoll = "Zoll"; _lengths1[_Zoll] = 0.02540   # Alias für Inch

# Längen, Druckermaße
_bp = "bp"; _lengths1[_bp] = _lengths1[_inch] / 72        # big point
_pt = "pt"; _lengths1[_pt] = _lengths1[_inch] / 72.26999  # point
_dd = "dd"; _lengths1[_dd] = _lengths1[_pt] * 1238 / 1157 # didot
_cc = "cc"; _lengths1[_cc] = _lengths1[_dd] / 12          # cicero
_pc = "pc"; _lengths1[_pc] = _lengths1[_pt] * 12          # pica
_sp = "sp"; _lengths1[_sp] = _lengths1[_pt] / 65536       # scaled point
_ze = "ze"; _lengths1[_ze] = _lengths1[_inch] / 6         # Zeiligkeit

# Längen, weitere
_ly = "ly"; _lengths1[_ly] = 9.460730472580800e15      # Lichtjahr (light year)

# ----------------------------------------------------------
# Einheiten für L2-Instanzen (Flächen)
# folgende Größen sind nicht direkt bekannt, wenn das Modul importiert wird:
#
# Flächen, metrische Maße
_aa2 = "aa2"; _lengths2[_aa2] =  1e-20  # (Aangström) hoch 2
_am2 = "am2"; _lengths2[_am2] =  1e-36  # (atto meter) hoch 2
_ar  = "ar";  _lengths2[_ar]  =  1e2    # ar
_cm2 = "cm2"; _lengths2[_cm2] =  1e-4   # (centi meter) hoch 2
_dm2 = "dm2"; _lengths2[_dm2] =  1e-2   # (dezi meter) hoch 2
_fm2 = "fm2"; _lengths2[_fm2] =  1e-30  # (femto meter) hoch 2
_Gm2 = "Gm2"; _lengths2[_Gm2] =  1e18   # (Giga meter) hoch 2
_ha  = "ha";  _lengths2[_ha]  =  1e4    # hektar
_km2 = "km2"; _lengths2[_km2] =  1e6    # (kilo meter) hoch 2
_m2  = "m2";  _lengths2[_m2]  =  1      # (meter) hoch 2
_Mm2 = "Mm2"; _lengths2[_Mm2] =  1e12   # (Mega meter) hoch 2
_mm2 = "mm2"; _lengths2[_mm2] =  1e-6   # (milli meter) hoch 2
_my2 = "my2"; _lengths2[_my2] =  1e-12  # (mikro meter) hoch 2
_nm2 = "nm2"; _lengths2[_nm2] =  1e-18  # (nano meter) hoch 2
_pm2 = "pm2"; _lengths2[_pm2] =  1e-24  # (pico meter) hoch 2
_Pm2 = "Pm2"; _lengths2[_Pm2] =  1e30   # (Peta meter) hoch 2
_Tm2 = "Tm2"; _lengths2[_Tm2] =  1e24   # (Tera meter) hoch 2

# Flächen, amerikanische Maße
_ft2   = "ft2";   _lengths2[_ft2]   =  0.3048 * 0.3048       # (foot) hoch 2
_inch2 = "inch2"; _lengths2[_inch2] =  0.0254 * 0.0254       # (Zoll) hoch 2
_mi2   = "mi2";   _lengths2[_mi2]   =  1609.3440 * 1609.3440 # (mile) hoch 2
_sm2   = "sm2";   _lengths2[_sm2]   =  1852 * 1852           # (Seemeile) hoch 2
_yd2   = "yd2";   _lengths2[_yd2]   =  0.9144 * 0.9144       # (yard) hoch 2

# ----------------------------------------------------------
# Einheiten für L3-Instanzen (Volumen-Maße)
# folgende Größen sind nicht direkt bekannt, wenn das Modul importiert wird:
#
# Volumen-Maße, metrische Maße
_cm3   = "cm3";   _lengths3[_cm3]   = 1e-6
_ccm   = "ccm";   _lengths3[_ccm]   = 1e-6
_dm3   = "dm3";   _lengths3[_dm3]   = 1e-3
_km3   = "km3";   _lengths3[_km3]   = 1e9
_m3    = "m3";    _lengths3[_m3]    = 1
_mm3   = "mm3";   _lengths3[_mm3]   = 1e-9

# Volumen-Maße, Liter-Abkömmlinge
_liter = "liter"; _lengths3[_liter] = 1e-3                     # Liter
_cl    = "cl";    _lengths3[_cl]    = 1e-5                     # Zentiliter: 1e-2 Liter
_dl    = "dl";    _lengths3[_dl]    = 1e-4                     # Deziliter: 1e-1 Liter
_fl    = "fl";    _lengths3[_fl]    = 1e-18                    # Femtoliter: 1e-15 Liter
_hl    = "hl";    _lengths3[_hl]    = 1e-1                     # Hektoliter: 1e2 Liter
_ml    = "ml";    _lengths3[_ml]    = 1e-6                     # Milliliter: 1e-3 Liter
_myl   = "myl";   _lengths3[_myl]   = 1e-9                     # Mikroliter: 1e-6 Liter
_nl    = "nl";    _lengths3[_nl]    = 1e-12                    # Nanoliter: 1e-9 Liter
_pl    = "pl";    _lengths3[_pl]    = 1e-15                    # Pikoliter: 1e-12 Liter

# Volumen-Maße, amerikanisch
_inch3 = "inch3"; _lengths3[_inch3] = _lengths1[_inch] * _lengths1[_inch] * _lengths1[_inch] # Cubic inch
_ft3   = "ft3";   _lengths3[_ft3]   = 1728 * _lengths3[_inch3] # Cubic foot
_gal   = "gal";   _lengths3[_gal]   = 231 * _lengths3[_inch3]  # US.liq.gal
_bbl   = "bbl";   _lengths3[_bbl]   = 42 * _lengths3[_gal]     # blue barrel (Erdöl)
_pint  = "pint";  _lengths3[_pint]  = _lengths3[_gal] / 8      # US.liq.pt
_yd3   = "yd3";   _lengths3[_yd3]   = 0.764554857984           # (yard) hoch 3

# ----------------------------------------------------------
# Einheiten für M-Instanzen (Gewichtsmaße)
# folgende Größen sind nicht direkt bekannt, wenn das Modul importiert wird:
#
# Gewichtsmaße, metrisch
_ct      = "ct";      _gewichte[_ct]      = 0.5e-3             # Karat (ct)
_Gt      = "Gt";      _gewichte[_Gt]      = 1e12               # Gigatonne (Gt)
_Mt      = "Mt";      _gewichte[_Mt]      = 1e9                # Megatonne (Mt)
_kt      = "kt";      _gewichte[_kt]      = 1e6                # Kilotonne (kt)
_t       = "t";       _gewichte[_t]       = 1e3                # Tonne (t)
_kg      = "kg";      _gewichte[_kg]      = 1                  # Kilogramm (kg)
_g       = "g";       _gewichte[_g]       = 1e-3               # Gramm (g)
_mg      = "mg";      _gewichte[_mg]      = 1e-6               # Milligramm (mg)
_myg     = "myg";     _gewichte[_myg]     = 1e-9               # Mikrogramm (µg)
_ng      = "ng";      _gewichte[_ng]      = 1e-12              # Nanogramm (ng)
_pg      = "pg";      _gewichte[_pg]      = 1e-15              # Pikogramm (pg)

# Gewichtsmaße, sonst
_pfd     = "pfd";     _gewichte[_pfd]     = 0.5                # Pfund
_dz      = "dz";      _gewichte[_dz]      = 100                # Doppelzentner
_Ztr     = "Ztr";     _gewichte[_Ztr]     = 50                 # Zentner

# amerikanische Gewichtsmaße
_grain   = "grain";   _gewichte[_grain]   = 0.00006479891      # grain; 1/7000 pound, Avoirdupois
_dr      = "dr";      _gewichte[_dr]      = 0.0017718451953125 # dram (Drachme); 1/16 ounce, Avoirdupois
_oz      = "oz";      _gewichte[_oz]      = 0.028349523125     # ounce (Unze); 1/16 pound, Avoirdupois
_lb      = "lb";      _gewichte[_lb]      = 0.453592370        # pound (Pfund); lb., pd., lbm., Avoirdupois

_stone   = "stone";   _gewichte[_stone]   = 6.35029318         # stone; 14 pound, long Avoirdupois
_qu      = "qu";      _gewichte[_qu]      = 12.700586360       # quarter (Viertelzentner); qu., qr. l.; 2 stone, long Avoirdupois
_cwt     = "cwt";     _gewichte[_cwt]     = 50.80234544        # long hundredweight (Zentner); 4 qu, long Avoirdupois
_lton    = "lton";    _gewichte[_lton]    = 1016.0469088       # long ton, T., to.; 20 hundredweight, long Avoirdupois

_quarter = "quarter"; _gewichte[_quarter] = 11.33980925        # quarter (Viertelzentner); 1/4 cwt, short Avoirdupois
_cental  = "cental";  _gewichte[_cental]  = 45.3592370         # short hundredweight (Zentner); 100 pound, short Avoirdupois
_ton     = "ton";     _gewichte[_ton]     = 907.18474          # short ton; 20 cwt, short Avoirdupois

# ----------------------------------------------------------
# Einheiten für T1-Instanzen (Zeitmaße)
# folgende Größen sind nicht direkt bekannt, wenn das Modul importiert wird:
#
_fs   = "fs";   _time1[_fs]   = 1e-15                # Femtosekunde; 1e-15 s
_ps   = "ps";   _time1[_ps]   = 1e-12                # Picosekunde; 1e-12 s
_ns   = "ns";   _time1[_ns]   = 1e-9                 # Nanosekunde; 1e-9 s
_mys  = "mys";  _time1[_mys]  = 1e-6                 # Mikrosekunde; 1e-6 s
_ms   = "ms";   _time1[_ms]   = 1e-3                 # Millisekunde; 1e-3 s
_s    = "s";    _time1[_s]    = 1                    # Sekunde; 1 s
_h    = "h";    _time1[_h]    = 3600                 # Stunde; 3600 s
_minute = "minute"; _time1[_minute] = 60             # Minute; 60 s
_d    = "d";    _time1[_d]    = 86400                # mittlerer Sonnentag; 86400 s
_week = "week"; _time1[_week] = 604800               # Woche, 7 d; 604800 s
_mon  = "mon";  _time1[_mon]  = 2592000              # gesetzlicher Monat (month), 30 d; 2592000 s
_y    = "y";    _time1[_y]    = 31536000             # Kalenderjahr (year), 365 d; 31536000 s

# ----------------------------------------------------------
# Einheiten für T2-Instanzen (Zeitmaße hoch 2)
# folgende Größen sind nicht direkt bekannt, wenn das Modul importiert wird:
#
_fs2   = "fs2";   _time2[_fs2]   = 1e-30             # (Femtosekunde) hoch 2; (1e-15 s) hoch 2
_ps2   = "ps2";   _time2[_ps2]   = 1e-24             # (Picosekunde) hoch 2; (1e-12 s) hoch 2
_ns2   = "ns2";   _time2[_ns2]   = 1e-18             # (Nanosekunde) hoch 2; (1e-9 s) hoch 2
_mys2  = "mys2";  _time2[_mys2]  = 1e-12             # (Mikrosekunde) hoch 2; (1e-6 s) hoch 2
_ms2   = "ms2";   _time2[_ms2]   = 1e-6              # (Millisekunde) hoch 2; (1e-3 s) hoch 2
_s2    = "s2";    _time2[_s2]    = 1                 # (Sekunde) hoch 2; (1 s) hoch 2
_h2    = "h2";    _time2[_h2]    = 3600*3600         # (Stunde) hoch 2; (3600 s) hoch 2
_minute2 = "minute2"; _time2[_minute2] = 60*60       # (Minute) hoch 2; (60 s) hoch 2
_d2    = "d2";    _time2[_d2]    = 86400*86400       # (Sonnentag) hoch 2; (86400 s) hoch 2
_week2 = "week2"; _time2[_week2] = 604800*604800     # (Woche) hoch 2; (604800 s) hoch 2
_mon2  = "mon2";  _time2[_mon2]  = 2592000*2592000   # (Monat) hoch 2; (2592000 s) hoch 2
_y2    = "y2";    _time2[_y2]    = 31536000*31536000 # (Kalenderjahr) hoch 2; (31536000 s) hoch 2

# ----------------------------------------------------------
# Einheiten für TT-Instanzen (Temperaturen)
# folgende Größen sind nicht direkt bekannt, wenn das Modul importiert wird:

_C    = "C"
_K    = "K"
_R    = "R"
_F    = "F"
_temp = [_C, _K, _F, _R]
_absK = 273.15

# ----------------------------------------------------------
# Kurzbeschreibungen der Maßeinheiten
# (werden in allUnits() verwendet)
# folgende Größen sind nicht direkt bekannt, wenn das Modul importiert wird:

_descript[_ft2]     = "amerik. Flächenmaß: (feet) hoch 2"
_descript[_mi2]     = "amerik. Flächenmaß: (mile) hoch 2"
_descript[_sm2]     = "amerik. Flächenmaß: (Seemeile) hoch 2"
_descript[_yd2]     = "amerik. Flächenmaß: (yard) hoch 2"
_descript[_inch2]   = "amerik. Flächenmaß: (Zoll) hoch 2"

_descript[_dr]      = """amerik. Gewichtsmaß, Avoirdupois: dram (Drachme);
                              1/16 ounce """
_descript[_grain]   = """amerik. Gewichtsmaß, Avoirdupois: grain;
                              1/7000 pound """
_descript[_oz]      = """amerik. Gewichtsmaß, Avoirdupois: ounce (Unze);
                              1/16 pound """
_descript[_lb]      = """amerik. Gewichtsmaß, Avoirdupois: pound (Pfund);
                              lb., pd., lbm. """

_descript[_cwt]     = """amerik. Gewichtsmaß, long Avoirdupois: long
                              hundredweight (Zentner); 4 qu"""
_descript[_lton]    = """amerik. Gewichtsmaß, long Avoirdupois: long ton,
                              T., to.; 20 cwt"""
_descript[_qu]      = """amerik. Gewichtsmaß, long Avoirdupois: quarter  
                              (Viertelzentner); qu., qr. l.; 2 stone"""
_descript[_stone]   = """amerik. Gewichtsmaß, long Avoirdupois: stone;
                              14 pound """

_descript[_quarter] = """amerik. Gewichtsmaß, short Avoirdupois: quarter
                              (Viertelzentner); 1/4 cwt """
_descript[_cental]  = """amerik. Gewichtsmaß, short Avoirdupois: short
                              hundredweight (Zentner); 100 pound """
_descript[_ton]     = """amerik. Gewichtsmaß, short Avoirdupois: short
                              ton; 20 quarter """

_descript[_bbl]     = """amerik. Volumen-Maß: blue barrel (Erdöl);
                              42 US.liq.gal"""
_descript[_ft3]     = "amerik. Volumen-Maß: cubic foot; 1728 cubic inch"
_descript[_inch3]   = "amerik. Volumen-Maß: cubic inch"
_descript[_gal]     = "amerik. Volumen-Maß: US.liq.gal; 231 cubic inch"
_descript[_pint]    = "amerik. Volumen-Maß: US.liq.pt; US.liq.gal / 8"
_descript[_yd3]     = "amerik. Volumen-Maß: cubic yard"

_descript[_Zoll]    = "amerik. Längenmaß: Alias für Inch"
_descript[_ft]      = "amerik. Längenmaß: Fuß (feet)"
_descript[_mi]      = "amerik. Längenmaß: Meile (mile)"
_descript[_sm]      = "amerik. Längenmaß: Seemeile"
_descript[_yd]      = "amerik. Längenmaß: yard"
_descript[_inch]    = "amerik. Längenmaß: Zoll (inch)"

_descript[_aa2]     = "Flächenmaß: (Aangström) hoch 2"
_descript[_am2]     = "Flächenmaß: (atto meter) hoch 2"
_descript[_cm2]     = "Flächenmaß: (centi meter) hoch 2"
_descript[_dm2]     = "Flächenmaß: (deci meter) hoch 2"
_descript[_fm2]     = "Flächenmaß: (femto meter) hoch 2"
_descript[_Gm2]     = "Flächenmaß: (Giga meter) hoch 2"
_descript[_km2]     = "Flächenmaß: (kilo meter) hoch 2"
_descript[_Mm2]     = "Flächenmaß: (Mega meter) hoch 2"
_descript[_m2]      = "Flächenmaß: (meter) hoch 2"
_descript[_my2]     = "Flächenmaß: (mikro meter) hoch 2"
_descript[_mm2]     = "Flächenmaß: (milli meter) hoch 2"
_descript[_nm2]     = "Flächenmaß: (nano meter) hoch 2"
_descript[_Pm2]     = "Flächenmaß: (Peta meter) hoch 2"
_descript[_pm2]     = "Flächenmaß: (pico meter) hoch 2"
_descript[_Tm2]     = "Flächenmaß: (Tera meter) hoch 2"
_descript[_ar]      = "Flächenmaß: ar"
_descript[_ha]      = "Flächenmaß: hektar"

_descript[_ct]      = "Gewichtsmaß: Karat (ct)"
_descript[_dz]      = "Gewichtsmaß: Doppelzentner (dz)"
_descript[_Gt]      = "Gewichtsmaß: Gigatonne (Gt) "
_descript[_g]       = "Gewichtsmaß: Gramm (g) "
_descript[_kg]      = "Gewichtsmaß: Kilogramm (kg)"
_descript[_kt]      = "Gewichtsmaß: Kilotonne (kt) "
_descript[_Mt]      = "Gewichtsmaß: Megatonne (Mt) "
_descript[_myg]     = "Gewichtsmaß: Mikrogramm (µg) "
_descript[_mg]      = "Gewichtsmaß: Milligramm (mg) "
_descript[_ng]      = "Gewichtsmaß: Nanogramm (ng) "
_descript[_pfd]     = "Gewichtsmaß: Pfund (pfd)"
_descript[_pg]      = "Gewichtsmaß: Pikogramm (pg) "
_descript[_t]       = "Gewichtsmaß: Tonne (t) "
_descript[_Ztr]     = "Gewichtsmaß: Zentner (Ztr)"

_descript[_cl]      = "Volumen-Maß: Zentiliter (cl): 1e-2 Liter"
_descript[_cm3]     = "Volumen-Maß: (cm) hoch 3"
_descript[_ccm]     = "Volumen-Maß: (cm) hoch 3"
_descript[_dl]      = "Volumen-Maß: Deziliter (dl): 1e-1 Liter"
_descript[_dm3]     = "Volumen-Maß: (dm) hoch 3"
_descript[_fl]      = "Volumen-Maß: Femtoliter (fl): 1e-15 Liter"
_descript[_hl]      = "Volumen-Maß: Hektoliter (hl): 100 liter"
_descript[_km3]     = "Volumen-Maß: (km) hoch 3"
_descript[_liter]   = "Volumen-Maß: 1 dm3"
_descript[_m3]      = "Volumen-Maß: m hoch 3"
_descript[_ml]      = "Volumen-Maß: Milliliter (ml): 1e-3 Liter"
_descript[_mm3]     = "Volumen-Maß: (mm) hoch 3"
_descript[_myl]     = "Volumen-Maß: Mikroliter (myl): 1e-6 Liter"
_descript[_nl]      = "Volumen-Maß: Nanoliter (nl): 1e-9 Liter"
_descript[_pl]      = "Volumen-Maß: Pikoliter (pl): 1e-12 Liter"

_descript[_bp]      = "Längenmaß im Druckergewerbe: big point; 72 bp/in"
_descript[_cc]      = """Längenmaß im Druckergewerbe: cicero;
                              1 cc   = 12 dd"""
_descript[_dd]      = """Längenmaß im Druckergewerbe: Didot;
                              1157 dd   = 1238 pt"""
_descript[_pc]      = "Längenmaß im Druckergewerbe: Pica; 12 pt/pc"
_descript[_pt]      = "Längenmaß im Druckergewerbe: Point (point)"
_descript[_sp]      = """Längenmaß im Druckergewerbe: scaled point;
                              65536 sp/pt"""
_descript[_ze]      = "Längenmaß im Druckergewerbe: Zeiligkeit"

_descript[_aa]      = "Längenmaß: Ångström"
_descript[_am]      = "Längenmaß: atto meter"
_descript[_dm]      = "Längenmaß: Dezimeter (deci meter)"
_descript[_fm]      = "Längenmaß: femto meter"
_descript[_Gm]      = "Längenmaß: Giga meter"
_descript[_hkm]     = "Längenmaß: 100 kilometer"
_descript[_km]      = "Längenmaß: kilometer (kilo meter)"
_descript[_ly]      = "Längenmaß: Lichtjahr (light year)"
_descript[_Mm]      = "Längenmaß: Mega meter"
_descript[_m]       = "Längenmaß: Meter (meter)"
_descript[_my]      = "Längenmaß: mikro meter"
_descript[_mm]      = "Längenmaß: Millimeter (milli meter)"
_descript[_nm]      = "Längenmaß: nano meter"
_descript[_Pm]      = "Längenmaß: Peta meter"
_descript[_pm]      = "Längenmaß: pico meter"
_descript[_Tm]      = "Längenmaß: Tera meter"
_descript[_cm]      = "Längenmaß: Zentimeter (centi meter)"

_descript[_d]       = "Zeitmaß: mittlerer Sonnentag; 86400 s"
_descript[_fs]      = "Zeitmaß: Femtosekunde; 1e-15 s"
_descript[_h]       = "Zeitmaß: Stunde; 3600 s"
_descript[_minute]  = "Zeitmaß: Minute; 60 s"
_descript[_mon]     = "Zeitmaß: gesetzlicher Monat (month), 30 d; 2592000 s"
_descript[_ms]      = "Zeitmaß: Millisekunde; 1e-3 s"
_descript[_mys]     = "Zeitmaß: Mikrosekunde; 1e-6 s"
_descript[_ns]      = "Zeitmaß: Nanosekunde; 1e-9 s"
_descript[_ps]      = "Zeitmaß: Picosekunde; 1e-12 s"
_descript[_s]       = "Zeitmaß: Sekunde; 1 s"
_descript[_week]    = "Zeitmaß: Woche, 7 d; 604800 s"
_descript[_y]       = "Zeitmaß: Kalenderjahr (year), 365 d; 31536000 s"

_descript[_d2]      = """Zeitmaß hoch 2: (Sonnentag) hoch 2;
                              (86400 s) hoch 2"""
_descript[_fs2]     = """Zeitmaß hoch 2: (Femtosekunde) hoch 2;
                              (1e-15 s) hoch 2"""
_descript[_h2]      = "Zeitmaß hoch 2: (Stunde) hoch 2; (3600 s) hoch 2"
_descript[_minute2] = "Zeitmaß hoch 2: (Minute) hoch 2; (60 s) hoch 2"
_descript[_mon2]    = """Zeitmaß hoch 2: (Monat) hoch 2;
                              (2592000 s) hoch 2"""
_descript[_ms2]     = """Zeitmaß hoch 2: (Millisekunde) hoch 2;
                              (1e-3 s) hoch 2"""
_descript[_mys2]    = """Zeitmaß hoch 2: (Mikrosekunde) hoch 2;
                              (1e-6 s) hoch 2"""
_descript[_ns2]     = """Zeitmaß hoch 2: (Nanosekunde) hoch 2;
                              (1e-9 s) hoch 2"""
_descript[_ps2]     = """Zeitmaß hoch 2: (Picosekunde) hoch 2;
                              (1e-12 s) hoch 2"""
_descript[_s2]      = "Zeitmaß hoch 2: (Sekunde) hoch 2; (1 s) hoch 2"
_descript[_week2]   = "Zeitmaß hoch 2: (Woche) hoch 2; (604800 s) hoch 2"
_descript[_y2]      = """Zeitmaß hoch 2: (Kalenderjahr) hoch 2;
                              (31536000 s) hoch 2"""

_descript[_C]       = "Temperaturmaß: Celsius"
_descript[_F]       = "Temperaturmaß: Fahrenheit"
_descript[_K]       = "Temperaturmaß: Kelvin"
_descript[_R]       = "Temperaturmaß: Reaumur"

# ----------------------------------------------------------
# Hilfsgrößen und Konfigurationsvariablen
# Hilfsgrößen (vereinfachen manchen Methodenaufruf)

kurz      = "kurz"
lang      = "lang"
mul       = "*"
div       = "/"
alles     = "A"
Kopf      = "H" # Head
Variable  = "V"
Klassen   = "K"
Methoden  = "M"
Einheiten = "E"
Komma     = ","
leer      = " "

# ----------------------------------------------------------
# Konfigurationsvariablen
# globale Größen: können mittels der Methode setVar() nachträglich geändert werden

eps       = 1e-16  # für Vergleiche auf Gleichheit: ganz klein
rndg      = 4      # für Rundung: Nachkommastellen
science   = False  # Darstellung von Instanzen in Science Notation
trennz    = leer   # Trennzeichen zw. Maß und Maßeinheit in __str__ und __repr__

# ----------------------------------------------------------
_q        = '-' * 40 + '\n'   # Querlinie
_qqq      = " " * 4 + "===> " 

# ----------------------------------------------------------
dmodule   = []               # Liste: nimmt dir() auf
Lclass    = []               # Liste: nimmt die Namen aller Klassen auf
Lfunction = []               # Liste: nimmt die Namen aller globalen Methoden auf

# ----------------------------------------------------------
# vorgefertigte Konvertierungen [können bei g.to() verwendet werden]
# folgende Größen sind nicht direkt bekannt, wenn das Modul importiert wird:

_kmh      = {_m:_km, _s:_h}          # m --> km, s -->  h
_mks      = {_m:_m,  _s:_s,  _kg:_kg}# m --> m,  s -->  s, kg --> kg
_cgs      = {_m:_cm, _kg:_g, _s:_s}  # m --> cm, kg --> g, s --> s
_mph      = {_m:_mi, _s:_h}          # m --> mi, s -->  h

# ----------------------------------------------------------
# Fehlermeldungen
# folgende Größen sind nicht direkt bekannt, wenn das Modul importiert wird:

_fehler2  = "Unit ist hier nicht bekannt/zulässig: "   # ValueError
_fehler3  = "Operand hat keinen zulässigen Typ: "      # TypeError
_fehler4  = "Operand hat den Wert Null: "              # ValueError
_fehler5  = "Parameter ist unzulässig: "               # ValueError
_fehler6  = "Parameter hat unzulässigen Wert: "        # ValueError
_fehler7  = "Einheiten nicht kompatibel: "             # ValueError
_fehler9  = "Operator ist nicht zulässig: "            # ValueError

# =========================================================
# Methoden

# ----------------------------------------------------------
# Standardmethoden (die bei globalInfo() ausgeblendet werden):
# die folgende Größe _standard ist nicht direkt bekannt, wenn das Modul importiert wird:

_standard = ["__class__", "__delattr__", "__dict__", "__dir__", "__file__", "__format__", "__getattribute__", "__hash__",
            "__init_subclass__", "__module__", "__reduce__", "__reduce_ex__", "__setattr__", "__subclasshook__", "__weakref__",
            "__doc__", "__sizeof__", "__new__"]

# globale Methoden
# ----------------------------------------------------------
def __format_e(n):
    """
    Formatiert eine Zahl in Scientific Notation (intern).

    Aufruf: __format_e(n)
    n: zu formatierende Zahl"""
    
    # lokale Hilfsvariable: a
    
    a = '%E' % n
    return a.split('E')[0].rstrip('0').rstrip('.') + 'e' + a.split('E')[1]

# ----------------------------------------------------------
def __ueberschrift(text, z="-"):
    """
    Dient zum Ausgeben von Überschriften bei der Ausgabe (intern).

    Aufruf: Aufruf: __ueberschrift(text,z="-")
    text: auszugebender Text
    z   : Zeichen zum Untertreichen    """
    
    print(str(text))
    print(z*len(text))
##    print(z*len(text) + "\n")

# ----------------------------------------------------------
def _repr_aus(s):
    """
    Formatiert eine Zahl als String in Scientific Notation oder mit Rundung
    (intern).

    Aufruf: _repr_aus(s)
    s: zu formatierende Zahl"""
    
    global rndg, science
    
    if science:
        return __format_e(s)
    else:
        return repr(round(s, rndg))

# ----------------------------------------------------------
def _str_aus(s):
    """
    Formatiert eine Zahl als String in Scientific Notation oder mit Rundung
    (intern).

    Aufruf: _str_aus(s)
    s: zu formatierende Zahl"""
    
    global rndg, science
    
    if science:
        return __format_e(s)
    else:
        return str(round(s, rndg))

# ----------------------------------------------------------
def allUnits(l="A"):
    """
    Listet alle berücksichtigten Einheiten (für L1, L2, L3, M, T1, T2) auf.

    Aufruf: allUnits(l) oder au(l)
    mögliche Angaben für l:
    - "A" [Voreinstellung], "L1", "L2", "L3", "M", "T1", "T2"."""
    
    # lokale Hilfsvariable: rr, f, s, ss
    
    rndg = 16
    rr   = "  "
    if (l in ["L1","A"]) :
        print("Längenmaße (in m): " + str(len(_lengths1)) + " Einträge")
        for f in sorted(_lengths1, key=str.lower):
            s  = _lengths1[f]
            ss = _str_aus(s)
            print(rr, f.ljust(7), str(ss).ljust(18), _descript[f])
        print(_q)
    if (l in ["L2", "A"]) :
        print("Flächenmaße (in m2): " + str(len(_lengths2)) + " Einträge")
        for f in sorted(_lengths2, key=str.lower):
            s  = _lengths2[f]
            ss = _str_aus(s)
            print(rr, f.ljust(7), str(ss).ljust(18), _descript[f])
        print(_q)
    if (l in ["L3", "A"]) :
        print("Volumenmaße (in m3): " + str(len(_lengths3)) + " Einträge")
        for f in sorted(_lengths3, key=str.lower):
            s  = _lengths3[f]
            ss = _str_aus(s)
            print(rr, f.ljust(7), str(ss).ljust(18), _descript[f])
        print(_q)
    if (l in ["M", "A"]) :
        print("Gewichtsmaße (in kg): " + str(len(_gewichte)) + " Einträge")
        for f in sorted(_gewichte, key=str.lower):
            s  = _gewichte[f]
            ss = _str_aus(s)
            print(rr, f.ljust(7), str(ss).ljust(18), _descript[f])
        print(_q)
    if (l in ["T1", "A"]) :
        print("Zeitmaße (in s): " + str(len(_time1)) + " Einträge")
        for f in sorted(_time1, key=str.lower):
            s  = _time1[f]
            ss = _str_aus(s)
            print(rr, f.ljust(7), str(ss).ljust(18), _descript[f])
        print(_q)
    if (l in ["T2", "A"]) :
        print("Zeitmaße hoch 2 (in s2): " + str(len(_time2)) + " Einträge")
        for f in sorted(_time2, key=str.lower):
            s  = _time2[f]
            ss = _str_aus(s)
            print(rr, f.ljust(7), str(ss).ljust(18), _descript[f])
        print(_q)

# ----------------------------------------------------------
def alle(l=alles, m=lang):
    """
    Listet alle Instanzen der Klassen (für L1, L2, L3, M, N, T1, T2, TT, G, U,
    V, B, F1, P, W) auf.

    Aufruf: alle(l,m=...)
    mögliche Angaben für l:
    - "A"/alles [Voreinstellung], "L1", "L2", "L3", "M", "N", "T1", "T2", "TT",
      "G", "U", "V", "B", "P", "W", "F1"
    mögliche Angaben für m:
    - lang (ausführlich) [Voreinstellung],
    - kurz (nur Name)
    - zahl (nur Anzahl)"""
    
    # lokale Hilfsvariable: ll, f, lll
    
    ll  = []
    lll = 0
    if l == "G" : ll = GListe; lll = len(ll)
    if l == "L1": ll = L1Liste; lll = len(ll)
    if l == "L" : ll = L1Liste; lll = len(ll)
    if l == "L2": ll = L2Liste; lll = len(ll)
    if l == "L3": ll = L3Liste; lll = len(ll)
    if l == "M" : ll = MListe; lll = len(ll)
    if l == "N" : ll = NListe; lll = len(ll)
    if l == "T1": ll = T1Liste; lll = len(ll)
    if l == "T" : ll = T1Liste; lll = len(ll)
    if l == "T2": ll = T2Liste; lll = len(ll)
    if l == "TT": ll = TTListe; lll = len(ll)
    if l == "U" : ll = UListe; lll = len(ll)
    if l == "V" : ll = VListe; lll = len(ll)
    if l == "B" : ll = BListe; lll = len(ll)
    if l == "P" : ll = PListe; lll = len(ll)
    if l == "F1": ll = F1Liste; lll = len(ll)
    if l == "W" : ll = WListe; lll = len(ll)
    if l == "A":
        for f in GListe : ll.append(f); lll += 1
        for f in L1Liste: ll.append(f); lll += 1
        for f in L2Liste: ll.append(f); lll += 1
        for f in L3Liste: ll.append(f); lll += 1
        for f in MListe : ll.append(f); lll += 1
        for f in NListe : ll.append(f); lll += 1
        for f in T1Liste: ll.append(f); lll += 1
        for f in T2Liste: ll.append(f); lll += 1
        for f in TTListe: ll.append(f); lll += 1
        for f in UListe : ll.append(f); lll += 1
        for f in VListe : ll.append(f); lll += 1
        for f in BListe : ll.append(f); lll += 1
        for f in PListe : ll.append(f); lll += 1
        for f in WListe : ll.append(f); lll += 1
        for f in F1Liste: ll.append(f); lll += 1
    if m == "zahl":
        return lll
    else:
        print(lll, " Element(e):\n")
        for f in ll:
            if m == "lang":
                f.info()
            elif m == "kurz":
                print(f.name)
            else:
                pass

# ----------------------------------------------------------
def beispiel(e=""):
    """
    Liefert Beispiele für die globalen Methoden des Moduls.

    Aufruf: beispiel(e)
    für e kann "allUnits", "alle", "au", "gcn", "getClassNames", "getFunctionNames",
    "gfn", "gi", "globalInfo", "km_h", "literprom2", "longweightsToM", "mpros",
    "mgprodl", "myfiToL1", "setVar", "strecke", "sv", "typ", "ymdToT1", "frequenz", 
    "meter", "meter2", "meter3", "sekunde", "sekunde2", "kilogramm", "kelvin",
    "meterS", "meterS2", "newton", "joule", "watt" oder die leere Zeichenkette
    [Voreinstellung] angegeben werden"""
    
    print("""
    n1=N(-3);l11=L1(2,m);l21=L2(3,km2);l31=L3(6,hl);t11=T(5,s);t12=T1(10,minute);
    t21=T2(6,h2);m1=M(2.5,kg);tt1=TT(8,C);g1=G(l11,div,t11); v1=L(700,m)/T(35,s)""")
    n1=N(-3);l11=L1(2,_m);l21=L2(3,_km2);l31=L3(6,_hl);t11=T(5,_s);t12=T1(10,_minute);t21=T2(6,_h2);m1=M(2.5,_kg);
    tt1=TT(8,_C);g1=G(l11,div,t11); v1=L(700,_m)/T(35,_s)
    
    if e in ["","alle"]:                                            # alle
        print("alle",alle.__doc__)
        print(_qqq+" alle('L1',kurz) --->");alle("L1",kurz)
        print(_qqq+" alle('M') --->");alle("M")
    if e in ["","allUnits", "au"]:                                  # allUnits
        print("allUnits",allUnits.__doc__)
        print(_qqq+" allUnits('L1') --->"); allUnits('L1')
        print(_qqq+" allUnits('T1') --->"); allUnits('T1')
    if e in ["","frequenz"]:                                        # frequenz
        print("frequenz",frequenz.__doc__)
        print(_qqq+" frequenz(100) --->"); print(frequenz(100))
        print(_qqq+" nn=3000;frequenz(nn) --->"); nn=3000;print(frequenz(nn))
    if e in ["","getClassNames", "gcn"]:                            # getClassNames
        print("getClassNames",getClassNames.__doc__)
        print(_qqq+" getClassNames --->", getClassNames())
    if e in ["","getFunctionNames", "gfn"]:                         # getFunctionNames
        print("getFunctionNames",getFunctionNames.__doc__)
        print(_qqq+" getFunctionNames --->", getFunctionNames())
    if e in ["","globalInfo", "gi"]:                                # globalInfo
        print("globalInfo",globalInfo.__doc__)
        print(_qqq+" globalInfo('V') --->"); globalInfo('V')
        print(_qqq+" globalInfo('K') --->"); globalInfo('K')
    if e in ["","gprocm3"]:                                         # gprocm3
        print("gprocm3",gprocm3.__doc__)
        print(_qqq+" m=M(1.007,kg);vol=L3(0.995,liter);gprocm3(m,vol) --->"); m=M(1.007,_kg);vol=L3(0.995,_liter);print(gprocm3(m,vol))
    if e in ["","joule"]:                                           # joule
        print("joule",joule.__doc__)
        print(_qqq+" joule("+str(-20)+") -->", joule(-20))
    if e in ["","kelvin", "K"]:                                     # kelvin
        print("kelvin",kelvin.__doc__)
        print(_qqq+" kelvin("+str(20)+") -->", kelvin(20))
    if e in ["","kilogramm", "kg"]:                                 # kilogramm
        print("kilogramm",kilogramm.__doc__)
        print(_qqq+" kilogramm("+str(-20)+") -->", kilogramm(-20))
    if e in ["","literpro100km"]:                                   # literpro100km
        print("literpro100km",literpro100km.__doc__)
        print(_qqq+" v=L3(30.8,liter);l=L(750,km);literpro100km(v,l) --->"); v=L3(30.8,_liter);l=L(750,_km);print(literpro100km(v,l))
    if e in ["","literprom2"]:                                      # literprom2
        print("literprom2",literprom2.__doc__)
        print(_qqq+" literprom2(L3(100,hl),L2(2,m2)) --->", literprom2(L3(100,_hl),L2(2,_m2)))
    if e in ["","longweightsToM"]:                                  # longweightsToM
        print("longweightsToM",longweightsToM.__doc__)
        print(_qqq+" l=[1,0,1,0,1,0,1,0];longweightsToM(l).to(lton) --->");l=[1,0,1,0,1,0,1,0];print(longweightsToM(l).to(_lton))
    if e in ["","meter", "m"]:                                      # meter
        print("meter",meter.__doc__)
        print(_qqq+" meter("+str(-20)+") -->", meter(-20))
    if e in ["","meter2", "m2"]:                                    # meter2
        print("meter2",meter2.__doc__)
        print(_qqq+" meter2("+str(-20)+") -->", meter2(-20))
    if e in ["","meter3", "m3"]:                                    # meter3
        print("meter3",meter3.__doc__)
        print(_qqq+" meter3("+str(-20)+") -->", meter3(-20))
    if e in ["","meterS"]:                                          # meterS
        print("meterS",meterS.__doc__)
        print(_qqq+" meterS("+str(-20)+") -->", meterS(-20))
    if e in ["","meterS2"]:                                         # meterS2
        print("meterS2",meterS2.__doc__)
        print(_qqq+" meterS2("+str(-20)+") -->", meterS2(-20))
    if e in ["","mgprodl"]:                                         # mgprodl
        print("mgprodl",mgprodl.__doc__)
        print(_qqq+" mgprodl(m1,l31) --->", mgprodl(m1,l31))
    if e in ["","mpros"]:                                           # mpros
        print("mpros",mpros.__doc__)
        print(_qqq+" mpros(L(25,km),T(0.2,h)) --->", mpros(L(25,_km),T(0.2,_h)))
    if e in ["","myfiToL1"]:                                        # myfiToL1
        print("myfiToL1",myfiToL1.__doc__)
        print(_qqq+" l=[1,1,1,1];myfiToL1(l) --->"); l=[1,1,1,1];print(myfiToL1(l))
    if e in ["","newton"]:                                          # newton
        print("newton",newton.__doc__)
        print(_qqq+" newton("+str(-20)+") -->", newton(-20))
    if e in ["","sekunde", "s"]:                                    # sekunde
        print("sekunde",sekunde.__doc__)
        print(_qqq+" sekunde("+str(-20)+") -->", sekunde(-20))
    if e in ["","sekunde2", "s2"]:                                  # sekunde2
        print("sekunde2",sekunde2.__doc__)
        print(_qqq+" sekunde2("+str(-20)+") -->", sekunde2(-20))
    if e in ["","setVar", "sv"]:                                    # setVar
        print("setVar",setVar.__doc__)
        print(_qqq+" setVar(s=False,r=8);globalInfo('V') --->");setVar(s=False,r=8);globalInfo('V')
    if e in ["","sign"]:                                            # sign
        print("sign",sign.__doc__)
        print(_qqq+" sign(-1.1);sign(0);sign(2.5) --->", sign(-1.1), sign(0), sign(2.5))
    if e in ["","typ"]:                                             # typ
        print("typ",typ.__doc__)
        print(_qqq+" typ("+str(m1)+") -->", typ(m1))
        print(_qqq+" typ("+str(n1)+") -->", typ(n1))
    if e in ["","Upromin"]:                                         # Upromin
        print("Upromin",Upromin.__doc__)
        print(_qqq+" anz=3500;t=T1(200,s);Upromin(anz,t) --->"); anz=3500;t=T1(200,_s);print(Upromin(anz,t))
    if e in ["","watt"]:                                            # watt
        print("watt",watt.__doc__)
        print(_qqq+" watt("+str(-20)+") -->", watt(-20))
    if e in ["","ymdToT1"]:                                         # ymdToT1
        print("ymdToT1",ymdToT1.__doc__)
        print(_qqq+" l=[1,1,1,1,1,1];ymdToT1(l) --->"); l=[1,1,1,1,1,1];print(ymdToT1(l))

# ----------------------------------------------------------
def clear(f=""):
    """Löscht alle Instanzen einer Klasse.

    Aufruf: clear(f)
    mögliche Angaben für f:
    '' (alle), 'A' (alle), 'B', 'F1', 'G', 'L', 'L1', 'L2', 'L3', 'M',
    'N', 'P', 'T', 'T1', 'T2', 'TT', 'U', 'V', 'W'"""
    
    global L1Liste, L2Liste, L3Liste, MListe, T1Liste, T2Liste, TTListe, NListe, GListe
    global UListe, VListe, BListe, PListe, WListe, F1Liste
    
    # lokale Hilfsvariable: lll
    
    lll = 0
    if f in ["", "A", "L1", "L"]: lll += len(L1Liste); del L1Liste; L1Liste=[]
    if f in ["", "A", "L2"]: lll += len(L2Liste);      del L2Liste; L2Liste=[]
    if f in ["", "A", "L3"]: lll += len(L3Liste);      del L3Liste; L3Liste=[]
    if f in ["", "A", "M"] : lll += len(MListe);       del MListe; MListe=[]
    if f in ["", "A", "T1", "T"]: lll += len(T1Liste); del T1Liste; T1Liste=[]
    if f in ["", "A", "T2"]: lll += len(T2Liste);      del T2Liste; T2Liste=[]
    if f in ["", "A", "TT"]: lll += len(TTListe);      del TTListe; TTListe=[]
    if f in ["", "A", "N"] : lll += len(NListe);       del NListe; NListe=[]
    if f in ["", "A", "G"] : lll += len(GListe);       del GListe; GListe=[]
    if f in ["", "A", "U"] : lll += len(UListe);       del UListe; UListe=[]
    if f in ["", "A", "V"] : lll += len(VListe);       del VListe; VListe=[]
    if f in ["", "A", "B"] : lll += len(BListe);       del BListe; BListe=[]
    if f in ["", "A", "P"] : lll += len(PListe);       del PListe; PListe=[]
    if f in ["", "A", "W"] : lll += len(WListe);       del WListe; WListe=[]
    if f in ["", "A", "F1"]: lll += len(F1Liste);      del F1Liste; F1Liste=[]
    return lll

# ----------------------------------------------------------
def dok(f=""):
    """
    Liefert Informationen zu f (Methode oder Klasse).

    Aufruf: dok(f)
    l : String"""

    if f == "":
        print(__doc__)
    else:
        print(f, eval(f +".__doc__"))

# ----------------------------------------------------------
def frequenz(wert):
    """Generiert eine G-Instanz mit dem Wert wert/T1.

    Aufruf: frequenz(wert)
    wert: int/float/N"""

    return N(wert) / T1(1,s)
    
# ----------------------------------------------------------
def getClassNames():
    """
    Liefert die Namen aller Klassen im Modul.

    Aufruf: getClassNames() oder gcn()"""
    
    # lokale Hilfsvariable: ll, s1, sm1, sm2, sm3, f, s
    
    ll = []
    s1 = "<class "
    sm1 = L1.__module__
    sm2 = s1 + "'" + sm1 + "."
    sm3 = "'>"
    for f in dmodule:
        if not (f in _standard):
            s = str(eval(f))
            if (s1 in s) and (sm1 in s):
                s = s.replace(sm2, "")
                s = s.replace(sm3, "")
                if s != "": ll.append(s)
    return ll

# ----------------------------------------------------------
def getFunctionNames():
    """
    Liefert die Namen aller globalen Methoden im Modul.

    Aufruf: getFunctionNames() oder gfn()"""
    
    # lokale Hilfsvariable: ll, s1, sm1, p3, f, s
    ll = []
    s1 = "<function "
    sm1 = L1.__module__
    p3 = re.compile("[. <>]+")
    for f in dmodule:
        s = str(eval(f))
        if (s1 in s):
            s2 = p3.split(s)
            if s2[2] != "": ll.append(s2[2])
    return ll

# ----------------------------------------------------------
def globalInfo(m="A"):
    """
    Gibt Informationen über Klassen, Methoden und Eigenschaften/variablen im
    Modul aus.

    Aufruf: globalInfo(m) oder gi(m)
    Zulässige Angaben für m:
    "A" (alles) [Voreinstellung]
    "V" (Variable)
    "E" (Eigenschaften; wie "V")
    "v" (Version)
    "M" (Methoden) 
    "K" (Klassen)
    "H" (Kopf)"""

    global Lfunction, Lclass, eps, trennz, leer

    # lokale Hilfsvariable: rr
    
    rr = 3 * leer

    if m in ["A", "H"]:
        __ueberschrift("Modul", "=")
        print(__doc__)
##        print(leer); __ueberschrift("Version", "-")
        print(_q)

    if m in ["A", "v"]:
        __ueberschrift("Version", "-")
        print("Modul  :", _modul)
        print("Version:", _version)
        print("Datum  :", _date)
        print(_q)

    if m in ["A", "V", "E"]:
        __ueberschrift("Globale Variablen/Eigenschaften", "-")
        print(rr, "eps".ljust(7),     str(eps).ljust(11),     "für Vergleiche auf Gleichheit: ganz klein")
        print(rr, "rndg".ljust(7),    str(rndg).ljust(11),    "für Rundung: Nachkommastellen")
        print(rr, "science".ljust(7), str(science).ljust(11), "Darstellung von Instanzen in Science Notation")
        print(rr, "trennz".ljust(7),  str(trennz).ljust(11),  "Trennzeichen zw. Maß und Maßeinheit in __str__/__repr__")
        print(rr, "\n"+rr+" Diese Eigenschaften können mit Hilfe der globalen Methode setVar geändert \n"+rr+" werden.\n")
        print(rr, "Außerdem:")
        print(rr, "modul".ljust(7),   str(modul).ljust(11),   "Name des Moduls")
        print(rr, "version".ljust(7), str(version).ljust(11), "aktuelle Version des Moduls")
        print(rr, "date".ljust(7),    str(date).ljust(11),    "Datum der letzten Änderung")
        print(_q)

    if m in ["A", "M"]:
        __ueberschrift("Globale Methoden", "-")
        for f in Lfunction: print(f, eval(f).__doc__)
        print(_q)

    if m in ["A", "K"]:
        __ueberschrift("Klassen", "-")
        for f in Lclass: print(f.ljust(4), eval(f).description())
        print(_q)

# ----------------------------------------------------------
def joule(wert=1, n=""):
    """
    Generiert eine W-Instanz (Arbeit) mit dem Wert wert [J].

    Aufruf: joule(wert)
    Parameter: 
    - wert (N, float oder int);
           Voreinstellung: 1
    - n (Zeichenkette);
        Name der Instanz;
        Voreinstellung: leere Zeichenkette
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    # lokale Hilfsvariablen: wert2, name
    
    if isinstance(wert, int) or isinstance(wert, float):
        wert2 = wert
    elif isinstance(wert, N):
        wert2 = wert.v
    else:
        raise TypeError(_fehler3 + str(wert))
    if n != "":
        name = n
    else:
        name = "joule(" + str(_str_aus(wert)) + ")"
    return W(newton(wert2), meter(1), n=name)

# ----------------------------------------------------------
def kelvin(wert=1, n=""):
    """
    Generiert eine TT-Instanz (Temperatur) mit dem Wert wert [K].

    Aufruf: kelvin(wert)
    Parameter: 
    - wert (N, float oder int);
           Voreinstellung: 1
    - n (Zeichenkette);
        Name der Instanz;
        Voreinstellung: leere Zeichenkette
    mögliche Fehlermeldungen:
    - Operand hat keinen zulässigen Typ
    - Parameter hat unzulässigen Wert"""
    
    # lokale Hilfsvariablen: wert2, name
    
    if isinstance(wert, int) or isinstance(wert, float):
        wert2 = wert
    elif isinstance(wert, N):
        wert2 = wert.v
    else:
        raise TypeError(_fehler3 + str(wert))
    if wert < 0:
        raise ValueError(_fehler6 + str(wert))
    if n != "":
        name = n
    else:
        name = "kelvin(" + str(_str_aus(wert)) + ")"
    return TT(wert2, _K, n=name)

# ----------------------------------------------------------
def kilogramm(wert=1, n=""):
    """
    Generiert eine M-Instanz (Gewicht) mit dem Wert wert [kg].

    Aufruf: kilogramm(wert)
    Parameter: 
    - wert (N, float oder int);
           Voreinstellung: 1
    - n (Zeichenkette);
        Name der Instanz;
        Voreinstellung: leere Zeichenkette
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    # lokale Hilfsvariablen: wert2, name
    
    if isinstance(wert, int) or isinstance(wert, float):
        wert2 = wert
    elif isinstance(wert, N):
        wert2 = wert.v
    else:
        raise TypeError(_fehler3 + str(wert))
    if n != "":
        name = n
    else:
        name = "kilogramm(" + str(_str_aus(wert)) + ")"
    return M(wert2, _kg, n=name)

# ----------------------------------------------------------
def meter(wert=1, n=""):
    """
    Generiert eine L1-Instanz (Länge) mit dem Wert wert [m].

    Aufruf: meter(wert)
    Parameter: 
    - wert (N, float oder int);
           Voreinstellung: 1
    - n (Zeichenkette);
        Name der Instanz;
        Voreinstellung: leere Zeichenkette
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    # lokale Hilfsvariablen: wert2, name
    
    if isinstance(wert, int) or isinstance(wert, float):
        wert2 = wert
    elif isinstance(wert, N):
        wert2 = wert.v
    else:
        raise TypeError(_fehler3 + str(wert))
    if n != "":
        name = n
    else:
        name = "meter(" + str(_str_aus(wert)) + ")"
    return L1(wert2, _m, n=name)

# ----------------------------------------------------------
def meterS(wert=1, n=""):
    """
    Generiert eine V-Instanz (Geschwindigkeit) mit dem Wert wert [m/s].

    Aufruf: meterS(wert)
    Parameter: 
    - wert (N, float oder int);
           Voreinstellung: 1
    - n (Zeichenkette);
        Name der Instanz;
        Voreinstellung: leere Zeichenkette
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    # lokale Hilfsvariablen: wert2, name
    
    if isinstance(wert, int) or isinstance(wert, float):
        wert2 = wert
    elif isinstance(wert, N):
        wert2 = wert.v
    else:
        raise TypeError(_fehler3 + str(wert))
    if n != "":
        name = n
    else:
        name = "meterS(" + str(_str_aus(wert)) + ")"
    return V(meter(wert2), sekunde(1), n=name)

# ----------------------------------------------------------
def meterS2(wert=1, n=""):
    """
    Generiert eine B-Instanz (Beschleunigung) mit dem Wert wert [m/s2].

    Aufruf: meterS2(wert)
    Parameter: 
    - wert (N, float oder int);
           Voreinstellung: 1
    - n (Zeichenkette);
        Name der Instanz;
        Voreinstellung: leere Zeichenkette
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    # lokale Hilfsvariablen: wert2, name
    
    if isinstance(wert, int) or isinstance(wert, float):
        wert2 = wert
    elif isinstance(wert, N):
        wert2 = wert.v
    else:
        raise TypeError(_fehler3 + str(wert))
    if n != "":
        name = n
    else:
        name = "meterS2(" + str(_str_aus(wert)) + ")"
    return B(meter(wert2), sekunde2(1), n=name)

# ----------------------------------------------------------
def meter2(wert=1, n=""):
    """
    Generiert eine L2-Instanz (Fläche) mit dem Wert wert [m2].

    Aufruf: meter2(wert)
    Parameter: 
    - wert (N, float oder int);
           Voreinstellung: 1
    - n (Zeichenkette);
        Name der Instanz;
        Voreinstellung: leere Zeichenkette
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    # lokale Hilfsvariablen: wert2, name
    
    if isinstance(wert, int) or isinstance(wert, float):
        wert2 = wert
    elif isinstance(wert, N):
        wert2 = wert.v
    else:
        raise TypeError(_fehler3 + str(wert))
    if n != "":
        name = n
    else:
        name = "meter2(" + str(_str_aus(wert)) + ")"
    return L2(wert2, _m2, n=name)

# ----------------------------------------------------------
def meter3(wert=1, n=""):
    """
    Generiert eine L3-Instanz (Volumen) mit dem Wert wert [m3].

    Aufruf: meter3(wert)
    Parameter: 
    - wert (N, float oder int);
           Voreinstellung: 1
    - n (Zeichenkette);
        Name der Instanz;
        Voreinstellung: leere Zeichenkette
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    # lokale Hilfsvariablen: wert2, name
    
    if isinstance(wert, int) or isinstance(wert, float):
        wert2 = wert
    elif isinstance(wert, N):
        wert2 = wert.v
    else:
        raise TypeError(_fehler3 + str(wert))
    if n != "":
        name = n
    else:
        name = "meter3(" + str(_str_aus(wert)) + ")"
    return L3(wert2, _m3, n=name)

# ----------------------------------------------------------
def newton(wert=1, n=""):
    """
    Generiert eine F1-Instanz (Kraft) mit dem Wert wert [N].

    Aufruf: newton(wert)
    Parameter: 
    - wert (N, float oder int);
           Voreinstellung: 1
    - n (Zeichenkette);
        Name der Instanz;
        Voreinstellung: leere Zeichenkette
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    # lokale Hilfsvariablen: wert2, name
    
    if isinstance(wert, int) or isinstance(wert, float):
        wert2 = wert
    elif isinstance(wert, N):
        wert2 = wert.v
    else:
        raise TypeError(_fehler3 + str(wert))
    if n != "":
        name = n
    else:
        name = "newton(" + str(_str_aus(wert)) + ")"
    return F1(kilogramm(wert2), meterS2(1), n=name)

# ----------------------------------------------------------
def PS(wert=1, n=""):
    """
    Generiert eine P-Instanz (Leistung) mit dem Wert wert [PS].

    Aufruf: PS(wert)
    Parameter: 
    - wert (N, float oder int);
           Voreinstellung: 1
    - n (Zeichenkette);
        Name der Instanz;
        Voreinstellung: leere Zeichenkette
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    return watt(wert * 735.49875)

# ----------------------------------------------------------
def sekunde(wert=1, n=""):
    """
    Generiert eine T1-Instanz (Temperatur) mit dem Wert wert [s].

    Aufruf: sekunde(wert)
    Parameter: 
    - wert (N, float oder int);
           Voreinstellung: 1
    - n (Zeichenkette);
        Name der Instanz;
        Voreinstellung: leere Zeichenkette
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    # lokale Hilfsvariablen: wert2, name
    
    if isinstance(wert, int) or isinstance(wert, float):
        wert2 = wert
    elif isinstance(wert, N):
        wert2 = wert.v
    else:
        raise TypeError(_fehler3 + str(wert))
    if n != "":
        name = n
    else:
        name = "sekunde(" + str(_str_aus(wert)) + ")"
    return T1(wert2, _s, n=name)

# ----------------------------------------------------------
def sekunde2(wert=1, n=""):
    """
    Generiert eine T2-Instanz mit dem Wert wert [s2].

    Aufruf: sekunde2(wert)
    Parameter: 
    - wert (N, float oder int);
           Voreinstellung: 1
    - n (Zeichenkette);
        Name der Instanz;
        Voreinstellung: leere Zeichenkette
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    # lokale Hilfsvariablen: wert2, name
    
    if isinstance(wert, int) or isinstance(wert, float):
        wert2 = wert
    elif isinstance(wert, N):
        wert2 = wert.v
    else:
        raise TypeError(_fehler3 + str(wert))
    if n != "":
        name = n
    else:
        name = "sekunde2(" + str(_str_aus(wert)) + ")"
    return T2(wert2, _s2, n=name)

# ----------------------------------------------------------
def setVar(e="", r="", s="", t=""):
    """
    Ermöglicht das nachträgliche Setzen der globalen Eigenschaften (e)ps, (r)ndg,
    (s)cience, (t)rennz.

    Aufruf: setVar(e=float, r=int, s=bool, t=char) oder sv(e=float, r=int, s=bool,
            t=char)
    (e)ps     : Genauigkeit von float-Zahlen
    (r)ndg,   : Nachkommazahlen
    (s)cience : wiss. Notation/Fixkomma
    (t)rennz  : Trennzeichen zwischen Maßzahl und Maßeinheit
    keine Voreinstellungen
    eingestellte Werte können durch gi("V") aufgelistet werden"""
    
    global eps, rndg, science, trennz
    
    if e != "":
        if isinstance(e, float):
            eps     = e
    if r != "":
        if isinstance(r, int):
            rndg    = r
    if s != "":
        if isinstance(s, bool):
            science = s
    if t != "":
        trennz = t

# ----------------------------------------------------------
def sign(s):
    """
    Liefert das Vorzeichen eines numerischen Werts/einer Instanz.

    Aufruf: sign(s)
    s: int/float oder B, F1, ..."""

    global eps

    # lokale Hilfsgröße: sx

    if typ(s) in ["int", "float"]:
        sx = s
    elif typ(s) in ['B', 'F1', 'G', 'L1', 'L2', 'L3', 'M', 'N', 'P', 'T1', 'T2', 'TT', 'U', 'V', 'W']:
        sx = s.internal
    if sx < 0:
        return -1
    elif abs(sx) <= eps:
        return 0
    else:
        return 1

# ----------------------------------------------------------
def typ(o):
    """
    Gibt den Typ von o aus.

    Aufruf: typ(o)
    o: int/float/B/F1 ...
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    if isinstance(o, L1):
        return "L1"
    elif isinstance(o, L2):
        return "L2"
    elif isinstance(o, L3):
        return "L3"
    elif isinstance(o, T1):
        return "T1"
    elif isinstance(o, T2):
        return "T2"
    elif isinstance(o, M):
        return "M"
    elif isinstance(o, TT):
        return "TT"
    elif isinstance(o, U):
        return "U"
    elif isinstance(o, V):
        return "V"
    elif isinstance(o, B):
        return "B"
    elif isinstance(o, F1):
        return "F1"
    elif isinstance(o, W):
        return "W"
    elif isinstance(o, P):
        return "P"
    elif isinstance(o, G):
        return "G"
    elif isinstance(o, list):
        return "list"
    elif isinstance(o, tuple):
        return "tuple"
    elif isinstance(o, int):
        return "int"
    elif isinstance(o, str):
        return "str"
    elif isinstance(o, dict):
        return "dict"
    elif isinstance(o, float):
        return "float"
    elif isinstance(o, N):
        return "N"
    else:
        raise TypeError(_fehler3 + str(o))

# ----------------------------------------------------------
def watt(wert=1, n=""):
    """
    Generiert eine P-Instanz (Leistung) mit dem Wert wert [W].

    Aufruf: watt(wert)
    Parameter:
    wert (N, float oder int);
         Voreinstellung: 1
    n    (Zeichenkette, Name)
         [Voreinstellung]
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    # lokale Hilfsvariablen: wert2, name
    
    if isinstance(wert, int) or isinstance(wert, float):
        wert2 = wert
    elif isinstance(wert, N):
        wert2 = wert.v
    else:
        raise TypeError(_fehler3 + str(wert))
    if n != "":
        name = n
    else:
        name = "watt(" + str(_str_aus(wert)) + ")"
    return P(joule(wert2), sekunde(1), n=name)

# =========================================================
class G:
    """
    Realisiert das Kombinieren von Instanzen (int, float, L1, L2, L3, M, T1, T2,
    TT, N) mittels eines Operators (*,/).

    g._eq_units(g)              Vergleicht die Maßeinheiten zweier G-Instanzen.
                                (intern)
    g.__add__(g, k=konvertierung) oder g + g
                                Dient der Addition von G-Instanzen.
    g.__eq__(g) oder g == g     Realisiert den Vergleich == in G.
    g.__ge__(g) oder g >= g     Realisiert den Vergleich >= in G.
    g.__gt__(g) oder g > g      Realisiert den Vergleich > in G.
    G.__init__(l, op, r, n='')  Initialisiert eine G-Instanz.
    g.__le__(g) oder g <= g     Realisiert den Vergleich <= in G.
    g.__lt__(g) oder g < g      Realisiert den Vergleich < in G.
    g.__mul__(o) oder g * o     Realisiert die Multiplikation von G-Instanzen.
    g.__ne__(g) oder g != g     Realisiert den Vergleich != in G.
    g.__neg__() oder -(g)       Realisiert negatives Vorzeichen von G-Instanzen.
    g.__pos__() oder +(g)       Realisiert positives Vorzeichen von G-Instanzen.
    g.__repr__() oder repr(g)   Repräsentiert eine G-Instanz.
    g.__str__() oder str(g)     Repräsentiert eine G-Instanz.
    g.__sub__(g, k=konvertierung) oder g - g
                                Dient der Subtraktion von G-Instanzen.
    g.__truediv__(o) oder g / o Realisiert die Division von G-Instanzen.
    G.beispiel(e)               Liefert Beispiele für die Methoden der Klasse G.
    G.classInfo(m=art)          Gibt Informationen zur Klasse G und ihre Methoden
                                aus.
    G.ci(m=art)                 Alias für G.classInfo(m=art)
    G.description()             Liefert eine Kurzbeschreibung der Klasse G.
    g.info()                    Gibt Informationen über eine G-Instanz aus.
    g.to(liste)                 Gibt in geigneter Weise den Wert einer G-Instanz
                                aus.
"""

    global eps, trennz

# ---------------------------------------------------------
    def __add__(self, g, k=_mks):
        """
        Dient der Addition von G-Instanzen.

        Aufruf: g.__add__(g, k=konvertierung)
        möglicher Typ des Operanden:
        - G (mit einer passenden Struktur)
        mögliche Fehlermeldungen:
        - Einheiten nicht kompatibel
        - Operand hat keinen zulässigen Typ"""
        
        # lokale Größen: p2, p3, z1, z2, l11, l12, l21, l22, w1, op, n1. lunitx, runtitx, links, rechts, name
        
        import re

        if not isinstance(g,G):
            raise TypeError(_fehler3 + str(g))
        rndg=16  # maximale Genauigkeit
        p2 = re.compile("[*/]")
        p3 = re.compile("[,' \]\[]+")
        z1 = self.to(k); i1 = z1.find(" "); l11 = z1[0:i1]; l12 = z1[i1:] # linke Seite
        z2 = g.to(k);    i2 = z2.find(" "); l21 = z2[0:i2]; l22 = z2[i2:] # rechte Seite
        l12.replace(" ", "")
        l22.replace(" ", "")
        w1 = eval(l11) + eval(l21)
        if l12 != l22:                                                    # nicht-kompatible Operanden
            raise ValueError(_fehler7 + str(l12) + " != " + str(l22))
        op = mul
        if l12.find(div) > 0:
            op = div
        n1 = p2.split(l12)                                                # Trennung am Operator (*, /)
        lunitx = n1[0]
        if len(n1) > 1:
            runitx = n1[1]
        else:
            runitx = ""
        lunit = p3.split(lunitx)
        runit = p3.split(runitx)
        links = N(w1)                                                     # linke Seite
        for f2 in lunit:    
            if f2 in ["cm", "m", "km"]:
                links = links * L1(1, f2)
            elif f2 in ["kg", "g"]:
                links = links * M(1, f2)
            elif f2 in ["s", "h"]:
                links = links * T(1, f2)
        rechts = N(1)                      # rechte Seite
        for f2 in runit:
            if f2 in ["cm", "m", "km"]:
                rechts = rechts * L1(1, f2)
            elif f2 in ["kg", "g"]:
                rechts = rechts * M(1, f2)
            elif f2 in ["s", "h"]:
                rechts = rechts * T(1, f2)
        name = str(self) + " + " + str(g)
        return G(links, op, rechts, n = name)
                
# ---------------------------------------------------------
    def __eq__(self, g):
        """
        Realisiert den Vergleich == in G.

        Aufruf: g.__eq__(g) oder g == g
        zulässiger Typ des Operanden:
        - G
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ
        - unorderable types: G() ..."""
        
        global eps
        
        if not isinstance(g, G):
            raise TypeError(_fehler3 + str(g))
        if not self._eq_units(g):
            return NotImplemented
        else:
            return abs(self.internal - g.internal) <= eps

# ---------------------------------------------------------
    def __ge__(self, g):
        """
        Realisiert den Vergleich >= in G.

        Aufruf: g.__ge__(g) oder g >= g
        zulässiger Typ des Operanden:
        - G
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ
        - unorderable types: G() ..."""
        
        global eps
        if not isinstance(g, G):
            raise TypeError(_fehler3 + str(g))
        if not self._eq_units(g):
            return NotImplemented
        else:
            return ((abs(self.internal - g.internal) <= eps) or (self.internal > g.internal))

# ---------------------------------------------------------
    def __gt__(self, g):
        """
        Realisiert den Vergleich > in G.

        Aufruf: g.__gt__(g) oder g > g
        zulässiger Typ des Operanden:
        - G
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ
        - unorderable types: G() ..."""
        
        if not isinstance(g, G):
            raise TypeError(_fehler3 + str(g))
        if not self._eq_units(g):
            print("---eq_units:")
            return NotImplemented
        else:
            return (self.internal > g.internal)

# ---------------------------------------------------------
    def __init__(self, l, op, r, n=""):
        """
        Initialisiert eine G-Instanz.

        Aufruf: G.__init__(l, op, r, n='')
        Parameter:
        - l : Instanz (int, float, L1, L2, L3, T1, T2, M, N, G, TT)
        - op: Operator (div, mul)
        - r : Instanz (int, float, L1, L2, L3, T1, T2, M, N, G, TT)
        - n : Name der Instanz;
              Voreinstellung: leere Zeichenkette
        mögliche Fehlermeldungen:
        - Operand hat den Wert Null.
        - Operand hat keinen zulässigen Typ
        - Operator ist nicht zulässig"""
        
        # lokale Hilfsvariable: b1, b2, b3, b4, c1, c2, c3, c4

        self.oben  = [] # Einheiten im Zähler
        self.unten = [] # Einheiten im Nenner

        if not op in [mul, div]:
            raise ValueError(_fehler9 + op)

        b1 = isinstance(l, int) or isinstance(l, float)
        b2 = isinstance(l, L1) or isinstance(l, L2) or isinstance(l, L3)
        b2 = b2 or isinstance(l, T1) or isinstance(l, T2) or isinstance(l, M) or isinstance(l, TT)
        b3 = isinstance(l, G)
        b4 = isinstance(l, N)

        c1 = isinstance(r, int) or isinstance(r, float)
        c2 = isinstance(r, L1) or isinstance(r, L2) or isinstance(r, L3)
        c2 = c2 or isinstance(r, T1) or isinstance(r, T2) or isinstance(r, M) or isinstance(r, TT)
        c3 = isinstance(r, G)
        c4 = isinstance(r, N)

        if not (b1 or b2 or b3 or b4):
            raise TypeError(_fehler3 + str(l))
        if not (c1 or c2 or c3 or c4):
            raise TypeError(_fehler3 + str(r))

        if (c2 or c3 or c4) and (op == div) and (abs(r.internal) < eps):
            raise ValueError(_fehler4 + str(r))

        self.links    = l
        self.rechts   = r
        self.operator = op

        self.internal = eval(str(l.internal) + op + str(r.internal))

        # Berechnung von u, llu, llo
        if b1:   # int/float
            pass
        elif b2: # L1/L2/L3/T1/M/TT
            self.oben.append(l.u)
        elif b3: # G
            self.oben  = self.oben + l.oben
            self.unten = self.unten + l.unten
        elif b4: # N
            pass
        else:
            pass

        if op == mul: # Operator ist mul, rechts
            if c1: # int/float
                pass
            elif c2: # L1/L2/L3/T1/M/TT
                self.oben.append(r.u)
            elif c3: # G
                self.oben  = self.oben + r.oben
                self.unten = self.unten + r.unten
            elif c4: # N
                pass
            else:
                pass
        else:         # Operator ist div, rechts
            if abs(r.internal) <= eps:
                raise ValueError(_fehler4 + str(r))
            if c1: # int/float
                pass
            elif c2: # L1/L2/L3/T1/M/TT
                self.unten.append(r.u)
            elif c3: # G
                self.oben  = self.oben + r.unten
                self.unten = self.unten + r.oben
            elif c4: # N
                pass
            else:
                pass

        self.v = eval(str(l.v) + op + str(r.v))

        if n != "":
            self.name = n
        else:
            self.name ="G(" + str(l) + leer + op + " (" + str(r) + "))"
        GListe.append(self)

# ---------------------------------------------------------
    def __le__(self, g):
        """
        Realisiert den Vergleich <= in G.

        Aufruf: g.__le__(g) oder g <=  g
        zulässiger Typ des Operanden:
        - G
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ
        - unorderable types: G() ..."""
        
        global eps
        if not isinstance(g, G):
            raise TypeError(_fehler3 + str(g))
        if not self._eq_units(g):
            return NotImplemented
        else:
            return ((abs(self.internal - g.internal) <= eps) or (self.internal < g.internal))

# ---------------------------------------------------------
    def __lt__(self, g):
        """
        Realisiert den Vergleich < in G.

        Aufruf: g.__lt__(g) oder g < g
        zulässiger Typ des Operanden:
        - G
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ
        - unorderable types: G() ..."""
        
        if not isinstance(g, G):
            raise TypeError(_fehler3 + str(g))
        if not self._eq_units(g):
            return NotImplemented
        else:
            return (self.internal < g.internal)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert die Multiplikation von G-Instanzen.

        Aufruf: g.__mul__(o) oder g * o
        mögliche Typen des Operanden:
        - - L1, L2, L3, T1, T2, TT, M, int, float, N, G, V, B, F1, W, P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]
        # lokale Hilfsvariable: b1, b2, name
        
        b1 = typ(o) in ["int", "float"]
        b2 = typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]

        name = str(self) + " * (" + str(o) + ")"
        if b1:
            return G(self, mul, N(o), n=name)
        elif b2:
            return G(self, mul, o, n=name)
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __ne__(self, g):
        """
        Realisiert den Vergleich != in G.

        Aufruf: g.__ne__(g) oder g != g
        zulässiger Typ des Operanden:
        - G
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ
        - unorderable types: G() ..."""
        
        global eps
        
        if not isinstance(g, G):
            raise TypeError(_fehler3 + str(g))
        if not self._eq_units(g):
            return NotImplemented
        else:
            return abs(self.internal - g.internal) > eps
# ---------------------------------------------------------
    def __neg__(self):
        """
        Realisiert negatives Vorzeichen für eine G-Instanz.

        Aufruf: g.__neg__() oder -(g)"""
        
        return G(self.links * (-1), self.operator, self.rechts)

# ---------------------------------------------------------
    def __pos__(self):
        """
        Realisiert positives Vorzeichen für G-Instanzen.

        Aufruf: g.__pos__() oder +(g)"""
        
        return self

# ---------------------------------------------------------
    def __repr__(self):
        """
        Repräsentiert eine G-Instanz.

        Aufruf: g.__repr__() oder repr(g)"""
        
        return "G(" + str(self.links) + " " + self.operator + " (" + str(self.rechts) + "))"

# ---------------------------------------------------------
    def __str__(self):
        """
        Repräsentiert eine G-Instanz.

        Aufruf: g.__str__() oder str(g)"""
        
        return "G(" + str(self.links) + " " + self.operator + " (" + str(self.rechts) + "))"

# ---------------------------------------------------------
    def __sub__(self, g, k=_mks):
        """
        Dient der subtraktion von G-Instanzen.

        Aufruf: g.__sub__(g, k=konvertierung)
        möglicher Typ des Operanden:
        - G (mit einer passenden Struktur)
        mögliche Fehlermeldungen:
        - Einheiten nicht kompatibel
        - Operand hat keinen zulässigen Typ"""
        
        return self + (-g)

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert die Division von G-Instanzen.

        Aufruf: g.__truediv__(o) oder g / o
        möglicher Typ des Operanden:
        - int, float, L1, L2, L3, T1, T2, M, G, N, TT
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ
        - Operand hat den Wert Null"""
        
        global eps
        
        # lokale Hilfsvariable: b1, b2, b3, b4, name
        
        b1 = typ(o) in ["int", "float"]
        b2 = typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT"]
        b3 = isinstance(o, G)
        b4 = isinstance(o, N)

        if b1:
            if abs(o) <= eps:
                raise ValueError(_fehler4 + str(o))
        elif b2 or b3 or b4:
            if abs(o.internal) <= eps:
                raise ValueError(_fehler4 + str(o))

        name = str(self) + " / (" + str(o) + ")"
        if b1:
            return G(self, div, N(o), n=name)
        elif b2 or b3 or b4:
            return G(self, div, o, n=name)
        else:
            raise TypeError(_fehler3 + str(o))

# ----------------------------------------------------------
    def _eq_units(self, g):
        """
        Vergleicht die Maßeinheiten zweier G-Instanzen. (intern)

        Aufruf: g._eq_units(g)"""
        
        return (sorted(self.oben) == sorted(g.oben)) and (sorted(self.unten) == sorted(g.unten))

# ---------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse G.

        Aufruf: G.beispiel(e)
        für e kann
        "*", "/", "__mul__", "__neg__", "__pos__", "__repr__", "__str__",
        "__truediv__", "description", "info", "repr", "str", "to", "Vorzeichen -",
        "Vorzeichen +", "--add__", "+", "__sub__", "-" angegeben werden
        Voreinstellung: leere Zeichenkette"""
        
        print("""
        l11=L1(2,m);l12=L1(3,cm);l21=L2(4,mm2);l22=L2(5,km2);l31=L3(6,liter);
        l32=L3(7,dl);n1=N(2);n1=N(-3);t11=T1(8,s);t12=T1(9,h);t21=T2(10,s2);
        t22=T2(11,d2);m11=M(12,g);m12=M(13,kg);tt1=TT(14,C);tt2=TT(15,K);
        g1=G(l11,div,t11);g2=G(t11,mul,m1);i1=2;i2=(-5);g3=G(l12,div,t12)""")
        l11=L1(2,_m);l12=L1(3,_cm);l21=L2(4,_mm2);l22=L2(5,_km2);l31=L3(6,_liter);l32=L3(7,_dl);n1=N(2);n1=N(-3);
        t11=T1(8,_s);t12=T1(9,_h);t21=T2(10,_s2);t22=T2(11,_d2);m11=M(12,_g);m12=M(13,_kg);tt1=TT(14,_C);tt2=TT(15,_K);
        g1=G(l11,div,t11);g2=G(t11,mul,m11);i1=2;i2=(-5);g3=G(l12,div,t12)
        if e in ["", "__mul__", "*"]:                                              # __mul__
            print("__mul__ oder *", G.__mul__.__doc__)
            for f in [i1,l11,l21,l31,m11,n1,t11,t21,tt1,g2]: print(_qqq+str(g1) + " * " + str(f) + " --> ", g1 * f)
        if e in ["", "__neg__", "Vorzeichen -"]:                                   # __neg__
            print("__neg__ oder Vorzeichen -", G.__neg__.__doc__)
            print(_qqq + "-" + str(g1) + " --> ", -g1)
        if e in ["","__pos__", "Vorzeichen +"]:                                    # __pos__
            print("__pos__ oder Vorzeichen +", G.__pos__.__doc__)
            print(_qqq + "+" + str(g1) + " --> ", +g1)
        if e in ["","__repr__", "repr"]:                                           # __repr__
            print("__repr__ oder repr", G.__repr__.__doc__)
            print(_qqq + "repr(g1), repr(g2) --> ", repr(g1), repr(g2))
        if e in ["","__str__", "str"]:                                             # __str__
            print("__str__ oder str", G.__str__.__doc__)
            print(_qqq + "str(g1), str(g2) --> ", str(g1), str(g2))
        if e in ["","__truediv__", "/"]:                                           # __truediv__
            print("__truediv__ oder /", G.__truediv__.__doc__)
            for f in [i1,l11,l21,l31,n1,t11,t21,m12,tt1,g1,g2]: print(_qqq+str(g1) + " / " +str(f) + " --> ", g1 / f)
        if e in ["", "description"]:                                               # description
            print("description", G.description.__doc__)
            print(_qqq + "G.description() --> ", G.description())
        if e in ["", "info"]:                                                      # info
            print("info", G.info.__doc__)
            print(_qqq + "g1.info(); g2.info() --> "); g1.info(); g2.info()
        if e in ["", "to"]:                                                        # to
            print("to", G.to.__doc__)
            print(_qqq + str(g1) + ".to(mks) --> ", g1.to(_mks))
            print(_qqq + str(g2) + ".to(cgs) --> ", g2.to(_cgs))
            print(_qqq + str(g1) + ".to(kmh) --> ", g1.to(_kmh))
        if e in ["", "+", "__add__"]:                                              # __add__
            print("__add__ oder +", G.__add__.__doc__)
            print(_qqq + str(g1) + " + " + str(g3) + "--> ", g1 + g3)
            print(_qqq + str(g1) + ".__add__(" + str(g3)+ ",mks)" + "--> ", g1.__add__(g3,mks))
        if e in ["", "-", "__sub__"]:                                              # __sub__
            print("__sub__ oder -", G.__sub__.__doc__)
            print(_qqq + str(g1) + " - " + str(g3) + "--> ", g1 - g3)
            print(_qqq + str(g1) + ".__sub__(" + str(g3)+ ",cgs)" + "--> ", g1.__sub__(g3,cgs))

# ---------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse G und ihre Methoden aus.

        Aufruf: G.classInfo(m=art) oder G.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles     : alles [Voreinstellung]
        + "H"/Kopf      : globale Informationen
        + "V"/Variablen : Variablen/Eigenschaften
        + "M"/Methoden  : Methoden"""
        
        # lokale Hilfsvariable: s1, s3, f
        
        s1 = "G."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class G\n", G.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der G-Instanzen:

    g.links    linker Operand
    g.operator Operator
    g.rechts   rechter Operand
    g.name     Name der Instanz
    g.oben     Einheiten im Zähler
    g.unten    Einheiten im Nenner
    g.internal interner Wert
    g.v        Wert in den angegebenen Einheiten
    """)
        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(G):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)

# ---------------------------------------------------------
    def description():
        """
        Liefert eine Kurzbeschreibung der Klasse G.

        Aufruf: G.description()"""
        
        return "Operationen mit G-Instanzen  (zusammengesetzte Objekte)"

# ---------------------------------------------------------
    def info(self):
        """
        Gibt Informationen über eine G-Instanz aus.

        Aufruf: g.info()"""
        
        # lokale Hilfsvariable: selfv, selfinternal
        
        selfv        = _str_aus(self.v)
        selfinternal = _str_aus(self.internal)
        print("Name                 :", self.name)
        print("Art                  :", "G-Instanz")
        print("linker Operand       :", self.links)
        print("Operator             :", self.operator)
        print("rechter Operand      :", self.rechts)
        print("Wert                 :", selfv, "(in den angegebenen Maßeinheiten)")
        print("interner Wert        :", selfinternal, "(in den Basismaßeinheiten [m, kg, s, K])")
        print("Maßeinheit(en) Zähler:", self.oben)
        print("Maßeinheit(en) Nenner:", self.unten)
        print(_q)

# ---------------------------------------------------------
    def to(self, d={}):
        """
        Gibt in geigneter Weise den Wert einer G-Instanz aus.

        Aufruf: g.to(wliste)
        vorgefertigte Werte für wliste (Dictionary mit Konvertierungen):
        - leer : keine Konvertierung [Voreinstellung], aber Bereinigung
        - kmh  : m --> km, s -->  h
        - mks  : m -->  m, s -->  s, kg --> kg
        - cgs  : m --> cm, kg --> g, s  --> s
        - mph  : m --> mi, s -->  h
        mögliche Fehlermeldung:
        - Parameter ist unzulässig."""
        
        # lokale Hilfsvariable: dx, llo,llu, vx, f, llox, llux, i, weiter, c, ff, gg, hh, ausgabe
        
        if not (typ(d) in [ "dict"]):
            raise ValueError(_fehler5 + str(d))
        if d != {}:
            dx = d
        else:
            ausgabe = ""
            ausgabe = ausgabe + _str_aus(self.v)
            ausgabe = ausgabe + leer + str(self.oben)
            if self.unten != []:
                ausgabe = ausgabe + "/" + str(self.unten)
            return ausgabe
        llo = []
        llu = []
        vx  = self.internal

        # normieren und sortieren
        for f in self.oben:
            if f in _lengths1: llo.append(_m)
            if f in _lengths2: llo.append(_m); llo.append(_m)
            if f in _lengths3: llo.append(_m); llo.append(_m); llo.append(_m);
            if f in _gewichte: llo.append(_kg)
            if f in _time1   : llo.append(_s)
            if f in _time2   : llo.append(_s); llo.append(_s)
            if f in _temp    : llo.append(_K)
        for f in self.unten:
            if f in _lengths1: llu.append(_m)
            if f in _lengths2: llu.append(_m); llu.append(_m)
            if f in _lengths3: llu.append(_m); llu.append(_m); llu.append(_m);
            if f in _gewichte: llu.append(_kg)
            if f in _time1   : llu.append(_s)
            if f in _time2   : llu.append(_s); llu.append(_s)
            if f in _temp    : llu.append(_K)
        llox = sorted(llo)
        llux = sorted(llu)

        # kürzen
        i = 0
        weiter = True
        while weiter:
            c = llox[i]
            if c in llux:
                j = llux.index(c)
                llox.pop(i)
                llux.pop(j)
            else:
                i = i + 1
            weiter = (i + 1 <= len(llox))
        llo = llox
        llu = llux
        llox = []
        llux = []
        for ff in range(len(llo)):
            gg = llo[ff]
            if gg in dx:
                hh = dx[gg]
                llox.append(hh)
                if gg == _m   : vx = vx / _lengths1[hh]
                elif gg == _kg: vx = vx / _gewichte[hh]
                elif gg == _s : vx = vx / _time1[hh]
                elif gg == _K : pass
                else: pass
            else:
                llox.append(gg)
        for ff in range(len(llu)):
            gg = llu[ff]
            if gg in dx:
                hh = dx[gg]
                llux.append(hh)
                if gg == _m   : vx = vx * _lengths1[hh]
                elif gg == _kg: vx = vx * _gewichte[hh]
                elif gg == _s : vx = vx * _time1[hh]
                elif gg == _K : pass
                else: pass
            else:
                llux.append(gg)
        ausgabe = ""
        ausgabe = ausgabe + _str_aus(vx)
        ausgabe = ausgabe + leer + str(llox)
        if llux != []:
            ausgabe = ausgabe + "/" + str(llux)
        if (len(llox) == 1) and (len(llux) == 0):
            if llox[0] == "km":
                return L(vx, _km)
            elif llox[0] == "m" :
                return L(vx, _m)
            elif llox[0] == "cm":
                return L(vx, _cm)
            elif llox[0] == "h" :
                return T(vx, _h)
            elif llox[0] == "kg":
                return M(vx, _kg)
            elif llox[0] == "g" :
                return M(vx, _g)
            elif llox[0] == "s" :
                return T(vx, _s)
        elif (len(llox) == 0) and (len(llux) == 0):
            return vx
        else:
            return ausgabe

    ci = classInfo # Alias für classInfo()

##        # kürzen; funktioniert leider nicht
##        llox = sorted([e for e in llo if not(e in llu)]) # list compreh.
##        llux = sorted([f for f in llu if not(f in llo)]) # list compreh.

# =========================================================
class V(G):
    """
    V ist eine Subklasse von G und realisiert das Rechnen mit V-Instanzen
    (Geschwindigkeiten). Sie erbt damit alle Eigenschaften und Methoden von G
    (außer denen, die überschrieben werden).

    Aufruf: V.__init__(l, t, n="")

    Parameter:

    l    : L1-Instanz;         keine Voreinstellung
    t    : T1-Instanz;         keine Voreinstellung
    n="" : Name der V-Instanz; Voreinstellung: leere Zeichenkette

    Methoden:

    v : V-Instanz (Geschwindigkeit)
    e : eine Methode der Klasse V
    o : eine zulässige Instanz

    v.__abs__() oder abs(v)     Liefert den Absolut-Betrag der V-Instanz.
    v.__add__(o) oder v + o     Realisiert das Addieren von V-Instanzen.
    V.__init__(l, t, n='')      Initialisiert eine V-Instanz.
    v.__mul__(o) oder v * o     Realisiert das Multiplizieren von V-Instanzen.
    v.__repr__() oder repr(v)   Repräsentiert eine V-Instanz.
    v.__str__() oder str(v)     Repräsentiert eine V-Instanz.
    v.__sub__(o) oder v - o     Realisiert das Subtrahieren von V-Instanzen.
    v.__truediv__(o) oder v / o	Realisiert die Division von V-Instanzen.
    v.__eq__(v) oder v == v     Realisiert den Vergleich == in V.
    v.__ge__(v) oder v >= v     Realisiert den Vergleich >= in V.
    v.__gt__(v) oder v > v      Realisiert den Vergleich > in V.
    v.__le__(v) oder v <= v     Realisiert den Vergleich <= in V.
    v.__lt__(v) oder v < v      Realisiert den Vergleich < in V.
    v.__ne__(v) oder v != v     Realisiert den Vergleich != in V.

    V.classInfo(m=art)          Gibt Informationen zur Klasse V und ihren
                                Methoden aus.
    V.ci(m=art)                 Alias für V.classInfo(m=art)
    V.beispiel(e)               Liefert Beispiele für die Methoden der Klasse V.
    V.description()             Liefert eine Kurzbeschreibung der Klasse V.
    v.to(liste)                 Gibt in geigneter Weise den Wert einer V-Instanz
                                aus.
    v.info()                    Gibt Informationen über eine V-Instanz
                                (Geschwindigkeit) aus.
    """
    
    global eps, trennz

    # Geschwindigkeit v = l/t

# ---------------------------------------------------------
    def __eq__(self, f):
        """
        Realisiert den Vergleich == in V.

        Aufruf: v.__eq__(v) oder v == v
        erlaubter Typ des Operanden:
        - V
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, V)):
            raise TypeError(_fehler3 + str(f))
        return abs(self.internal - f.internal) <= eps

# ---------------------------------------------------------
    def __ge__(self, f):
        """
        Realisiert den Vergleich >= in V.

        Aufruf: v.__ge__(v) oder v >= v
        erlaubter Typ des Operanden:
        - V
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, V)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal > f.internal) or (abs(self.internal - f.internal) <= eps)

# ---------------------------------------------------------
    def __gt__(self, f):
        """
        Realisiert den Vergleich > in V.

        Aufruf: v.__gt__(v) oder v > v
        erlaubter Typ des Operanden:
        - V
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(f, V)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal > f.internal)
# ---------------------------------------------------------
    def __le__(self, f):
        """
        Realisiert den Vergleich <= in V.

        Aufruf: v.__le__(v) oder v <= v
        erlaubter Typ des Operanden:
        - V
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, V)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal < f.internal) or (abs(self.internal - f.internal) <= eps)

# ---------------------------------------------------------
    def __lt__(self, f):
        """
        Realisiert den Vergleich < in V.

        Aufruf: v.__lt__(v) oder v < v
        erlaubter Typ des Operanden:
        - V
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(f, V)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal < f.internal)

# ---------------------------------------------------------
    def __ne__(self, f):
        """
        Realisiert den Vergleich != in V.

        Aufruf: v.__ne__(v) oder v != v
        erlaubter Typ des Operanden:
        - V
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, V)):
            raise TypeError(_fehler3 + str(f))
        return abs(self.internal - f.internal) > eps

# ---------------------------------------------------------
    def __abs__(self):
        """
        Liefert den Absolut-Betrag der V-Instanz.

        Aufruf: v.__abs__() oder abs(v)"""
        
        name = "abs(" + str(self) + ")"
        return V(abs(self.links), abs(self.rechts), n=name)

# ---------------------------------------------------------
    def __add__(self, o):
        """
        Realisiert das Addieren von V-Instanzen.

        Aufruf: v.__add__(o) oder v + o
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # lokale Größen: zwi, name
        
        if not isinstance(o, V):
            raise TypeError(_fehler3 + str(o))
        zwi  = G(self.links, div, self.rechts) + G(o.links, div, o.rechts)
        name = self.name + " + " + o.name
        return V(zwi.links, zwi.rechts, n=name)

# ---------------------------------------------------------
    def __init__(self, l, t, n=""):
        """
        Initialisiert eine V-Instanz.

        Aufruf: V.__init__(l, t, n='')
        Parameter:
        - l : L1-Instanz
        - t : T1-Instanz
        - n : Name der Instanz;
              Voreinstellung: leere Zeichenkette
        mögliche Fehlermeldungen:
        - Operand hat den Wert Null.
        - Operand hat keinen zulässigen Typ."""

        if abs(t.v) <= eps:
            raise ValueError(_fehler4 + str(t))
        if not (isinstance(l, L1) and isinstance(t, T1)):
            raise TypeError(_fehler3 + str(l) + "/" + str(t))
        if n != "":
            self.name = n
        else:
            self.name ="V(" + str(l) + ", " + str(t) + ")"
        G.__init__(self, l, div, t, self.name)
        VListe.append(self)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert das Multiplizieren von V-Instanzen.

        Aufruf: v.__mul__(o) oder v * o
        möglicher Typ des Operanden:
        - L1, L2, L3, T1, T2, TT, M, int, float, N, G, V, B, F1, W, P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]
        # lokale Hilfsvariablen: zwi, name
        
        zwi  = G(self.links, div, self.rechts) * o
        name = self.name + " * " + str(o)
        if isinstance(o, T1):
            return meter(zwi.internal, n=name)
        elif typ(o) in ["int", "float"]:
            return V(self.links * o, self.rechts, n=name)
        elif isinstance(o, N):
            return V(self.links * o.v, self.rechts, n=name)
        elif isinstance(o, F1):
            return watt(zwi.internal, n=name)
        elif typ(o) in ["L1", "L2", "L3", "T2", "M", "TT", "T1", "T2", "V", "B", "W", "P", "G"]:
            return G(self, mul, o, n=name)
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __repr__(self):
        """
        Repräsentiert eine V-Instanz.

        Aufruf: v.__repr__() oder repr(v)"""
        
        return "V(" + str(self.links) + ", " + str(self.rechts) + ")"
    
# ---------------------------------------------------------
    def __str__(self):
        """
        Repräsentiert eine V-Instanz.

        Aufruf: v.__str__() oder str(v)"""
        
        return "V(" + str(self.links) + ", " + str(self.rechts) + ")"

# ---------------------------------------------------------
    def __sub__(self, o):
        """
        Realisiert das Subtrahieren von V-Instanzen.

        Aufruf: v.__sub__(o) oder v - o
        mögliche Fehlermeldung:
        - Parameter hat unzulässigen Wert"""
        
        # lokale Größen: zwi, name
        
        if not isinstance(o, V):
            raise TypeError(_fehler3 + str(o))
        zwi  = G(self.links, div, self.rechts) - G(o.links, div, o.rechts)
        name = self.name + " - " + o.name
        return V(zwi.links, zwi.rechts, n=name)

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert die Division von V-Instanzen.

        Aufruf: v.__truediv__(o) oder v / o
        möglicher Typ des Operanden:
        - T1, T2, L1, L2, L3, V, B, int, float, N, M, TT, F1, W, P
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ
        - Operand hat den Wert Null"""
        
        global eps

        # lokale Hilfsvariablen: zwi, name
        
        if typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P"]:
            if abs(o.internal) <= eps:
                raise ValueError(_fehler4 + str(o))
        if typ(o) in ["int", "float"]:
            if abs(o) <= eps:
                raise ValueError(_fehler4 + str(o))
        name = self.name + " / " + str(o)
        zwi  = G(self.links, div, self.rechts) / o
        
        if isinstance(o, V):
            return zwi.internal                            # V/V ---> Skalar
        elif isinstance(o, T1):
            return meterS2(zwi.internal, n=name)           # V/T1 ---> B
        elif isinstance(o, B):
            return sekunde(zwi.internal, n=name)           # V/B ---> T1
        elif typ(o) in ["int", "float"]:
            return V(self.links / o, self.rechts, n=name)  # V/Skalar ---> V
        elif isinstance(o, N):
            return V(self.links / o.v, self.rechts, n=name)# V/N ---> V
        elif typ(o) in ["L1", "L2", "L3", "T2", "TT", "M", "F1", "W", "P"]:
            return G(self, div, o, n=name)                 # V/sonst ---> G
        else:
            raise TypeError(_fehler3 + str(o))

# ----------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse V.

        Aufruf: V.beispiel(e)
        für e kann
        "-", "*", "/", "__abs__", "__add__", "__mul__", "__repr__", "__str__",
        "__sub__", "__truediv__", "+", "abs", "description", "info", "repr", "str",
        leere Zeichenkette [Voreinstellung] angegeben werden"""

        print("""
        t0=T1(10,_s);l0=L1(250,_m);v0=meterS(-30);t1=sekunde(15);b1=meterS2(20);
        n1=N(15);i1=15;r1=15.0;v1=V(l0,t0)
        """)
        t0=T1(10,_s);l0=L1(250,_m);v0=meterS(-30);t1=sekunde(15);b1=meterS2(20);n1=N(15);i1=15;r1=15.0;v1=V(l0,t0)
        if e in ["","__abs__", "abs"]:                                             # __abs__
            print("__abs__ oder abs",V.__abs__.__doc__)
            print(_qqq+"abs(v0) --> ", abs(v0))
        if e in ["","__add__", "+"]:                                               # __add__
            print("__add__ oder +",V.__add__.__doc__)
            for f in [v0]: print(_qqq+"v1"+" + " +str(f)+" --> ", v1+f)
        if e in ["","__mul__", "*"]:                                               # __mul__
            print("__mul__ oder *",V.__mul__.__doc__)
            for f in [t1,n1,i1,r1]: print(_qqq+"v1"+" * " +str(f)+" --> ", v1*f)
        if e in ["","__repr__", "repr"]:                                           # __repr__
            print("__repr__ oder repr",V.__repr__.__doc__)
            print(_qqq+"repr(v0), repr(v1) --> ", repr(v0), repr(v1))
        if e in ["","__str__", "str"]:                                             # __str__
            print("__str__ oder str",V.__str__.__doc__)
            print(_qqq+"str(v0), str(v1) --> ", str(v0), str(v1))
        if e in ["","__sub__", "-"]:                                               # __sub__
            print("__sub__ oder -",V.__sub__.__doc__)
            for f in [v0]: print(_qqq+"v1"+" - " +str(f)+" --> ", v1-f)
        if e in ["","__truediv__", "/"]:                                           # __truediv__
            print("__truediv__ oder /",V.__truediv__.__doc__)
            for f in [t1,b1,n1,i1,r1,v0]: print(_qqq+"v1"+" / " +str(f)+" --> ", v1/f)
        if e in ["","description"]:                                                # description
            print("description",V.description.__doc__)
            print(_qqq+"V.description() --> ", V.description())
        if e in ["","info"]:                                                       # info
            print("info",V.info.__doc__)
            print(_qqq+str(v0)+".info() --> ");v0.info()
            print(_qqq+str(v1)+".info() --> ");v1.info()
       
# ---------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse V und ihren Methoden aus.

        Aufruf: V.classInfo(m=art) oder V.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles     : alles [Voreinstellung]
        + "H"/Kopf      : globale Informationen
        + "V"/Variablen : Variablen/Eigenschaften
        + "M"/Methoden  : Methoden"""
        
        # lokale Hilfsvariable: s1, s3, s2
        
        s1 = "V."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class V\n", V.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der V-Instanzen:

    v.links    linker Operand
    v.operator Operator
    v.rechts   rechter Operand
    v.name     Name der Instanz
    v.oben     Einheiten im Zähler
    v.unten    Einheiten im Nenner
    v.internal interner Wert
    v.v        Wert in den angegebenen Einheiten
    """)

        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(V):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)

# ---------------------------------------------------------
    def description():
        """
        Liefert eine Kurzbeschreibung der Klasse V.

        Aufruf: description()"""
        
        return "Operationen mitr V-Instanzen  (Geschwindigkeit)"

# ---------------------------------------------------------
    def info(self):
        """
        Gibt Informationen über eine V-Instanz (Geschwindigkeit) aus.

        Aufruf: v.info()"""
        
        # lokale Hilfsvariable: selfv, selfinternal
        
        selfv        = _str_aus(self.v)
        selfinternal = _str_aus(self.internal)
        print("Name                 :", self.name)
        print("Art                  :", "V-Instanz (Geschwindigkeit)")
        print("linker Operand       :", self.links)
        print("Operator             :", self.operator)
        print("rechter Operand      :", self.rechts)
        print("Wert                 :", selfv, "(in den angegebenen Maßeinheiten)")
        print("interner Wert        :", selfinternal, "(in den Basismaßeinheiten [m, kg, s, K])")
        print("Maßeinheit(en) Zähler:", self.oben)
        print("Maßeinheit(en) Nenner:", self.unten)
        print("konvertiert (km/h)   :", self.to(kmh))
        print("konvertiert (cgs)    :", self.to(cgs))
        print("konvertiert (mks)    :", self.to(mks))
        print(_q)

    ci = classInfo
    
# =========================================================
class B(G):
    """
    B ist eine Subklasse von G und realisiert das Rechnen mitr B-Instanzen
    (Beschleunigung). Sie erbt damit alle Eigenschaften und Methoden von G
    (außer denen, die überschrieben werden).

    Aufruf: B.__init__(l, t2, n="")

    Parameter:

    l    : L1-Instanz;          keine Voreinstellung
    t2   : T2-Instanz;          keine Voreinstellung
    n="" : Name der B-Instanz;  Voreinstellung: leere Zeichenkette

    Methoden:

    b : B-Instanz (Beschleuinigung)
    e : eine Methode der Klasse B
    o : eine zulässige Instanz

    b.__abs__() oder abs(b)     Liefert den Absolut-Betrag der B-Instanz.
    b.__add__(o) oder b + o     Realisiert das Addieren von B-Instanzen.
    B.__init__(l, t2, n='')     Initialisiert eine B-Instanz.
    b.__mul__(o) oder b * o     Realisiert das Multiplizieren von B-Instanzen.
    b.__repr__() oder repr(b)   Repräsentiert eine B-Instanz.
    b.__str__() oder str(b)     Repräsentiert eine B-Instanz.
    b.__sub__(o) oder b - o     Realisiert das Subtrahieren von B-Instanzen.
    b.__truediv__(o) oder b / o	Realisiert die Division von B-Instanzen.
    b.__eq__(b) oder b == b     Realisiert den Vergleich == in B.
    b.__ge__(b) oder b >= b     Realisiert den Vergleich >= in B.
    b.__gt__(b) oder b > b      Realisiert den Vergleich > in B.
    b.__le__(b) oder b <= b     Realisiert den Vergleich <= in B.
    b.__lt__(b) oder b < b      Realisiert den Vergleich < in B.
    b.__ne__(b) oder b != b     Realisiert den Vergleich != in B.

    B.beispiel(e)               Liefert Beispiele für die Methoden der Klasse B.
    B.description()             Liefert eine Kurzbeschreibung von B.
    B.ci(m=art)                 Alias für B.classInfo(m=art)
    B.classInfo(m=art)          Gibt Informationen zur Klasse B und ihren
                                Methoden aus.
    b.to(liste)                 Gibt in geigneter Weise den Wert einer B-Instanz
                                aus.
    b.info()                    Gibt Informationen über eine B-Instanz
                                (Beschleunigung) aus.
    """
    
    global eps, trennz

    # Beschleunigung b = l/t2

# ---------------------------------------------------------
    def __eq__(self, f):
        """
        Realisiert den Vergleich == in B.

        Aufruf: b.__eq__(b) oder b == b
        erlaubter Typ des Operanden:
        - B
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, B)):
            raise TypeError(_fehler3 + str(f))
        return abs(self.internal - f.internal) <= eps

# ---------------------------------------------------------
    def __ge__(self, f):
        """
        Realisiert den Vergleich >= in B.

        Aufruf: b.__ge__(b) oder b >= b
        erlaubter Typ des Operanden:
        - B
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, B)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal > f.internal) or (abs(self.internal - f.internal) <= eps)

# ---------------------------------------------------------
    def __gt__(self, f):
        """
        Realisiert den Vergleich > in B.

        Aufruf: b.__gt__(b) oder b > b
        erlaubter Typ des Operanden:
        - B
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(f, B)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal > f.internal)
# ---------------------------------------------------------
    def __le__(self, f):
        """
        Realisiert den Vergleich <= in B.

        Aufruf: b.__le__(b) oder b <= b
        erlaubter Typ des Operanden:
        - B
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, B)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal < f.internal) or (abs(self.internal - f.internal) <= eps)

# ---------------------------------------------------------
    def __lt__(self, f):
        """
        Realisiert den Vergleich < in B.

        Aufruf: b.__lt__(b) oder b < b
        erlaubter Typ des Operanden:
        - B
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(f, B)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal < f.internal)

# ---------------------------------------------------------
    def __ne__(self, f):
        """
        Realisiert den Vergleich != in B.

        Aufruf: b.__ne__(b) oder b != b
        erlaubter Typ des Operanden:
        - B
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, B)):
            raise TypeError(_fehler3 + str(f))
        return abs(self.internal - f.internal) > eps

# ---------------------------------------------------------
    def __abs__(self):
        """
        Liefert den Absolut-Betrag der B-Instanz.

        Aufruf: b.__abs__() oder abs(b)"""
        
        name = "abs(" + str(self) + ")"
        return B(abs(self.links), abs(self.rechts), n=name)

# ---------------------------------------------------------
    def __add__(self, o):
        """
        Realisiert das Addieren von B-Instanzen.

        Aufruf: b.__add__(o) oder b + o
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # lokale Größen: zwi, name
        
        if not isinstance(o, B):
            raise TypeError(_fehler3 + str(o))
        zwi  = G(self.links, div, self.rechts) + G(o.links, div, o.rechts)
        name = self.name + " + " + o.name
        return B(zwi.links, zwi.rechts, n=name)

# ---------------------------------------------------------
    def __init__(self, l, t2, n=""):
        """
        Initialisiert eine B-Instanz.

        Aufruf: B.__init__(l, t2, n='')
        Parameter:
        - l : L1-Instanz
        - t2: T2-Instanz
        - n : Name der Instanz;
              Voreinstellung: leere Zeichenkette
        mögliche Fehlermeldungen:
        - Operand hat den Wert Null.
        - Operand hat keinen zulässigen Typ."""
        
        if abs(t2.internal) <= eps:
            raise ValueError(_fehler4 + str(t2))
        if not (isinstance(l, L1) and isinstance(t2, T2)):
            raise TypeError(_fehler3 + str(l) + "/" + str(t2))
        if n != "":
            self.name = n
        else:
            self.name ="B(" + str(l) + ", " + str(t) + ")"
        G.__init__(self, l, div, t2, self.name)
        BListe.append(self)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert das Multiplizieren von B-Instanzen.

        Aufruf: b.__mul__(o) oder b * o
        Typ des Operanden:
        - L1, L2, L3, T1, T2, TT, MM, int, float, N, G, V, B, F1, W, P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""

        # typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]
        
        # lokale Hilfsvariablen: zwi, name
        
        name = self.name + " * " + str(o)
        zwi  = G(self.links, div, self.rechts) * o
        if isinstance(o, T1):
            return meterS(zwi.internal, n=name)
        elif isinstance(o, T2):
            return meter(zwi.internal, n=name)
        elif isinstance(o, N):
            return B(self.links * o.v, self.rechts, n=name)
        elif isinstance(o, M):
            return newton(zwi.internal, n=name)
        elif typ(o) in ["int", "float"]:
            return B(self.links * o, self.rechts, n=name)
        elif typ(o) in ["L1", "L2", "L3", "T2", "TT", "T1", "V", "B", "F1", "W", "P", "G"]:
            return G(self, mul, o, n=name)
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __repr__(self):
        """
        Repräsentiert eine B-Instanz.

        Aufruf: b.__repr__() oder repr(b)"""
        
        return "B(" + str(self.links) + ", " + str(self.rechts) + ")"

# ---------------------------------------------------------
    def __str__(self):
        """
        Repräsentiert eine B-Instanz.

        Aufruf: b.__str__() oder str(b)"""
        
        return "B(" + str(self.links) + ", " + str(self.rechts) + ")"

# ---------------------------------------------------------
    def __sub__(self, o):
        """
        Realisiert das Subtrahieren von B-Instanzen.

        Aufruf: b.__sub__(o) oder b - o
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # lokale Größen: zwi, name
        
        if not isinstance(o, B):
            raise TypeError(_fehler3 + str(o))
        zwi  = G(self.links, div, self.rechts) - G(o.links, div, o.rechts)
        name = self.name + " - " + o.name
        return B(zwi.links, zwi.rechts, n=name)

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert die Division von B-Instanzen.

        Aufruf: b.__truediv__(o) oder b / o
        möglicher Typ des Operanden:
        - B, int, float, N, L1, L2, L3, T1, T2, M, TT, V, W, P
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ
        - Operand hat den Wert Null"""
        
        global eps
        
        # lokale Hilfsvariable: zwi, name
        
        zwi  = G(self.links, div, self.rechts) / o
        name = self.name + " / " + str(o)
        if typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P"]:
            if abs(o.internal) <= eps: raise ValueError(_fehler4 + str(o))
        if typ(o) in ["int", "float"]:
            if abs(o) <= eps: raise ValueError(_fehler4 + str(o))
            
        if isinstance(o, B):
            return zwi.internal # B/B ---> Skalar
        elif typ(o) in ["int", "float"]:
            return B(self.links / o, self.rechts, n=name)   # B/Skalar ---> B
        elif isinstance(o, N):
            return B(self.links / o.v, self.rechts, n=name) # B/N ---> B
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "V", "F1", "W", "P"]:
            return G(self, div, o, n=name)                  # B/sonst ---> G
        else:
            raise TypeError(_fehler3 + str(o))

# ----------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse B.

        Aufruf: B.beispiel(e)
        für e kann
        "-", "*", "/", "__abs__", "__add__", "__mul__", "__repr__", "__str__",
        "__sub__", "__truediv__", "+", "abs", "description", "info", "repr", "str",
        leere Zeichenkette [Voreinstellung] angegeben werden"""

        print("""
        t0=T1(10,_s);l0=L1(250,_m);b0=meterS2(-30);t1=sekunde(15);v1=meterS(20);
        n1=N(15);i1=15;r1=15.0;m1=kilogramm(5);t2=sekunde2(40);b1=B(l0,t2)
        """)
        t0=T1(10,_s);l0=L1(250,_m);b0=meterS2(-30);t1=sekunde(15);v1=meterS(20);n1=N(15);i1=15;r1=15.0;m1=kilogramm(5);
        t2=sekunde2(40);b1=B(l0,t2)
        if e in ["","__abs__", "abs"]:                                             # __abs__
            print("__abs__ oder abs",B.__abs__.__doc__)
            print(_qqq+"abs(b0) --> ", abs(b0))
        if e in ["","__add__", "+"]:                                               # __add__
            print("__add__ oder +",B.__add__.__doc__)
            for f in [b0]: print(_qqq+"b1"+" + " +str(f)+" --> ", b1+f)
        if e in ["","__mul__", "*"]:                                               # __mul__
            print("__mul__ oder *",B.__mul__.__doc__)
            for f in [m1,t2,t1,n1,i1,r1]: print(_qqq+"b1"+" * " +str(f)+" --> ", b1*f)
        if e in ["","__repr__", "repr"]:                                           # __repr__
            print("__repr__ oder repr",B.__repr__.__doc__)
            print(_qqq+"repr(b0), repr(b1) --> ", repr(b0), repr(b1))
        if e in ["","__str__", "str"]:                                             # __str__
            print("__str__ oder str",B.__str__.__doc__)
            print(_qqq+"str(b0), str(b1) --> ", str(b0), str(b1))
        if e in ["","__sub__", "-"]:                                               # __sub__
            print("__sub__ oder -",B.__sub__.__doc__)
            for f in [b0]: print(_qqq+"b1"+" - " +str(f)+" --> ", b1-f)
        if e in ["","__truediv__", "/"]:                                           # __truediv__
            print("__truediv__ oder /",B.__truediv__.__doc__)
            for f in [n1,i1,r1,b0]: print(_qqq+"b1"+" / " +str(f)+" --> ", b1/f)
        if e in ["","description"]:                                                # description
            print("description",B.description.__doc__)
            print(_qqq+"V.description() --> ", V.description())
        if e in ["","info"]:                                                       # info
            print("info",B.info.__doc__)
            print(_qqq+str(b0)+".info() --> ");b0.info()
            print(_qqq+str(b1)+".info() --> ");b1.info()

# ---------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse B und ihren Methoden aus.

        Aufruf: B.classInfo(m=art) oder B.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles     : alles [Voreinstellung]
        + "H"/Kopf      : globale Informationen
        + "V"/Variablen : Variablen/Eigenschaften
        + "M"/Methoden  : Methoden"""
        
        # lokale Hilfsvariable: s1, s3, s2
        
        s1 = "B."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class B\n", B.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der B-Instanzen:

    b.links    linker Operand
    b.operator Operator
    b.rechts   rechter Operand
    b.name     Name der Instanz
    b.oben     Einheiten im Zähler
    b.unten    Einheiten im Nenner
    b.internal interner Wert
    b.v        Wert in den angegebenen Einheiten
    """)
        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(B):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)

# ----------------------------------------------------------
    def description():
        """
        Liefert eine Kurzbeschreibung der Klasse B.

        Aufruf: description()"""
        
        return "Operationen mitr B-Instanzen  (Beschleunigung)"

# ---------------------------------------------------------
    def info(self):
        """
        Gibt Informationen über eine B-Instanz (Beschleunigung) aus.

        Aufruf: b.info()"""
        
        # lokale Hilfsvariable: selfv, selfinternal
        
        selfv        = _str_aus(self.v)
        selfinternal = _str_aus(self.internal)
        print("Name                 :", self.name)
        print("Art                  :", "B-Instanz (Beschleunigung) ")
        print("linker Operand       :", self.links)
        print("Operator             :", self.operator)
        print("rechter Operand      :", self.rechts)
        print("Wert                 :", selfv, "(in den angegebenen Maßeinheiten)")
        print("interner Wert        :", selfinternal, "(in den Basismaßeinheiten [m, kg, s, K])")
        print("Maßeinheit(en) Zähler:", self.oben)
        print("Maßeinheit(en) Nenner:", self.unten)
        print("konvertiert (km/h)   :", self.to(kmh))
        print("konvertiert (cgs)    :", self.to(cgs))
        print("konvertiert (mks)    :", self.to(mks))
        print(_q)

    ci = classInfo

# =========================================================
class F1(G):
    """
    F1 ist eine Subklasse von G und realisiert das Rechnen mitr F1-Instanzen
    (Kraft).Sie erbt damit alle Eigenschaften und Methoden von G (außer denen,
    die überschrieben werden).

    Aufruf: F1.__init__(m, b, n="")

    Parameter:

    m    : M-Instanz;           keine Voreinstellung
    b    : B-Instanz;           keine Voreinstellung
    n="" : Name der F1-Instanz; Voreinstellung: leere Zeichenkette

    Methoden:

    f : F1-Instanz (Kraft)
    e : eine Methode der Klasse F1
    o : ein zulässige Instanz

    f.__abs__() oder abs(f)     Liefert den Absolut-Betrag der F1-Instanz.
    f.__add__(o) oder f + o     Realisiert das Addieren von F1-Instanzen.
    f.__mul__(o) oder f * o     Realisiert das Multiplizieren von F1-Instanzen.
    f.__repr__() oder repr(f)   Repräsentiert eine F1-Instanz.
    f.__str__() oder str(f)     Repräsentiert eine F1-Instanz.
    f.__sub__(o) oder f - o     Realisiert das Subtrahieren von F1-Instanzen.
    f.__truediv__(o) oder f / o Realisiert die Division von F1-Instanzen.
    F1.__init__(m, b, n='')     Initialisiert eine F1-Instanz.
    f.__eq__(f) oder f == f     Realisiert den Vergleich == in F1.
    f.__ge__(f) oder f >= f     Realisiert den Vergleich >= in F1.
    f.__gt__(f) oder f > f      Realisiert den Vergleich > in F1.
    f.__le__(f) oder f <= f     Realisiert den Vergleich <= in F1.
    f.__lt__(f) oder f < f      Realisiert den Vergleich < in F1.
    f.__ne__(f) oder f != f     Realisiert den Vergleich != in F1.
    F1.beispiel(e)              Liefert Beispiele für die Methoden der Klasse F1.
    F1.classInfo(m=art)         Gibt Informationen zur Klasse F1 und ihren
                                Methoden aus.
    F1.ci(m=art)                Alias für F1.classInfo(m=art)
    f.to(liste)                 Gibt in geigneter Weise den Wert einer F1-Instanz
                                aus.
    F1.description()            Liefert eine Kurzbeschreibung der Klasse F1.
    F1.info()                   Gibt Informationen über eine F1-Instanz (Kraft)
                                aus.
    """
    
    global eps, trennz

    # Kraft f = m*bk

# ---------------------------------------------------------
    def __eq__(self, f):
        """
        Realisiert den Vergleich == in F1.

        Aufruf: k.__eq__(k) oder k == k
        erlaubter Typ des Operanden:
        - F1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, F1)):
            raise TypeError(_fehler3 + str(f))
        return abs(self.internal - f.internal) <= eps

# ---------------------------------------------------------
    def __ge__(self, f):
        """
        Realisiert den Vergleich >= in F1.

        Aufruf: k.__ge__(k) oder k >= k
        erlaubter Typ des Operanden:
        - F1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        if not (isinstance(f, F1)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal > f.internal) or (abs(self.internal - f.internal) <= eps)

# ---------------------------------------------------------
    def __gt__(self, f):
        """
        Realisiert den Vergleich > in F1.

        Aufruf: k.__gt__(k) oder k > k
        erlaubter Typ des Operanden:
        - F1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        if not (isinstance(f, F1)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal > f.internal)
# ---------------------------------------------------------
    def __le__(self, f):
        """
        Realisiert den Vergleich <= in F1.

        Aufruf: k.__le__(k) oder k <= k
        erlaubter Typ des Operanden:
        - F1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, F1)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal < f.internal) or (abs(self.internal - f.internal) <= eps)

# ---------------------------------------------------------
    def __lt__(self, f):
        """
        Realisiert den Vergleich < in F1.

        Aufruf: k.__lt__(k) oder k < k
        erlaubter Typ des Operanden:
        - F1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(f, F1)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal < f.internal)

# ---------------------------------------------------------
    def __ne__(self, f):
        """
        Realisiert den Vergleich != in F1.

        Aufruf: k.__ne__(k) oder k != k
        erlaubter Typ des Operanden:
        - F1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, F1)):
            raise TypeError(_fehler3 + str(f))
        return abs(self.internal - f.internal) > eps

# ---------------------------------------------------------
    def __abs__(self):
        """
        Liefert den Absolut-Betrag der F1-Instanz.

        Aufruf: f.__abs__() oder abs(f)"""
        
        name = "abs(" + str(self) + ")"
        return F1(abs(self.links), abs(self.rechts), n=name)

# ---------------------------------------------------------
    def __add__(self, o):
        """
        Realisiert das Addieren von F1-Instanzen.

        Aufruf: f.__add__(o) oder f + o
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # lokale Größen: zwi, name
        
        if not isinstance(o, F1):
            raise TypeError(_fehler3 + str(o))
        zwi  = G(self.links, mul, self.rechts) + G(o.links, mul, o.rechts)
        name = self.name + " + " + o.name
        return newton(zwi.internal, n=name)

# ---------------------------------------------------------
    def __sub__(self, o):
        """
        Realisiert das Subtrahieren von F1-Instanzen.

        Aufruf: f.__sub__(o) oder f - o
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # lokale Größen: zwi, name
        
        if not isinstance(o, F1):
            raise TypeError(_fehler3 + str(o))
        zwi  = G(self.links, mul, self.rechts) - G(o.links, mul, o.rechts)
        name = self.name + " - " + o.name
        return newton(zwi.internal, n=name)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert das Multiplizieren von F1-Instanzen.

        Aufruf: f.__mul__(o) oder f * o
        Typ des Operaynden:
        - L1, L2, L3, T1, T2, TT, M, int, float, N, G, V, B, F1, W, P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]
        # lokale Hilfsvariablen: zwi, name
        
        zwi  = G(self.links, div, self.rechts) * o
        name = self.name + " * " + str(o)
        if isinstance(o, L1):
            return joule(zwi.internal, n=name)
        elif isinstance(o, N):
            return newton(self.internal * o.v, n=name)
        elif isinstance(o, V):
            return watt(self.internal * o.v, n=name)
        elif typ(o) in ["int", "float"]:
            return newton(self.internal * o, n=name)
        elif typ(o) in ["L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "B", "F1", "W", "P", "G"]:
            return G(self, mul, o, n=name)
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert die Division von F1-Instanzen.

        Aufruf: f.__truediv__(o) oder f / o
        möglicher Typ des Operanden:
        - B, M, F1, N, int, float, L1, L2, L3, T1, T2, N, V, W, P
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ
        - Operand hat den Wert Null"""
        
        global eps
        
        # lokale Hilfsvariablen: zwi, name
        
        zwi  = G(self.links, div, self.rechts) / o
        name = self.name+ " / " + str(o)
        if typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "G", "V", "B", "F1", "W", "P", "N"]:
            if abs(o.internal) <= eps: raise ValueError(_fehler4 + str(o))
        if typ(o) in ["int", "float"]: 
            if abs(o) <= eps: raise ValueError(_fehler4 + str(o))
            
        if isinstance(o, B):
            return kilogramm(zwi.internal, n=name)     # F1/B ---> M
        elif isinstance(o, M):
            return meterS2(zwi.internal, n=name)      # F1/M ---> B
        elif isinstance(o, F1):
            return zwi.internal                        # F1/F1 ---> Skalar
        elif isinstance(o, N):
            return newton(self.internal / o.v, n=name) # F1/N ---> F1
        elif typ(o) in ["int", "float"]:
            return newton(self.internal / o, n=name)   # F1/Skalar ---> F1
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "TT", "G", "V", "W", "P"]:
            return G(self, div, o, n=name)             # F1/sonst ---> G
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __init__(self, m, b, n=""):
        """
        Initialisiert eine F1-Instanz.

        Aufruf: F1.__init__(m, b, n='')
        Parameter:
        - m : M-Instanz
        - b : B-Instanz
        - n : Name der Instanz;
              Voreinstellung: leere Zeichenkette
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(m, M) and isinstance(b, B)):
            raise TypeError(_fehler3 + str(m) + "/" + str(b))
        if n != "":
            self.name = n
        else:
            self.name ="F1(" + str(m) + ", " + str(b) + ")"
        G.__init__(self, m, mul, b, self.name)
        F1Liste.append(self)

# ---------------------------------------------------------
    def __str__(self):
        """
        Repräsentiert eine F1-Instanz.

        Aufruf: f.__str__() oder str(f)"""
        
        return "F1(" + str(self.links) + ", " + str(self.rechts) + ")"

# ---------------------------------------------------------
    def __repr__(self):
        """
        Repräsentiert eine F1-Instanz.

        Aufruf: f.__repr__() oder repr(f)"""
        return "F1(" + str(self.links) + ", " + str(self.rechts) + ")"

# ----------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse F1.

        Aufruf: F1.beispiel(e)
        für e kann
        "-", "*", "/", "__abs__", "__add__", "__mul__", "__repr__", "__str__",
        "__sub__", "__truediv__", "+", "abs", "description", "info", "repr", "str",
        leere Zeichenkette [Voreinstellung] angegeben werden"""

        print("""
        i1=15;r1=15.0;n1=N(15);f0=newton(-200);t2=T2(20,s2);l1=L1(10,m);b1=B(l1,t2);
        m1=M(5,kg);f1=F1(m1,b1)
        """)
        i1=15;r1=15.0;n1=N(15);f0=newton(-200);t2=T2(20,s2);l1=L1(10,m);b1=B(l1,t2);m1=M(5,kg);f1=F1(m1,b1)

        if e in ["","__abs__", "abs"]:                                             # __abs__
            print("__abs__ oder abs",F1.__abs__.__doc__)
            print(_qqq+"abs(f0) --> ", abs(f0))
        if e in ["","__add__", "+"]:                                               # __add__
            print("__add__ oder +",F1.__add__.__doc__)
            for f in [f0]: print(_qqq+"f1"+" + " +str(f)+" --> ", f1+f)
        if e in ["","__mul__", "*"]:                                               # __mul__
            print("__mul__ oder *",F1.__mul__.__doc__)
            for f in [l1,n1,i1,r1]: print(_qqq+"f1"+" * " +str(f)+" --> ", f1*f)
        if e in ["","__repr__", "repr"]:                                           # __repr__
            print("__repr__ oder repr",F1.__repr__.__doc__)
            print(_qqq+"repr(f0), repr(f1) --> ", repr(f0), repr(f1))
        if e in ["","__str__", "str"]:                                             # __str__
            print("__str__ oder str",F1.__str__.__doc__)
            print(_qqq+"str(f0), str(f1) --> ", str(f0), str(f1))
        if e in ["","__sub__", "-"]:                                               # __sub__
            print("__sub__ oder -",F1.__sub__.__doc__)
            for f in [f0]: print(_qqq+"f1"+" - " +str(f)+" --> ", f1-f)
        if e in ["","__truediv__", "/"]:                                           # __truediv__
            print("__truediv__ oder /",F1.__truediv__.__doc__)
            for f in [b1,m1,f0,n1,i1,r1]: print(_qqq+"f1"+" / " +str(f)+" --> ", f1/f)
        if e in ["","description"]:                                                # description
            print("description",F1.description.__doc__)
            print(_qqq+"V.description() --> ", F1.description())
        if e in ["","info"]:                                                       # info
            print("info",F1.info.__doc__)
            print(_qqq+str(f0)+".info() --> ");f0.info()
            print(_qqq+str(f1)+".info() --> ");f1.info()

# ---------------------------------------------------------
    def description():
        """
        Liefert eine Kurzbeschreibung der Klasse F1.

        Aufruf: F1.description()"""
        
        return "Operationen mitr F1-Instanzen (Kraft)"

# ---------------------------------------------------------
    def info(self):
        """
        Gibt Informationen über eine F1-Instanz (Kraft) aus.

        Aufruf: F1.info()"""
        
        # lokale Hilfsvariable: selfv, selfinternal
        
        selfv        = _str_aus(self.v)
        selfinternal = _str_aus(self.internal)
        print("Name                 :", self.name)
        print("Art                  :", "F1-Instanz (Kraft)")
        print("linker Operand       :", self.links)
        print("Operator             :", self.operator)
        print("rechter Operand      :", self.rechts)
        print("Wert                 :", selfv, "(in den angegebenen Maßeinheiten)")
        print("interner Wert        :", selfinternal, "(in den Basismaßeinheiten [m, kg, s, K])")
        print("Maßeinheit(en) Zähler:", self.oben)
        print("Maßeinheit(en) Nenner:", self.unten)
        print("konvertiert (cgs)    :", self.to(cgs))
        print("konvertiert (mks) [N]:", self.to(mks))
        print(_q)

# ----------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse F1 und ihren Methoden aus.

        Aufruf: F1.classInfo(m=art) oder F1.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles     : alles [Voreinstellung]
        + "H"/Kopf      : globale Informationen
        + "V"/Variablen : Variablen/Eigenschaften
        + "M"/Methoden  : Methoden"""
        
        # lokale Hilfsvariable: s1, s3, s2
        
        s1 = "F1."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class F1\n", F1.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der F1-Instanzen:

    f.links    linker Operand
    f.operator Operator
    f.rechts   rechter Operand
    f.name     Name der Instanz
    f.oben     Einheiten im Zähler
    f.unten    Einheiten im Nenner
    f.internal interner Wert
    f.v        Wert in den angegebenen Einheiten
    """)
        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(F1):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)

    ci = classInfo

# =========================================================
class W(G):
    """
    W ist eine Subklasse von G und realisiert das Rechnen mit W-Instanzen
    (Arbeit). Sie erbt damit alle Eigenschaften und Methoden von G (außer
    denen, die überschrieben werden).

    Aufruf: W.__init__(k, l, n="")

    Parameter:

    k    : K-Instanz;           keine Voreinstellung
    l    : L1-Instanz;          keine Voreinstellung
    n="" : Name der W-Instanz;  Voreinstellung: leere Zeichenkette

    Methoden:

    w : W-Instanz (Arbeit)
    e : eine Methode der Klasse W
    o : eine zulässige Instanz

    w.__abs__() oder abs(w)   Liefert den Absolut-Betrag der W-Instanz.
    w.__add__(o) oder w + o   Realisiert das Addieren von W-Instanzen.
    W.__init__(k, l, n='')    Initialisiert eine W-Instanz.
    w.__mul__(o) oder w * o   Realisiert das Multiplizieren von W-Instanzen.
    w.__repr__() oder repr(w) Repräsentiert eine W-Instanz.
    w.__str__() oder str(w)   Repräsentiert eine W-Instanz.
    w.__sub__(o) oder w - o   Realisiert das Subtrahieren von W-Instanzen.
    w.__eq__(w) oder w == w   Realisiert den Vergleich == in W.
    w.__ge__(w) oder w >= w   Realisiert den Vergleich >= in W.
    w.__gt__(w) oder w > w    Realisiert den Vergleich > in W.
    w.__le__(w) oder w <= w   Realisiert den Vergleich <= in W.
    w.__lt__(w) oder w < w    Realisiert den Vergleich < in W.
    w.__ne__(w) oder w != w   Realisiert den Vergleich != in W.
    W.beispiel(e)             Liefert Beispiele für die Methoden der Klasse W.
    W.classInfo(m=art)        Gibt Informationen zur Klasse W und ihren Methoden
                              aus.
    W.ci(m=art)               Alias für W.classInfo(m=art)
    W.description()           Liefert eine Kurzbeschreibung der Klasse W.
    w.to(liste)               Gibt in geigneter Weise den Wert einer W-Instanz
                              aus.
    w.info()                  Gibt Informationen über eine W-Instanz (Arbeit)
                              aus.
    """
    
    global eps, trennz

    # Arbeit w = k*l

# ---------------------------------------------------------
    def __eq__(self, f):
        """
        Realisiert den Vergleich == in W.

        Aufruf: w.__eq__(w) oder w == w
        erlaubter Typ des Operanden:
        - W
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        global eps
        if not (isinstance(f, W)):
            raise TypeError(_fehler3 + str(f))
        return abs(self.internal - f.internal) <= eps

# ---------------------------------------------------------
    def __ge__(self, f):
        """
        Realisiert den Vergleich >= in W.

        Aufruf: w.__ge__(w) oder w >= w
        erlaubter Typ des Operanden:
        - W
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, W)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal > f.internal) or (abs(self.internal - f.internal) <= eps)

# ---------------------------------------------------------
    def __gt__(self, f):
        """
        Realisiert den Vergleich > in W.

        Aufruf: w.__gt__(w) oder w > w
        erlaubter Typ des Operanden:
        - W
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(f, W)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal > f.internal)
# ---------------------------------------------------------
    def __le__(self, f):
        """
        Realisiert den Vergleich <= in W.

        Aufruf: w.__le__(w) oder w <= w
        erlaubter Typ des Operanden:
        - W
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        if not (isinstance(f, W)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal < f.internal) or (abs(self.internal - f.internal) <= eps)

# ---------------------------------------------------------
    def __lt__(self, f):
        """
        Realisiert den Vergleich < in W.

        Aufruf: w.__lt__(w) oder w < w
        erlaubter Typ des Operanden:
        - W
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(f, W)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal < f.internal)

# ---------------------------------------------------------
    def __ne__(self, f):
        """
        Realisiert den Vergleich != in W.

        Aufruf: w.__ne__(w) oder w != w
        erlaubter Typ des Operanden:
        - W
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, W)):
            raise TypeError(_fehler3 + str(f))
        return abs(self.internal - f.internal) > eps

# ---------------------------------------------------------
    def __abs__(self):
        """
        Liefert den Absolut-Betrag der W-Instanz.

        Aufruf: w.__abs__() oder abs(w)"""
        
        name = "abs(" + str(self) + ")"
        return W(abs(self.links), abs(self.rechts), n=name)

# ---------------------------------------------------------
    def __add__(self, o):
        """
        Realisiert das Addieren von W-Instanzen.

        Aufruf: w.__add__(o) oder w + o
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # lokale Größen: zwi, name
        
        if not isinstance(o, W):
            raise TypeError(_fehler3 + str(o))
        zwi  = G(self.links, mul, self.rechts) + G(o.links, mul, o.rechts)
        name = self.name + " + " + o.name
        return joule(zwi.internal, n=name)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert das Multiplizieren von W-Instanzen.

        Aufruf: w.__mul__(o) oder w * o
        Typ des Operanden:
        - L1, L2, L3, T1, T2, TT, M, int, float, N, G, V, B, F1, W, P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]
        # lokale Hilfsvariablen: zwi, name
        
        zwi  = G(self.links, div, self.rechts) * o
        name = self.name + " * " + str(o)
        if isinstance(o, N):
            return joule(self.internal * o.v, n=name)
        elif typ(o) in ["int", "float"]:
            return joule(self.internal * o, n=name)
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "V", "B", "F1", "W", "P", "G"]:
            return G(self, mul, o, n=name)
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __sub__(self, o):
        """
        Realisiert das Subtrahieren von W-Instanzen.

        Aufruf: w.__sub__(o) oder w - o
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # lokale Größen: zwi, name
        
        if not isinstance(o, W):
            raise TypeError(_fehler3 + str(o))
        zwi  = G(self.links, mul, self.rechts) - G(o.links, mul, o.rechts)
        name = self.name + " - " + o.name
        return joule(zwi.internal, n=name)

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert das Multiplizieren von W-Instanzen.

        Aufruf: w.__truediv__(o) oder w * o
        möglicher Typ des Operanden:
        - T1, T2, L1, L2, L3, M, TT, F1, W, N, int, float, V, B
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ
        - Operand hat den Wert Null"""
        
        global eps
        
        # lokale Hilfsvariablen: zwi, name
        
        zwi  = G(self.links, div, self.rechts) / o
        name = self.name+ " / " + str(o)
        if typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P"]:
            if abs(o.internal) <= eps: raise ValueError(_fehler4 + str(o))
        if typ(o) in ["int", "float"]:
            if abs(o) <= eps: raise ValueError(_fehler4 + str(o))
            
        if isinstance(o, T1):
            return watt(zwi.internal, n=name)         # W/T1 ---> P
        elif isinstance(o, L1):
            return newton(zwi.internal, n=name)       # W/T1 ---> P
        elif isinstance(o, F1):
            return meter(zwi.internal, n=name)        # W/T1 ---> P
        elif isinstance(o, W):
            return zwi.internal                       # W/T1 ---> P
        elif isinstance(o, N):
            return joule(self.internal / o.v, n=name) # W/T1 ---> P
        elif typ(o) in ["int", "float"]:
            return joule(self.internal / o, n=name)   # W/T1 ---> P
        elif typ(o) in ["L2", "L3", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "P"]:
            return G(self, div, o, n=name)            # W/sonst ---> G
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __init__(self, k, l, n=""):
        """
        Initialisiert eine W-Instanz.

        Aufruf: W.__init__(k, l, n='')
        Parameter:
        - k : F1-Instanz
        - l : L1-Instanz
        - n : Name der Instanz;
              Voreinstellung: leere Zeichenkette
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(k, F1) and isinstance(l, L1)):
            raise TypeError(_fehler3 + str(k) + "/" + str(l))
        if n != "":
            self.name = n
        else:
            self.name ="W(" + str(l) + ", " + str(t) + ")"
        G.__init__(self, k, mul, l, self.name)
        WListe.append(self)

# ---------------------------------------------------------
    def __str__(self):
        """
        Repräsentiert eine W-Instanz.

        Aufruf: w.__str__() oder str(w)"""
        return "W(" + str(self.links) + ", " + str(self.rechts) + ")"

# ---------------------------------------------------------
    def __repr__(self):
        """
        Repräsentiert eine W-Instanz.

        Aufruf: w.__repr__() oder repr(w)"""
        
        return "W(" + str(self.links) + ", " + str(self.rechts) + ")"

# ---------------------------------------------------------
    def description():
        """
        Liefert eine Kurzbeschreibung der Klasse W.

        Aufruf: W.description()"""
        
        return "Operationen mit W-Instanzen  (Arbeit)"

# ---------------------------------------------------------
    def info(self):
        """
        Gibt Informationen über eine W-Instanz (Arbeit) aus.

        Aufruf: w.info()"""
        
        # lokale Hilfsvariable: selfv, selfinternal
        
        selfv        = _str_aus(self.v)
        selfinternal = _str_aus(self.internal)
        print("Name                    :", self.name)
        print("Art                     :", "W-Instanz (Arbeit)")
        print("linker Operand          :", self.links)
        print("Operator                :", self.operator)
        print("rechter Operand         :", self.rechts)
        print("Wert                    :", selfv, "(in den angegebenen Maßeinheiten)")
        print("interner Wert           :", selfinternal, "(in den Basismaßeinheiten [m, kg, s, K])")
        print("Maßeinheit(en) Zähler   :", self.oben)
        print("Maßeinheit(en) Nenner   :", self.unten)
        print("konvertiert (cgs)       :", self.to(cgs))
        print("konvertiert (mks) [Nm=J]:", self.to(mks))
        print(_q)

# ----------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse W.

        Aufruf: W.beispiel(e)
        für e kann
        "-", "*", "/", "__abs__", "__add__", "__mul__", "__repr__", "__str__",
        "__sub__", "__truediv__", "+", "abs", "description", "info", "repr", "str",
        leere Zeichenkette [Voreinstellung] angegeben werden"""

        print("""
        i1=15;r1=15.0;n1=N(15);t1=sekunde(75);l1=meter(50);f1=newton(100);
        w0=joule(-200);w1=W(f1,l1)
        """)
        i1=15;r1=15.0;n1=N(15);t1=sekunde(75);l1=meter(50);f1=newton(100);w0=joule(-200);w1=W(f1,l1)

        if e in ["","__abs__", "abs"]:                                             # __abs__
            print("__abs__ oder abs",W.__abs__.__doc__)
            print(_qqq+"abs(w0) --> ", abs(w0))
        if e in ["","__add__", "+"]:                                               # __add__
            print("__add__ oder +",W.__add__.__doc__)
            for f in [w0]: print(_qqq+"w1"+" + " +str(f)+" --> ", w1+f)
        if e in ["","__mul__", "*"]:                                               # __mul__
            print("__mul__ oder *",W.__mul__.__doc__)
            for f in [n1,i1,r1]: print(_qqq+"w1"+" * " +str(f)+" --> ", w1*f)
        if e in ["","__repr__", "repr"]:                                           # __repr__
            print("__repr__ oder repr",W.__repr__.__doc__)
            print(_qqq+"repr(w0), repr(w1) --> ", repr(w0), repr(w1))
        if e in ["","__str__", "str"]:                                             # __str__
            print("__str__ oder str",W.__str__.__doc__)
            print(_qqq+"str(w0), str(w1) --> ", str(w0), str(w1))
        if e in ["","__sub__", "-"]:                                               # __sub__
            print("__sub__ oder +",W.__sub__.__doc__)
            for f in [w0]: print(_qqq+"w1"+" - " +str(f)+" --> ", w1-f)
        if e in ["","__truediv__", "/"]:                                           # __truediv__
            print("__truediv__ oder /",W.__truediv__.__doc__)
            for f in [t1,l1,f1,w0,n1,i1,r1]: print(_qqq+"w1"+" / " +str(f)+" --> ", w1/f)
        if e in ["","description"]:                                                # description
            print("description",W.description.__doc__)
            print(_qqq+"V.description() --> ", W.description())
        if e in ["","info"]:                                                       # info
            print("info",W.info.__doc__)
            print(_qqq+str(w0)+".info() --> ");w0.info()
            print(_qqq+str(w1)+".info() --> ");w1.info()

# ----------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse W und ihren Methoden aus.

        Aufruf: W.classInfo(m=art) oder W.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles     : alles [Voreinstellung]
        + "H"/Kopf      : globale Informationen
        + "V"/Variablen : Variablen/Eigenschaften
        + "M"/Methoden  : Methoden"""
        
        # lokale Hilfsvariable: s1, s3, s2
        
        s1 = "W."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class W\n", W.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der W-Instanzen:

    w.links    linker Operand
    w.operator Operator
    w.rechts   rechter Operand
    w.name     Name der Instanz
    w.oben     Einheiten im Zähler
    w.unten    Einheiten im Nenner
    w.internal interner Wert
    w.v        Wert in den angegebenen Einheiten
    """)
        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(W):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)

    ci = classInfo

# =========================================================
class P(G):
    """
    P ist eine Subklasse von G und realisiert das Rechnen mit P-Instanzen
    (Leistung). Sie erbt damit alle Eigenschaften und Methoden von G (außer
    denen, die überschrieben werden).

    Aufruf: P.__init__(w, t, n="")

    Parameter:

    w    : W-Instanz;           keine Voreinstellung
    t    : T1-Instanz;          keine Voreinstellung
    n="" : Name der P-Instanz;  Voreinstellung: leere Zeichenkette

    Methoden:

    p : P-Instanz (Leistung)
    e : eine Methode der Klasse P
    o : ein zulässige Instanz

    p.__abs__() oder abs(p)     Liefert den Absolut-Betrag der P-Instanz.
    p.__add__(o) oder p + o     Realisiert das Addieren von P-Instanzen.
    P.__init__(w, t, n='')      Initialisiert eine P-Instanz.
    p.__mul__(o) oder p * o     Realisiert das Multiplizieren von P-Instanzen.
    p.__repr__() oder repr(p)   Repräsentiert eine P-Instanz.
    p.__str__() oder str(p)     Repräsentiert eine P-Instanz.
    p.__sub__(o) oder p - o     Realisiert das Subtrahieren von P-Instanzen.
    p.__truediv__(o) oder p / o Realisiert die Division von P-Instanzen.
    p.__eq__(p) oder p == p     Realisiert den Vergleich == in P.
    p.__ge__(p) oder p >= p     Realisiert den Vergleich >= in P.
    p.__gt__(p) oder p > p      Realisiert den Vergleich > in P.
    p.__le__(p) oder p <= p     Realisiert den Vergleich <= in P.
    p.__lt__(p) oder p < p      Realisiert den Vergleich < in P.
    p.__ne__(p) oder p != p     Realisiert den Vergleich != in P.
    P.beispiel(e)               Liefert Beispiele für die Methoden der Klasse P.
    P.classInfo(m=art)          Gibt Informationen zur Klasse P und ihren
                                Methoden aus.
    P.ci(m=art)                 Alias für P.classInfo(m=art)
    P.description()             Liefert eine Kurzbeschreibung der Klasse P.
    p.to(liste)                 Gibt in geigneter Weise den Wert einer P-Instanz
                                aus.
    p.info()                    Gibt Informationen über eine P-Instanz (Leistung)
                                aus.
    """
    
    global eps, trennz

    # Leistung p = w/t

# ---------------------------------------------------------
    def __eq__(self, f):
        """
        Realisiert den Vergleich == in P.

        Aufruf: p.__eq__(p) oder p == p
        erlaubter Typ des Operanden:
        - P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, P)):
            raise TypeError(_fehler3 + str(f))
        return abs(self.internal - f.internal) <= eps

# ---------------------------------------------------------
    def __ge__(self, f):
        """
        Realisiert den Vergleich >= in P.

        Aufruf: p.__ge__(p) oder p >= p
        erlaubter Typ des Operanden:
        - P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, P)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal > f.internal) or (abs(self.internal - f.internal) <= eps)

# ---------------------------------------------------------
    def __gt__(self, f):
        """
        Realisiert den Vergleich > in P.

        Aufruf: p.__gt__(p) oder p > p
        erlaubter Typ des Operanden:
        - P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(f, P)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal > f.internal)
    
# ---------------------------------------------------------
    def __le__(self, f):
        """
        Realisiert den Vergleich <= in P.

        Aufruf: p.__le__(p) oder p <= p
        erlaubter Typ des Operanden:
        - P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, P)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal < f.internal) or (abs(self.internal - f.internal) <= eps)

# ---------------------------------------------------------
    def __lt__(self, f):
        """
        Realisiert den Vergleich < in P.

        Aufruf: p.__lt__(p) oder p < p
        erlaubter Typ des Operanden:
        - P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(f, P)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal < f.internal)

# ---------------------------------------------------------
    def __ne__(self, f):
        """
        Realisiert den Vergleich != in P.

        Aufruf: p.__ne__(p) oder p != p
        erlaubter Typ des Operanden:
        - P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, P)):
            raise TypeError(_fehler3 + str(f))
        return abs(self.internal - f.internal) > eps

# ---------------------------------------------------------
    def __abs__(self):
        """
        Liefert den Absolut-Betrag der P-Instanz.

        Aufruf: p.__abs__() oder abs(p)"""
        
        name = "abs(" + str(self) + ")"
        return P(abs(self.links), abs(self.rechts), n=name)

# ---------------------------------------------------------
    def __add__(self, o):
        """
        Realisiert das Addieren von P-Instanzen.

        Aufruf: p.__add__(o) oder p + o
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # lokale Größen: zwi, name
        
        if not isinstance(o, P):
            raise TypeError(_fehler3 + str(o))
        zwi  = G(self.links, div, self.rechts) + G(o.links, div, o.rechts)
        name = self.name + " + " + o.name
        return watt(zwi.internal, n=name)

# ---------------------------------------------------------
    def __init__(self, w, t, n=""):
        """
        Initialisiert eine P-Instanz.

        Aufruf: P.__init__(w, t, n='')
        Parameter:
        - w : W-Instanz
        - t : T1-Instanz
        - n : Name der Instanz;
              Voreinstellung: leere Zeichenkette
        mögliche Fehlermeldungen:
        - Operand hat den Wert Null.
        - Operand hat keinen zulässigen Typ."""
        
        if abs(t.v) <= eps:
            raise ValueError(_fehler4 + str(t))
        if not (isinstance(w, W) and isinstance(t, T1)):
            raise TypeError(_fehler3 + str(w) + "/" + str(t))
        if n != "":
            self.name = n
        else:
            self.name ="P(" + str(w) + ", " + str(t) + ")"
        G.__init__(self, w, div, t, self.name)
        PListe.append(self)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert das Multiplizieren von P-Instanzen.

        Aufruf: p.__mul__(o) oder p * o
        Typ des Operanden:
        - - L1, L2, L3, T1, T2, TT, M, int, float, N, G, V, B, F1, W, P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]
        # lokale Hilfsvariablen: zwi, name
        
        zwi  = G(self.links, div, self.rechts) * o
        name = self.name + " * " + str(o)
        if isinstance(o, T1):
            return joule(zwi.internal, n=name)
        elif isinstance(o, N):
            return watt(self.internal * o.v, n=name)
        elif typ(o) in ["int", "float"]:
            return watt(self.internal * o, n=name)
        elif typ(o) in ["L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "V", "B", "F1", "W", "P", "G"]:
            return G(self, mul, o, n=name)
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __repr__(self):
        """
        Repräsentiert eine P-Instanz.

        Aufruf: p.__repr__() oder repr(p)"""
        
        return "P(" + str(self.links) + ", " + str(self.rechts) + ")"

# ---------------------------------------------------------
    def __str__(self):
        """
        Repräsentiert eine P-Instanz.

        Aufruf: p.__str__() oder str(p)"""
        
        return "P(" + str(self.links) + ", " + str(self.rechts) + ")"

# ---------------------------------------------------------
    def __sub__(self, o):
        """
        Realisiert das Subtrahieren von P-Instanzen.

        Aufruf: p.__sub__(o) oder p - o
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # lokale Größen: zwi, name
        
        if not isinstance(o, P):
            raise TypeError(_fehler3 + str(o))
        zwi  = G(self.links, div, self.rechts) - G(o.links, div, o.rechts)
        name = self.name + " + " + o.name
        return watt(zwi.internal, n=name)

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert die Division von P-Instanzen.

        Aufruf: p.__truediv__(o) oder p / o
        möglicher Typ des Operanden:
        - P, N, int, float, L1, L2, L3, T1, T2, M, TT, V, B, F1, W
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ
        - Operand hat den Wert Null"""
        
        global eps
        
        # lokale Hilfsvariablen: zwi, name
        
        zwi  = G(self.links, div, self.rechts) / o
        name = self.name + " / " + str(o)
        if typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P"]:
            if abs(o.internal) <= eps: raise ValueError(_fehler4 + str(o))
        if typ(o) in ["int", "float"]:
            if abs(o) <= eps: raise ValueError(_fehler4 + str(o))
            
        if isinstance(o, P):
            return zwi.internal                      # W/F1 ---> V
        elif isinstance(o, F1):
            return meterS(zwi.internal, n=name)      # W/F1 ---> V
        elif isinstance(o, V):
            return newton(zwi.internal, n=name)      # W/V ---> F1
        elif isinstance(o, N):
            return watt(self.internal / o.v, n=name) # W/N ---> W
        elif typ(o) in ["int", "float"]:
            return watt(self.internal / o, n=name)   # W/Skalar ---> W
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "B", "W"]:
            return G(self, div, o, n=name)           # W/sonst ---> G
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse P.

        Aufruf: P.beispiel(e)
        für e kann
        "-", "*", "/", "__abs__", "__add__", "__mul__", "__repr__", "__str__",
        "__sub__", "__truediv__", "+", "abs", "description", "info", "repr", "str",
        leere Zeichenkette [Voreinstellung] angegeben werden"""

        print("""
        i1=15;r1=15.0;n1=N(15);t1=sekunde(5);w1=joule(1000);p0=watt(-200);p1=P(w1,t1)
        """)
        i1=15;r1=15.0;n1=N(15);t1=sekunde(5);p1=joule(1000);p0=watt(-200);p1=P(p1,t1)

        if e in ["","__abs__", "abs"]:                                             # __abs__
            print("__abs__ oder abs",P.__abs__.__doc__)
            print(_qqq+"abs(p0) --> ", abs(p0))
        if e in ["","__add__", "+"]:                                               # __add__
            print("__add__ oder +",P.__add__.__doc__)
            for f in [p0]: print(_qqq+"p1"+" + " +str(f)+" --> ", p1+f)
        if e in ["","__mul__", "*"]:                                               # __mul__
            print("__mul__ oder *",P.__mul__.__doc__)
            for f in [t1,n1,i1,r1]: print(_qqq+"p1"+" * " +str(f)+" --> ", p1*f)
        if e in ["","__repr__", "repr"]:                                           # __repr__
            print("__repr__ oder repr",P.__repr__.__doc__)
            print(_qqq+"repr(p0), repr(p1) --> ", repr(p0), repr(p1))
        if e in ["","__str__", "str"]:                                             # __str__
            print("__str__ oder str",P.__str__.__doc__)
            print(_qqq+"str(p0), str(p1) --> ", str(p0), str(p1))
        if e in ["","__sub__", "-"]:                                               # __sub__
            print("__sub__ oder +",P.__sub__.__doc__)
            for f in [p0]: print(_qqq+"p1"+" - " +str(f)+" --> ", p1-f)
        if e in ["","__truediv__", "/"]:                                           # __truediv__
            print("__truediv__ oder /",P.__truediv__.__doc__)
            for f in [p0,n1,i1,r1]: print(_qqq+"p1"+" / " +str(f)+" --> ", p1/f)
        if e in ["","description"]:                                                # description
            print("description",P.description.__doc__)
            print(_qqq+"P.description() --> ", P.description())
        if e in ["","info"]:                                                       # info
            print("info",P.info.__doc__)
            print(_qqq+str(p0)+".info() --> ");p0.info()
            print(_qqq+str(p1)+".info() --> ");p1.info()

# ----------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse P und ihren Methoden aus.

        Aufruf: P.classInfo(m=art) oder P.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles     : alles [Voreinstellung]
        + "H"/Kopf      : globale Informationen
        + "V"/Variablen : Variablen/Eigenschaften
        + "M"/Methoden  : Methoden"""
        
        # lokale Hilfsvariable: s1, s3, s2
        
        s1 = "P."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class P\n", P.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der P-Instanzen:

    p.links    linker Operand
    p.operator Operator
    p.rechts   rechter Operand
    p.name     Name der Instanz
    p.oben     Einheiten im Zähler
    p.unten    Einheiten im Nenner
    p.internal interner Wert
    p.v        Wert in den angegebenen Einheiten
    """)
        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(P):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)

# ----------------------------------------------------------
    def description():
        """
        Liefert eine Kurzbeschreibung der Klasse P.

        Aufruf: P.description()"""
        
        return "Operationen mit P-Instanzen  (Leistung)"

# ---------------------------------------------------------
    def info(self):
        """
        Gibt Informationen über eine P-Instanz (Leistung) aus.

        Aufruf: p.info()"""
        
        # lokale Hilfsvariable: selfv, selfinternal
        
        selfv        = _str_aus(self.v)
        selfinternal = _str_aus(self.internal)
        print("Name                  :", self.name)
        print("Art                   :", "P-Instanz (Leistung)")
        print("linker Operand        :", self.links)
        print("Operator              :", self.operator)
        print("rechter Operand       :", self.rechts)
        print("Wert                  :", selfv, "(in den angegebenen Maßeinheiten)")
        print("interner Wert         :", selfinternal, "(in den Basismaßeinheiten [m, kg, s, K])")
        print("Maßeinheit(en) Zähler :", self.oben)
        print("Maßeinheit(en) Nenner :", self.unten)
        print("konvertiert (cgs)     :", self.to(cgs))
        print("konvertiert (mks) [W] :", self.to(mks))
        print(_q)

    ci = classInfo

# =========================================================
class L1:
    """
    Realisiert das Rechnen mit L1-Instanzen (Längen).

    Parameter:

    value=1: Längenwert;          Voreinstellung: 1
    unit=m : L1-Maßeinheit;       Voreinstellung: m
    n=""   : Name der L1-Instanz; Voreinstellung: leere Zeichenkette

    Methoden:

    l : T1-Instanzen (Länge)
    o : Instanz
    i : Integer
    u : eine zulässige L1-Maßeinheit

    l.__abs__() oder abs(l)     Liefert den Absolut-Betrag der L1-Instanz.
    l.__add__(l) oder l + l     Realisiert die Addition zweier L1-Instanzen.
    l.__eq__(l) oder l == l     Realisiert den Vergleich == in L1.
    l.__ge__(l) oder l >= l     Realisiert den Vergleich >= in L1.
    l.__gt__(l) oder l > l      Realisiert den Vergleich > in L1.
    L1.__init__(value=1, unit=m, n="") Initialisiert eine L1-Instanz.
    l.__le__(l) oder l <= l     Realisiert den Vergleich <= in L1.
    l.__lt__(l) oder l < l      Realisiert den Vergleich < in L1.
    l.__mul__(o) oder l * o     Realisiert die Multiplikation in L1.
    l.__ne__(l) oder l != l     Realisiert den Vergleich != in L1.
    l.__neg__() oder -(l)       Realisiert negatives Vorzeichen in L1.
    l.__pos__() oder +(l)       Realisiert positives Vorzeichen in L1.
    l.__pow__(i) oder l ** i    Realisiert das Potenzieren in L1.
    l.__repr__() oder repr(l)   Repräsentiert eine L1-Instanz.
    l.__str__() oder str(l)     Repräsentiert eine L1-Instanz.
    l.__sub__(l) oder l - l     Realisiert die Subtraktion zweier L1-Instanzen.
    l.__truediv__(o) oder l / o Realisiert die Division in L1.
    L1.beispiel(e)              Liefert Beispiele für die Methoden der Klasse L1.
    L1.classInfo(m=art)         Gibt Informationen zur Klasse L1 und ihre
                                Methoden aus.
    L1.ci(m=art)                Alias für L1.classInfo(m=art)
    L1.description()            Gibt eine Kurzbeschreibung der Klasse L1 aus.
    l.info(modus)               Gibt Informationen über eine L1-Instanz aus.
    l.to(u)                     Realisiert die Konvertierung einer L1-Instanz in
                                eine andere Maßeinheit.
    """

    global eps, trennz

# ---------------------------------------------------------
    def __abs__(self):
        """
        Liefert den Absolut-Betrag der L1-Instanz.

        Aufruf: l.__abs__() oder abs(l)"""
        
        name = "abs(" + str(self) + ")"
        return L1(abs(self.v), self.u, n=name)

# ---------------------------------------------------------
    def __add__(self, o):
        """
        Realisiert die Addition zweier L1-Instanzen.

        Aufruf: l.__add__(l) oder l + l
        erlaubter Typ des Operanden:
        - L1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # interne Hilfsvariable: name, ss
        
        if not (isinstance(o, L1)):
            raise TypeError(_fehler3 + str(o))
        name = str(self) + " + " + o.name
        return L1(self.internal + o.internal, _m, n=name)

# ---------------------------------------------------------
    def __eq__(self, l):
        """
        Realisiert den Vergleich == in L1.

        Aufruf: l.__eq__(l) oder l == l
        erlaubter Typ des Operanden:
        - L1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(l, L1)):
            raise TypeError(_fehler3 + str(o))
        return abs(self.internal - l.internal) <= eps

# ---------------------------------------------------------
    def __ge__(self, l):
        """
        Realisiert den Vergleich >= in L1.

        Aufruf: l.__ge__(l) oder l >= l
        erlaubter Typ des Operanden:
        - L1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(l, L1)):
            raise TypeError(_fehler3 + str(l))
        return (self.internal > l.internal) or (abs(self.internal - l.internal) <= eps)

# ---------------------------------------------------------
    def __gt__(self, l):
        """
        Realisiert den Vergleich > in L1.

        Aufruf: l.__gt__(l) oder l > l
        erlaubter Typ des Operanden:
        - L1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(l, L1)):
            raise TypeError(_fehler3 + str(l))
        return (self.internal > l.internal)

# ---------------------------------------------------------
    def __init__(self, value=1, unit=_m, n=""):
        """
        Initialisiert eine L1-Instanz.

        Aufruf: L1.__init__(value=1, unit=m, n="")
        Parameter:
        - value: Wert der L1-Instanz;
                 Voreinstellung: 1
        - unit : eine zulässige L1-Maßeinheit;
                 Voreinstellung: m
        - n    : Name der L1-Instanz;
                 Voreinstellung: leere Zeichenkette
        mögliche Fehlermeldung:
        - Unit ist hier nicht bekannt/zulässig"""
        
        if not (unit in _lengths1):
            raise ValueError(_fehler2 + str(unit))
        self.v = value
        self.u = unit
        self.internal = self.v * _lengths1[self.u]
        if n == "":
            self.name = "L1(" + str(_str_aus(self.v)) + trennz + self.u + ")"
        else:
            self.name = n
        L1Liste.append(self)

# ---------------------------------------------------------
    def __le__(self, l):
        """
        Realisiert den Vergleich <= in L1.

        Aufruf: l.__le__(l) oder l <= l
        erlaubter Typ des Operanden:
        - L1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(l, L1)):
            raise TypeError(_fehler3 + str(l))
        return (self.internal < l.internal) or (abs(self.internal - l.internal) <= eps)

# ---------------------------------------------------------
    def __lt__(self, l):
        """
        Realisiert den Vergleich < in L1.

        Aufruf: l.__lt__(l) oder l < l
        erlaubter Typ des Operanden:
        - L1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(l, L1)):
            raise TypeError(_fehler3 + str(l))
        return (self.internal < l.internal)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert die Multiplikation einer L1-Instanz.

        Aufruf: l.__mul__(o) oder l * o
        mögliche Typen des Operanden:
        - - L1, L2, L3, T1, T2, TT, M, int, float, N, G, V, B, F1, W, P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]
        # lokale Hilfsvariable: name
        
        name = str(self) + " * (" + str(o) + ")"
        if typ(o) in ["int", "float"]:
            return L1(self.v * o, self.u, n=name)
        elif isinstance(o, L1):
            return L2(self.internal * o.internal, _m2, n=name)
        elif isinstance(o, L2):
            return L3(self.internal * o.internal, _m3, n=name)
        elif isinstance(o, N):
            return L1(self.v * o.v, self.u, n=name)
        elif isinstance(o, F1):  
            zwi = G(self, mul, N(1)) * o
            return joule(zwi.internal, n=name)
        elif typ(o) in ["L3", "T1", "T2", "M", "TT", "T1", "T2", "V", "B", "W", "P", "G"]:
            return G(self, mul, o, n=name)
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __ne__(self, l):
        """
        Realisiert den Vergleich != in L1.

        Aufruf: l.__ne__(l) oder l != l
        erlaubter Typ des Operanden:
        - L1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(l, L1)):
            raise TypeError(_fehler3 + str(l))
        return abs(self.internal - l.internal) > eps

# ---------------------------------------------------------
    def __neg__(self):
        """
        Realisiert negatives Vorzeichen für eine L1-Instanz.

        Aufruf: l.__neg__() oder -(l)"""
        
        return L1(-self.v, self.u)

# ---------------------------------------------------------
    def __pos__(self):
        """
        Realisiert positives Vorzeichen für eine L1-Instanz.

        Aufruf: l.__pos__() oder +(l)"""
        
        return L1(self.v, self.u)

# ---------------------------------------------------------
    def __pow__(self, p):
        """
        Realisiert das Potenzieren einer L1-Instanz.

        Aufruf: l.__pow__(p) oder l ** p
        erlaubter Typ des Operanden p:
        - int, float
        erlaubte Werte für p:
        - 0, 1, 2, 3
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - unsupported operand type(s) for ** or pow(): 'L1' and 'int'"""
        
        # lokale Hilfsvariable: name
        
        global eps
        
        if not (isinstance(p, int) or isinstance(p, float)):
            raise TypeError(_fehler3 + str(p))
        name = str(self) + " ** (" + str(p) + ")"
        if abs(p) <= eps:
            return 1
        elif abs(p - 1) <= eps:
            return L1(self.v, self.u, n=name)
        elif abs(p - 2) <= eps:
            return L2(self.internal * self.internal, _m2, n=name)
        elif abs(p - 3) <= eps:
            return L3(self.internal * self.internal * self.internal, _m3, n=name)
        else:
            return NotImplemented

# ---------------------------------------------------------
    def __repr__(self):
        """
        Repräsentiert eine L1-Instanz.

        Aufruf: l.__repr__() oder repr(l)"""
        
        global trennz
        
        return "L1(" + _repr_aus(self.v) + trennz + self.u + ")"

# ---------------------------------------------------------
    def __str__(self):
        """
        Repräsentiert eine L1-Instanz.

        Aufruf: l.__str__() oder str(l)"""
        
        global trennz
        
        return "L1(" + _str_aus(self.v) + trennz + self.u + ")"

# ---------------------------------------------------------
    def __sub__(self, o):
        """
        Realisiert die Subtraktion zweier L1-Instanzen.

        Aufruf: l.__sub__(o) oder l-o
        erlaubter Typ des Operanden:
        - L1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(o, L1)):
            raise TypeError(_fehler3 + str(o))
        name = str(self) + " - " + o.name
        return L1(self.internal - o.internal, _m, n=name)

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert die Division einer L1-Instanz.

        Aufruf: l.__truediv__(o) oder l / o
        möglicher Typ des Operanden:
        - int, float, L1, N, L2, L3, T1, T2, M, TT, G, V, B, F1, W, P
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - Operand hat den Wert Null."""
        
        global eps
        
        # lokale Hilfsvariable: name
        
        name = str(self) + " / (" + str(o) + ")"
        if typ(o) in ["int", "float"]:
            if abs(o) <= eps:
                raise ValueError(_fehler4 + str(o))
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P"]:
            if abs(o.v) <= eps:
                raise ValueError(_fehler4 + str(o))

        if typ(o) in ["int", "float"]:
            return L1(self.internal / o, self.u, n=name)          # L1/Skalar ---> L1
        elif isinstance(o, L1):
            return self.internal / o.internal                     # L1/L1 ---> Skalar
        elif isinstance(o, N):
            return L1(self.internal / o.internal, self.u, n=name) # L1/N ---> L1
        elif isinstance(o, V):
            zwi = G(self, div, N(1)) / o
            return sekunde(zwi.internal, n=name)                  # L1/V ---> T1
        elif isinstance(o, B):
            zwi = G(self, mul, N(1)) / o
            return sekunde2(zwi.internal, n=name)                 # L1/B ---> T2
        elif isinstance(o, T2):  
            zwi = G(self, mul, N(1)) / o
            return meterS2(zwi.internal, n=name)                  # L1/T2 ---> B
        elif isinstance(o, T1):  
            zwi = G(self, mul, N(1)) / o
            return meterS(zwi.internal, n=name)                   # L1/T1 ---> V
        elif typ(o) in ["L2", "L3", "T1", "T2", "M", "TT", "V", "F1", "W", "P"]:
            return G(self, div, o, n=name)                        # L1/sonst ---> G
        else:
            raise TypeError(_fehler3 + str(o))

# ----------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse L1.

        Aufruf: L1.beispiel(e)
        für e kann
        "!=", "-", "*", "**", "/", "__add__", "__eq__", "__ge__", "__gt__",
        "__le__", "__lt__", "__mul__", "__ne__", "__neg__", "__pos__", "__pow__",
        "__repr__", "__str__", "__sub__", "__truediv__", "+", "<", "<=", "==", ">",
        ">=", "description", "info", "repr", "str", "to", "toMyfi", "Vorzeichen -",
        "Vorzeichen +", leere Zeichenkett [Voreinstellung] angegeben werden"""
        
        print("""
        l11=L1(2,m);l12=L1(3,cm);l21=L2(4,mm2);l22=L2(5,km2);l31=L3(6,liter);
        l32=L3(7,dl);n1=N(2);n1=N(-3);t11=T1(8,s);t12=T1(9,h);t21=T2(10,s2);
        t22=T2(11,d2);m11=M(12,g);m12=M(13,kg);tt1=TT(14,C);tt2=TT(15,K);
        g1=G(l11,div,t11);g2=G(t11,mul,m1);i1=2;i2=(-5)""")
        l11=L1(2,_m);l12=L1(3,_cm);l21=L2(4,_mm2);l22=L2(5,_km2);l31=L3(6,_liter);l32=L3(7,_dl);n1=N(2);n1=N(-3);
        t11=T1(8,_s);t12=T1(9,_h);t21=T2(10,_s2);t22=T2(11,_d2);m11=M(12,_g);m12=M(13,_kg);tt1=TT(14,_C);tt2=TT(15,_K);
        g1=G(l11,div,t11);g2=G(t11,mul,m11);i1=2;i2=(-5)
        if e in ["","__add__", "+"]:                                               # __add__
            print("__add__ oder +",L1.__add__.__doc__)
            for f in [l12]: print(_qqq+str(l11)+"+" +str(f)+" --> ", l11+f)
        if e in ["","__eq__", "=="]:                                               # __eq__
            print("__eq__ oder ==",L1.__eq__.__doc__)
            for f in [l12]: print(_qqq+str(l11)+"==" +str(f)+" --> ", l11==f)
        if e in ["","__ge__", ">="]:                                               # __ge__
            print("__ge__ oder >=",L1.__ge__.__doc__)
            for f in [l12]: print(_qqq+str(l11)+">=" +str(f)+" --> ", l11>=f)
        if e in ["","__gt__", ">"]:                                                # __gt__
            print("__gt__ oder >",L1.__gt__.__doc__)
            for f in [l12]: print(_qqq+str(l11)+">" +str(f)+" --> ", l11>f)
        if e in ["","__le__", "<="]:                                               # __le__
            print("__le__ oder <=",L1.__le__.__doc__)
            for f in [l12]: print(_qqq+str(l11)+"<=" +str(f)+" --> ", l11<=f)
        if e in ["","__lt__", "<"]:                                                # __lt__
            print("__lt__ oder <",L1.__lt__.__doc__)
            for f in [l12]: print(_qqq+str(l11)+"<" +str(f)+" --> ", l11<f)
        if e in ["","__mul__", "*"]:                                               # __mul__
            print("__mul__ oder *",L1.__mul__.__doc__)
            for f in [i1,l12,l21,l31,n1,t11,t21,m11,tt1,g1,g2]: print(_qqq+str(l11)+"*" +str(f)+" --> ", l11*f)
        if e in ["","__ne__", "!="]:                                               # __ne__
            print("__ne__ oder !=",L1.__ne__.__doc__)
            for f in [l12]: print(_qqq+str(l11)+"!=" +str(f)+" --> ", l11!=f)
        if e in ["","__neg__", "Vorzeichen -"]:                                    # __neg__
            print("__neg__ oder Vorzeichen -",L1.__neg__.__doc__)
            print(_qqq+"-"+str(l11)+" --> ", -l11)
        if e in ["","__pos__", "Vorzeichen +"]:                                    # __pos__
            print("__pos__ oder Vorzeichen +",L1.__pos__.__doc__)
            print(_qqq+"+"+str(l11)+" --> ", +l11)
        if e in ["","__pow__", "**"]:                                              # __pow__
            print("__pow__ oder **",L1.__pow__.__doc__)
            print(_qqq+str(l11)+"**2 --> ", l11**2)
            print(_qqq+str(l12)+"**3 --> ", l12**3)
        if e in ["","__repr__", "repr"]:                                           # __repr__
            print("__repr__ oder repr",L1.__repr__.__doc__)
            print(_qqq+"repr(l11), repr(l12) --> ", repr(l11), repr(l12))
        if e in ["","__str__", "str"]:                                             # __str__
            print("__str__ oder str",L1.__str__.__doc__)
            print(_qqq+"str(l11), str(l12) --> ", str(l11), str(l12))
        if e in ["","__sub__", "-"]:                                               # __sub__
            print("__sub__ oder -",L1.__sub__.__doc__)
            for f in [l12]: print(_qqq+str(l11)+"-" +str(f)+" --> ", l11-f)
        if e in ["","__truediv__", "/"]:                                           # __truediv__
            print("__truediv__ oder /",L1.__truediv__.__doc__)
            for f in [i1,l12,l21,l31,n1,t11,t21,m11,tt1]: print(_qqq+str(l11)+"/" +str(f)+" --> ", l11/f)
        if e in ["","description"]:                                                # description
            print("description",L1.description.__doc__)
            print(_qqq+"L1.description() --> ", L1.description())
        if e in ["","info"]:                                                       # info
            print("info",L1.info.__doc__)
            print(_qqq+str(l11)+".info() --> ");l11.info()
            print(_qqq+str(l12)+".info(lang) --> ");l12.info(lang)
        if e in ["","to"]:                                                         # to
            print("to",L1.to.__doc__)
            print(_qqq+str(l11)+".to(km) --> ",l11.to(_km))
            print(_qqq+str(l12)+".to(mm) --> ",l12.to(_mm))
            print(_qqq+str(l11)+".to(yd) --> ",l11.to(_yd))
            print(_qqq+str(l12)+".to(inch) --> ",l12.to(_inch))
        if e in ["","toMyfi"]:                                                    # toMyfi
            print("toMyfi",L1.toMyfi.__doc__)
            print(_qqq+"L1(2.5,km).toMyfi() --> ", L1(2.5,_km).toMyfi())

# ----------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse L1 und ihre Methoden aus.

        Aufruf: L1.classInfo(m=art) oder L1.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles     : alles [Voreinstellung]
        + "H"/Kopf      : globale Informationen
        + "M"/Methoden  : Methoden 
        + "V"/Variablen : Variablen/Eigenschaften
        + "E"/Einheiten : Einheiten"""
        
        # lokale Hilfsvariable: s1, s3, s2
        
        s1 = "L1."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class L1\n", L1.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der L1-Instanzen:

    l.v        Wert der Instanz (gemessen in l.u)
    l.u        Maßeinheit der Instanz (L1-Maßeinheit)
    l.name     Name der Instanz
    l.internal interner Wert
    """)
        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(L1):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)
        if m in ["A", "E"]:
            print('Einheiten\n')
            au("L1")
        
# ---------------------------------------------------------
    def description():
        """
        Liefert eine Kurzbeschreibung der Klasse L1.

        Aufruf: description()"""
        
        return "Operationen mit L1-Instanzen (Längenmaße)"

# ---------------------------------------------------------
    def info(self, m=kurz):
        """
        Gibt Informationen über eine L1-Instanz aus.

        Aufruf: l.info(m)
        m Modus
          kurz nur Grund-Eigenschaften
               [Voreinstellung]
          lang auch Darstellung in anderen Einheiten"""
        
        # lokale Hilfsvariable: mm, mmm, ss, sss
        
        ss  = _str_aus(self.v)
        sss = _str_aus(self.internal)
        print("Name         :", self.name)
        print("Art          :", "L1-Instanz (Länge)")
        print("Wert         :", ss, "(in " + self.u + ")")
        print("Einheit      :", self.u, "["+_descript[self.u]+"]")
        print("interner Wert:", sss, "(in m)")
        if m == lang:
            print("Darstellung in anderen Einheiten:")
            for f in sorted(_lengths1, key=str.lower):
                mm  = (self.to(f)).v
                mmm = _str_aus(mm)
                print(leer, f.ljust(4), str(mmm).ljust(18), "(" + _descript[f] + ")")
        print(_q)

# ---------------------------------------------------------
    def to(self, unit):
        """
        Realisiert die Konvertierung einer L1-Instanz in eine andere Maßeinheit.

        Aufruf: l.to(u)
        erlaubter Typ des Operanden:
        - eine der zulässigen L1-Maßeinheiten
        mögliche Fehlermeldung:
        - Unit ist hier nicht bekannt/zulässig"""
        
        # lokale Hilfsvariable: z, name
        
        if not (unit in _lengths1):
            raise ValueError(_fehler2 + str(unit))
        z = self.internal / _lengths1[unit]
        name = str(self) + "--->" + unit
        return L1(z, unit, n=name)

# ---------------------------------------------------------
    def toMyfi(self):
        """
        Liefert mile, yard, feet, inch der aktuellen L1-Instanz als Liste.

        Aufruf: l.toMyfi()"""
        
        # lokale Hilfsvariable: ll, zz, zmi, zyd, zft, zinch, vorz
        
        ll    = [0, 0, 0, 0]
        vorz  = sign(self.internal)
        zz    = abs(self.internal/_lengths1[_inch]) # jetzt alles in inch-Einheiten
        zmi   = 63360
        zyd   = 36
        zft   = 12
        zinch = _lengths1[_inch]
        ll[0] = L1(int(zz // zmi), _mi)*vorz; zz = zz % zmi
        ll[1] = L1(int(zz // zyd), _yd)*vorz; zz = zz % zyd
        ll[2] = L1(int(zz // zft), _ft)*vorz; zz = zz % zft
        ll[3] = L1(zz, _inch)*vorz
        return ll

    ci = classInfo  # Alias für classInfo()

# =========================================================
class L2:
    """
    Realisiert das Rechnen mit L2-Instanzen (Flächen).

    Aufruf: L2.__init__(value=1, unit=m2, n="")

    Parameter:

    value=1: Wert;
             Voreinstellung: 1
    unit=m2: L2-Maßeinheit;
             Voreinstellung: m2
    n=""   : Name der L2-Instanz;
             Voreinstellung: leere Zeichenkette

    Methoden:

    f : L2-Instanz (Fläche)
    n : Zahl(Integer/Float)
    o : Instanz
    i : Integer
    u : eine der zulässigen T2-Maßeinheiten

    f.__abs__() oder abs(f)     Liefert den Absolut-Betrag der L2-Instanz.
    f.__add__(f) oder f + f     Realisiert die Addition zweier L2-Instanzen.
    f.__eq__(f) oder f == f     Realisiert den Vergleich ==.
    f.__ge__(f) oder f >= f     Realisiert den Vergleich >=.
    f.__gt__(f) oder f > f      Realisiert den Vergleich >.
    L2.__init__(value=1,unit=m2,n="") Initialisiert eine L2-Instanz.
    f.__le__(f) oder f <= f     Realisiert den Vergleich <=.
    f.__lt__(f) oder f < f      Realisiert den Vergleich <.
    f.__mul__(o) oder f * o     Realisiert die Multiplikation.
    f.__neg__() oder -(f)       Realisiert negatives Vorzeichen für eine
                                L2-Instanz.
    f.__pos__() oder +(f)       Realisiert positives Vorzeichen für eine
                                L2-Instanz.
    f.__pow__(p) oder f ** p    Realisiert das Potenzieren einer L2-Instanz.
    f.__repr__() oder repr(f)   Repräsentiert eine L2-Instanz.
    f.__str__() oder str(f)     Repräsentiert eine L2-Instanz.
    f.__sub__(f) oder f - f     Realisiert die Subtraktion zweier L2-Instanzen.
    f.__truediv__(o) oder f / o Realisiert die Division einer L2-Instanz.
    L2.beispiel(e)              Liefert Beispiele für die Methoden der Klasse L2.
    L2.classInfo(m=art)         Gibt Informationen zur Klasse L2 und ihrer
                                Methoden aus.
    L2.ci(m=art)                Alias für L2.classInfo(m=art)
    L2.description()            Gibt eine Kurzbeschreibung der Klasse aus.
    f.info(modus)               Gibt Informationen über eine L2-Instanz aus.
    f.to(u)                     Realisiert die Konvertierung einer L2-Instanz in
                                eine andere Maßeinheit.
"""

    global eps, trennz

# ---------------------------------------------------------
    def __abs__(self):
        """
        Liefert den Absolut-Betrag der L2-Instanz.

        Aufruf: l.__abs__() oder abs(l)"""
        
        name = "abs(" + str(self) + ")"
        return L2(abs(self.v), self.u, n=name)

# ---------------------------------------------------------
    def __add__(self, o):
        """
        Realisiert die Addition zweier L2-Instanzen.

        Aufruf: f.__add__(f) oder f + f
        erlaubter Typ des Operanden:
        - L2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(o, L2)):
            raise TypeError(_fehler3 + str(o))
        name = str(self) + " + " + o.name
        return L2(self.internal + o.internal, _m2, n=name)

# ---------------------------------------------------------
    def __eq__(self, f):
        """
        Realisiert den Vergleich == in L2.

        Aufruf: f.__eq__(f) oder f == f
        erlaubter Typ des Operanden:
        - L2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, L2)):
            raise TypeError(_fehler3 + str(f))
        return abs(self.internal - f.internal) <= eps

# ---------------------------------------------------------
    def __ge__(self, f):
        """
        Realisiert den Vergleich >= in L2.

        Aufruf: f.__ge__(f) oder f >= f
        erlaubter Typ des Operanden:
        - L2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, L2)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal > f.internal) or (abs(self.internal - f.internal) <= eps)

# ---------------------------------------------------------
    def __gt__(self, f):
        """
        Realisiert den Vergleich > in L2.

        Aufruf: f.__gt__(f) oder f > f
        erlaubter Typ des Operanden:
        - L2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(f, L2)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal > f.internal)

# ---------------------------------------------------------
    def __init__(self, value=1, unit=_m2, n=""):
        """
        Initialisiert eine L2-Instanz.

        Aufruf: L2.__init__(value=1, unit=m2, n="")
        Parameter:
        - value: Wert der L2-Instanz;
                 Voreinstellung: 1
        - unit : eine zulässige L2-Maßeinheit;
                 Voreinstellung: m2
        - n    : Name der L2-Instanz;
                 Voreinstellung: leere Zeichenkette
        mögliche Fehlermeldung:
        - Unit ist hier nicht bekannt/zulässig"""
        
        global trennz
        
        if not (unit in _lengths2):
            raise ValueError(_fehler2 + str(unit))
        self.v = value
        self.u = unit
        self.internal = self.v * _lengths2[self.u]
        if n == "":
            self.name = "L2(" + str(_str_aus(self.v)) + trennz + self.u + ")"
        else:
            self.name = n
        L2Liste.append(self)

# ---------------------------------------------------------
    def __le__(self, f):
        """
        Realisiert den Vergleich <= in L2.

        Aufruf: f.__le__(f) oder f <= f
        erlaubter Typ des Operanden:
        - L2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, L2)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal < f.internal) or (abs(self.internal - f.internal) <= eps)

# ---------------------------------------------------------
    def __lt__(self, f):
        """
        Realisiert den Vergleich < in L2.

        Aufruf: f.__lt__(f) oder f < f
        erlaubter Typ des Operanden:
        - L2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(f, L2)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal < f.internal)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert die Multiplikation einer L2-Instanz.

        Aufruf: f.__mul__(o) oder f * o
        mögliche Typen des Operanden:
        - - L1, L2, L3, T1, T2, TT, M, int, float, N, G, V, B, F1, W, P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]
        # lokale Hilfsvariable: name
        
        name = str(self) + " * (" + str(o) + ")"
        if typ(o) in ["int", "float"]:
            return L2(self.v * o, self.u, n=name)
        elif isinstance(o, L1):
            return L3(self.internal * o.internal, _m3, n=name)
        elif isinstance(o, N):
            return L2(self.v * o.v, self.u, n=name)
        elif typ(o) in ["L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "V", "B", "F1", "W", "P", "G"]:
            return G(self, mul, o, n=name)
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __ne__(self, f):
        """
        Realisiert den Vergleich != in L2.

        Aufruf: f.__ne__(f) oder f != f
        erlaubter Typ des Operanden:
        - L2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, L2)):
            raise TypeError(_fehler3 + str(f))
        return abs(self.internal - f.internal) > eps

# ---------------------------------------------------------
    def __neg__(self):
        """
        Realisiert negatives Vorzeichen für eine L2-Instanz.

        Aufruf: f.__neg__() oder -(f)"""
        return L2(-self.v, self.u)

# ---------------------------------------------------------
    def __pos__(self):
        """
        Realisiert positives Vorzeichen für eine L2-Instanz.

        Aufruf: f.__pos__() oder +(f)"""
        return L2(self.v, self.u)

# ---------------------------------------------------------
    def __pow__(self, p):
        """
        Realisiert das Potenzieren einer L2-Instanz.

        Aufruf: f.__pow__(p) oder f ** p
        erlaubte Werte für p:
        - 0, 1, 0.5
        erlaubter Typ des Operanden p:
        - int, float
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - unsupported operand type(s) for ** or pow(): 'L2' and 'int'"""
        
        # lokale Hilfsvariable: name
        
        global eps
        
        if not (isinstance(p, int) or isinstance(p, float)):
            raise TypeError(_fehler3 + str(p))
        name = str(self) + " ** (" + str(p) + ")"
        if abs(p) <= eps:
            return 1
        elif abs(p - 1) <= eps:
            return L2(self.v, self.u, n=name)
        elif abs(p - 0.5) <= eps:
            return L(math.sqrt(self.internal), _m, n=name)
        else:
            return NotImplemented

# ---------------------------------------------------------
    def __repr__(self):
        """
        Repräsentiert eine L2-Instanz.

        Aufruf: f.__repr__() oder repr(f)"""
        
        global trennz
        
        return "L2(" + _repr_aus(self.v) + trennz + self.u + ")"

# ---------------------------------------------------------
    def __str__(self):
        """
        Repräsentiert eine L2-Instanz.

        Aufruf: f.__str__() oder str(f)"""
        
        global trennz
        
        return "L2(" + _str_aus(self.v) + trennz + self.u + ")"

# ---------------------------------------------------------
    def __sub__(self, o):
        """
        Realisiert die Subtraktion zweier L2-Instanzen.

        Aufruf: f.__sub__(o) oder f - o
        erlaubter Typ des Operanden:
        - L2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(o, L2)):
            raise TypeError(_fehler3 + str(o))
        name = str(self) + " - " + o.name
        return L2(self.internal - o.internal, _m2, n=name)

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert die Division einer L2-Instanz.

        Aufruf: f.__truediv__(o) oder f / o
        möglicher Typ des Operanden:
        - int, float, L1, L2, L3, T1, T2, M, N, TT, N, G, V, B, F1, W, P
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - Operand hat den Wert Null."""
        
        global eps
        
        # lokale Hilfsvariable: name
        
        name = str(self) + " / (" + str(o) + ")"
        if typ(o) in ["int", "float"]:
            if abs(o) <= eps:
                raise ValueError(_fehler4 + str(o))
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P"]:
            if abs(o.v) <= eps:
                raise ValueError(_fehler4 + str(o))

        if typ(o) in ["int", "float"]:
            return L2(self.internal / o, self.u, n=name)          # L2/skalar ---> L2
        elif isinstance(o, L1):
            return L1(self.internal / o.internal, _m, n=name)     # L2/L1 ---> L1
        elif isinstance(o, L2):
            return self.internal / o.internal                     # L2/L2 ---> Skalar
        elif isinstance(o, N):
            return L2(self.internal / o.internal, self.u, n=name) # L2/N ---> L2
        elif typ(o) in ["L3", "T1", "T2", "M", "TT", "T1", "T2", "V", "B", "F1", "W", "P"]:
            return G(self, div, o, n=name)                        # L2/sonst ---> G
        else:
            raise TypeError(_fehler3 + str(o))

# ----------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse L2.

        Aufruf: L2.beispiel(e)
        für e kann
        "!=", "-", "*", "**", "/", "__add__", "__eq__", "__ge__", "__gt__",
        "__le__", "__lt__", "__mul__", "__ne__", "__neg__", "__pos__", "__pow__",
        "__repr__", "__str__", "__sub__", "__truediv__", "+", "<", "<=", "==", ">",
        ">=", "description", "info", "repr", "str", "to", "Vorzeichen -", "Vorzeichen +",
        leere Zeichenkette [Voreinstellung] angegeben werden"""
        
        print("""
        l11=L1(2,m);l12=L1(3,cm);l21=L2(4,mm2);l22=L2(5,km2);l31=L3(6,liter);
        l32=L3(7,dl);n1=N(2);n1=N(-3);t11=T1(8,s);t12=T1(9,h);t21=T2(10,s2);
        t22=T2(11,d2);m11=M(12,g);m12=M(13,kg);tt1=TT(14,C);tt2=TT(15,K);
        g1=G(l11,div,t11);g2=G(t11,mul,m1);i1=2;i2=(-5)""")
        l11=L1(2,_m);l12=L1(3,_cm);l21=L2(4,_mm2);l22=L2(5,_km2);l31=L3(6,_liter);l32=L3(7,_dl);n1=N(2);n1=N(-3);
        t11=T1(8,_s);t12=T1(9,_h);t21=T2(10,_s2);t22=T2(11,_d2);m11=M(12,_g);m12=M(13,_kg);tt1=TT(14,_C);tt2=TT(15,_K);
        g1=G(l11,div,t11);g2=G(t11,mul,m11);i1=2;i2=(-5)
        if e in ["","__add__", "+"]:                                               # __add__
            print("__add__ oder +",L2.__add__.__doc__)
            for f in [l22]: print(_qqq+str(l21)+"+" +str(f)+" --> ", l21+f)
        if e in ["","__eq__", "=="]:                                               # __eq__
            print("__eq__ oder ==",L2.__eq__.__doc__)
            for f in [l22]: print(_qqq+str(l21)+"==" +str(f)+" --> ", l21==f)
        if e in ["","__ge__", ">="]:                                               # __ge__
            print("__ge__ oder >=",L2.__ge__.__doc__)
            for f in [l22]: print(_qqq+str(l21)+">=" +str(f)+" --> ", l21>=f)
        if e in ["","__gt__", ">"]:                                                # __gt__
            print("__gt__ oder >",L2.__gt__.__doc__)
            for f in [l22]: print(_qqq+str(l21)+">" +str(f)+" --> ", l21>f)
        if e in ["","__le__", "<="]:                                               # __le__
            print("__le__ oder <=",L2.__le__.__doc__)
            for f in [l22]: print(_qqq+str(l21)+"<=" +str(f)+" --> ", l21<=f)
        if e in ["","__lt__", "<"]:                                                # __lt__
            print("__lt__ oder <",L2.__lt__.__doc__)
            for f in [l22]: print(_qqq+str(l21)+"<" +str(f)+" --> ", l21<f)
        if e in ["","__mul__", "*"]:                                               # __mul__
            print("__mul__ oder *",L2.__mul__.__doc__)
            for f in [i1,l22,l21,l31,n1,t11,t21,m11,tt1,g1,g2]: print(_qqq+str(l21)+"*" +str(f)+" --> ", l21*f)
        if e in ["","__ne__", "!="]:                                               # __ne__
            print("__ne__ oder !=",L2.__ne__.__doc__)
            for f in [l22]: print(_qqq+str(l21)+"!=" +str(f)+" --> ", l21!=f)
        if e in ["","__neg__", "Vorzeichen -"]:                                    # __neg__
            print("__neg__ oder Vorzeichen -",L2.__neg__.__doc__)
            print(_qqq +"-"+str(l21)+" --> ", -l21)
        if e in ["","__pos__", "Vorzeichen +"]:                                    # __pos__
            print("__pos__ oder Vorzeichen +",L2.__pos__.__doc__)
            print(_qqq + "+"+str(l21)+" --> ", +l21)
        if e in ["","__pow__", "**"]:                                              # __pow__
            print("__pow__ oder **",L2.__pow__.__doc__)
            print(_qqq+str(l21)+"**0 --> ", l21**0)
            print(_qqq+str(l22)+"**(0.5) --> ", l22**(0.5))
        if e in ["","__repr__", "repr"]:                                           # __repr__
            print("__repr__ oder repr",L2.__repr__.__doc__)
            print(_qqq+"repr(l21), repr(l22) --> ", repr(l21), repr(l22))
        if e in ["","__str__", "str"]:                                             # __str__
            print("__str__ oder str",L2.__str__.__doc__)
            print(_qqq+"str(l21), str(l22) --> ", str(l21), str(l22))
        if e in ["","__sub__", "-"]:                                               # __sub__
            print("__sub__ oder -",L2.__sub__.__doc__)
            for f in [l22]: print(_qqq+str(l21)+"-" +str(f)+" --> ", l21-f)
        if e in ["","__truediv__", "/"]:                                           # __truediv__
            print("__truediv__ oder /",L2.__truediv__.__doc__)
            for f in [i1,l22,l21,l31,n1,t11,t21,m11,tt1]: print(_qqq+str(l21)+"/" +str(f)+" --> ", l21/f)
        if e in ["","description"]:                                                # description
            print("description",L2.description.__doc__)
            print(_qqq+"L2.description() --> ", L2.description())
        if e in ["","info"]:                                                       # info
            print("info",L2.info.__doc__)
            print(_qqq+str(l21)+".info() --> ");l21.info()
            print(_qqq+str(l22)+".info(lang) --> ");l22.info(lang)
        if e in ["","to"]:                                                         # to
            print("to",L2.to.__doc__)
            print(_qqq+str(l21)+".to(km2) --> ",l21.to(_km2))
            print(_qqq+str(l22)+".to(mm2) --> ",l22.to(_mm2))

# ----------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse L2 und ihren Methoden aus.

        Aufruf: L2.classInfo(m=art) oder L2.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles     : alles [Voreinstellung]
        + "H"/Kopf      : globale Informationen
        + "V"/Variablen : Variablen/Eigenschaften
        + "M"/Methoden  : Methoden
        + "E"/Einheiten : Einheiten"""
        
        # lokale Hilfsvariable: s1, s2, s3
        
        s1 = "L2."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class L2\n", L2.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der L2-Instanzen:

    l.v        Wert der Instanz (gemessen in l.u)
    l.u        Maßeinheit der Instanz (L2-Maßeinheit)
    l.name     Name der Instanz
    l.internal interner Wert
    """)
        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(L2):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)
        if m in ["A", "E"]:
            print('Einheiten\n')
            au("L2")

# ---------------------------------------------------------
    def description():
        """
        Liefert eine Kurzbeschreibung der Klasse L2.

        Aufruf: description()"""
        return "Operationen mit L2-Instanzen (Flächenmaße)"

# ---------------------------------------------------------
    def info(self, m=kurz):
        """
        Gibt Informationen über eine L2-Instanz aus.

        Aufruf: f.info(m)
        m Modus
          kurz  nur Grund-Eigenschaften
                [Voreinstellung]
          lang  auch Darstellung in anderen Einheiten"""

        # lokale Hilfsvariable: mm, mmm, ss, sss
        
        ss  = _str_aus(self.v)
        sss = _str_aus(self.internal)
        print("Name         :", self.name)
        print("Art          :", "L2-Instanz (Länge)")
        print("Wert         :", ss, "(in " + self.u + ")")
        print("Einheit      :", self.u, "["+_descript[self.u]+"]")
        print("interner Wert:", sss, "(in m2)")
        if m == lang:
            print("Darstellung in anderen Einheiten:")
            for f in sorted(_lengths2):
                mm  = self.to(f)
                mmm = _str_aus(mm.v)
                print(leer, f.ljust(5), str(mmm).ljust(22), "(" + _descript[f] + ")")
        print(_q)

# ---------------------------------------------------------
    def to(self, unit):
        """
        Realisiert die Konvertierung einer L2-Instanz in eine andere Maßeinheit.

        Aufruf: f.to(u)
        erlaubter Typ des Operanden:
        - eine der zulässigen L2-Maßeinheiten
        mögliche Fehlermeldung:
        - Unit ist hier nicht bekannt/zulässig"""
        
        # lokale Hilfsvariable: z, name
        
        if not (unit in _lengths2):
            raise ValueError(_fehler2 + str(unit))
        z = self.internal / _lengths2[unit]
        name = str(self) + "--->" + unit
        return L2(z, unit, n=name)

    ci = classInfo # Alias für classInfo()

# =========================================================
class L3:
    """
    Realisiert das Rechnen mit L3-Instanzen (Volumenmaße).

    Aufruf: L3.__init__(value=1, unit=m3, n="")

    Parameter:

    value=1: Wert;
             Voreinstellung: 1
    unit=m3: L3-Maßeinheit;
             Voreinstellung: m3
    n=""   : Name der L3-Instanz;
             Voreinstellung: leere Zeichenkette

    Methoden:

    a : L3-Instanz
    n : Zahl(Integer/Float)
    o : Instanz
    i : Integer
    u : eine der zulässigen L3-Maßeinheiten

    a.__abs__() oder abs(a)     Liefert den Absolut-Betrag der L3-Instanz.
    a.__add__(a) oder a + a     Realisiert die Addition zweier L3-Instanzen.
    a.__eq__(a) oder a == a     Realisiert den Vergleich == in L3.
    a.__ge__(a) oder a >= a     Realisiert den Vergleich >= in L3.
    a.__gt__(a) oder a > a      Realisiert den Vergleich > in L3.
    a.__le__(a) oder a <= a     Realisiert den Vergleich <= in L3.
    a.__lt__(a) oder a < a      Realisiert den Vergleich < in L3.
    a.__mul__(o) oder a * o     Realisiert die Multiplikation in L3.
    a.__neg__() oder -(a)       Realisiert negatives Vorzeichen für eine
                                L3-Instanz.
    a.__pos__() oder +(a)       Realisiert positives Vorzeichen für eine
                                L3-Instanz.
    a.__pow__(p) oder f ** p    Realisiert das Potenzieren einer L3-Instanz.
    a.__repr__() oder repr(f)   Repräsentiert eine L3-Instanz.
    a.__str__() oder str(f)     Repräsentiert eine L3-Instanz.
    a.__sub__(a) oder f - a     Realisiert die Subtraktion zweier L3-Instanzen.
    a.__truediv__(o) oder f / o Realisiert die Division einer L3-Instanz.
    L3.beispiel(e)              Liefert Beispiele für die Methoden der
                                Klasse L3.
    a.info(modus)               Gibt Informationen über eine L3-Instanz aus.
    a.to(u)                     Realisiert die Konvertierung einer L3-Instanz in
                                eine andere Maßeinheit.
    L3.__init__(value=1,unit=m3,n="") Initialisiert eine L3-Instanz.
    L3.classInfo(m=art)         Gibt Informationen zur Klasse L3 und ihrer
                                Methoden aus.
    L3.ci(m=art)                Alias für L3.classInfo(m=art)
    L3.description()            Gibt eine Kurzbeschreibung der Klasse L3 aus.
"""

    global eps, trennz

# ---------------------------------------------------------
    def __abs__(self):
        """
        Liefert den Absolut-Betrag der L3-Instanz.

        Aufruf: l.__abs__() oder abs(l)"""
        name = "abs(" + str(self) + ")"
        return L3(abs(self.v), self.u, n=name)

# ---------------------------------------------------------
    def __add__(self, o):
        """
        Realisiert die Addition zweier L3-Instanzen.

        Aufruf: a.__add__(a) oder a + a
        erlaubter Typ des Operanden:
        - L3
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(o, L3)):
            raise TypeError(_fehler3 + str(o))
        name = str(self) + " + " + o.name
        return L3(self.internal + o.internal, _m3, n=name)

# ---------------------------------------------------------
    def __eq__(self, f):
        """
        Realisiert den Vergleich == in L3.

        Aufruf: a.__eq__(a) oder a == a
        erlaubter Typ des Operanden:
        - L3
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, L3)):
            raise TypeError(_fehler3 + str(f))
        return abs(self.internal - f.internal) <= eps

# ---------------------------------------------------------
    def __ge__(self, f):
        """
        Realisiert den Vergleich >= in L3.

        Aufruf: a.__ge__(a) oder a >= a
        erlaubter Typ des Operanden:
        - L3
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, L3)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal > f.internal) or (abs(self.internal - f.internal) <= eps)

# ---------------------------------------------------------
    def __gt__(self, f):
        """
        Realisiert den Vergleich > in L3.

        Aufruf: a.__gt__(a) oder a > a
        erlaubter Typ des Operanden:
        - L3
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(f, L3)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal > f.internal)

# ---------------------------------------------------------
    def __init__(self, value=1, unit=_m3, n=""):
        """
        Initialisiert eine L3-Instanz.

        Aufruf: L3.__init__(value=1, unit=m3, n="")
        Parameter:
        - value: Wert der L3-Instanz;
                 Voreinstellung: 1
        - unit : eine zulässige L3-Maßeinheit;
                 Voreinstellung: m3
        - n    : Name der L3-Instanz;
                 Voreinstellung: leere Zeichenkette
        mögliche Fehlermeldung:
        - Unit ist hier nicht bekannt/zulässig"""
        
        global trennz
        
        if not (unit in _lengths3):
            raise ValueError(_fehler2 + str(unit))
        self.v = value
        self.u = unit
        self.internal = self.v * _lengths3[self.u]
        if n == "":
            self.name = "L3(" + str(_str_aus(self.v)) + trennz + self.u + ")"
        else:
            self.name = n
        L3Liste.append(self)

# ---------------------------------------------------------
    def __le__(self, f):
        """
        Realisiert den Vergleich <= in L3.

        Aufruf: a.__le__(a) oder a <= a
        erlaubter Typ des Operanden:
        - L3
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, L3)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal < f.internal) or (abs(self.internal - f.internal) <= eps)

# ---------------------------------------------------------
    def __lt__(self, f):
        """
        Realisiert den Vergleich < in L3.

        Aufruf: a.__lt__(a) oder a < a
        erlaubter Typ des Operanden:
        - L3
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(f, L3)):
            raise TypeError(_fehler3 + str(f))
        return (self.internal < f.internal)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert die Multiplikation einer L3-Instanz.

        Aufruf: a.__mul__(o) oder a * o
        mögliche Typen des Operanden:
        - - L1, L2, L3, T1, T2, TT, M, int, float, N, G, V, B, F1, W, P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]
        # lokale Hilfsvariable: b1, b2, name
        
        name = str(self) + " * (" + str(o) + ")"
        if typ(o) in ["int", "float"]:
            return L3(self.v * o, self.u, n=name)
        elif isinstance(o, N):
            return L3(self.v * o.v, self.u, n=name)
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "V", "B", "F1", "W", "P", "G"]:
            return G(self, mul, o, n=name)
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __ne__(self, f):
        """
        Realisiert den Vergleich != in L3.

        Aufruf: a.__ne__(a) oder a != a
        erlaubter Typ des Operanden:
        - L3
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(f, L3)):
            raise TypeError(_fehler3 + str(f))
        return abs(self.internal - f.internal) > eps

# ---------------------------------------------------------
    def __neg__(self):
        """
        Realisiert negatives Vorzeichen für eine L3-Instanz.

        Aufruf: a.__neg__() oder -(f)"""
        
        return L3(-self.v, self.u)

# ---------------------------------------------------------
    def __pos__(self):
        """
        Realisiert positives Vorzeichen für eine L3-Instanz.

        Aufruf: a.__pos__() oder +(f)"""
        
        return L3(self.v, self.u)

# ---------------------------------------------------------
    def __pow__(self, p):
        """
        Realisiert das Potenzieren einer L3-Instanz.

        Aufruf: a.__pow__(p) oder f ** p
        erlaubte Werte für p:
        - 0, 1, 1/3
        erlaubter Typ des Operanden p:
        - int, float
        mögliche Fehlermeldungen:
        - unsupported operand type(s) for ** or pow(): 'L3' and 'int'
        - Operand hat keinen zulässigen Typ."""
        
        global eps

        # lokale Hilfsvariable: name
       
        if not (isinstance(p, int) or isinstance(p, float)):
            raise TypeError(_fehler3 + str(p))
        name = str(self) + " ** (" + str(p) + ")"
        if abs(p) <= eps:
            return 1
        elif abs(p - 1) <= eps:
            return L3(self.v, self.u, n=name)
        elif abs(p - 1/3) <= eps:
            return L1(self.internal**(p), m, n=name)
        else:
            return NotImplemented

# ---------------------------------------------------------
    def __repr__(self):
        """
        Repräsentiert eine L3-Instanz.

        Aufruf: a.__repr__() oder repr(f)"""
        
        global trennz
        
        return "L3(" + _repr_aus(self.v) + trennz + self.u + ")"

# ---------------------------------------------------------
    def __str__(self):
        """
        Repräsentiert eine L3-Instanz.

        Aufruf: a.__str__() oder str(f)"""
        
        global trennz
        
        return "L3(" + _str_aus(self.v) + trennz + self.u + ")"

# ---------------------------------------------------------
    def __sub__(self, o):
        """
        Realisiert die Subtraktion zweier L3-Instanzen.

        Aufruf: a.__sub__(a) oder f - a
        erlaubter Typ des Operanden:
        - L3
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(o, L3)):
            raise TypeError(_fehler3 + str(o))
        name = str(self) + " - " + o.name
        return L3(self.internal - o.internal, _m3, n=name)

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert die Division einer L3-Instanz.

        Aufruf: a.__truediv__(o) oder f / o
        möglicher Typ des Operanden:
        - int, float, L1, L2, L3, T1, T2, M, N, TT, G, V, B, F1, W, P
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - Operand hat den Wert Null."""
        
        global eps
        
        # lokale Hilfsvariable: name
        
        name = str(self) + " / (" + str(o) + ")"
        if typ(o) in ["int", "float"]:
            if abs(o) <= eps:
                raise ValueError(_fehler4 + str(o))
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P"]:
            if abs(o.internal) <= eps:
                raise ValueError(_fehler4 + str(o))

        if typ(o) in ["int", "float"]:
            return L3(self.internal / o, self.u, n=name)         # L3/Skalar ---> L3
        elif isinstance(o, L1):
            return L2(self.internal / o.internal, _m2, n=name)   # L3/L1 ---> L2
        elif isinstance(o, L2):
            return L1(self.internal / o.internal, _m, n=name)    # L3/L2 ---> L1
        elif isinstance(o, L3):
            return self.internal / o.internal                    # L3/L3 ---> Skalar
        elif isinstance(o, N):
            return L3(self.internal / o.internal, self.u, n=name)# L3/N ---> L3
        elif typ(o) in ["T1", "T2", "M", "TT", "T1", "T2", "V", "B", "F1", "W", "P"]:
            return G(self, div, o, n=name)                       # L3/sonst ---> G
        else:
            raise TypeError(_fehler3 + str(o))

# ----------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse L3.

        Aufruf: L3.beispiel(e)
        für e kann "!=", "-", "*", "**", "/", "__add__", "__eq__", "__ge__",
        "__gt__", "__le__", "__lt__", "__mul__", "__ne__", "__neg__", "__pos__",
        "__pow__", "__repr__", "__str__", "__sub__", "__truediv__", "+", "<",
        "<=", "==", ">", ">=", "description", "info", "repr", "str", "to",
        "Vorzeichen -", "Vorzeichen +", leere Zeichenkette [Voreinstellung]
        angegeben werden"""
        
        print("""
        l11=L1(2,m);l12=L1(3,cm);l21=L2(4,mm2);l22=L2(5,km2);l31=L3(6,liter);
        l32=L3(7,dl);n1=N(2);n1=N(-3);t11=T1(8,s);t12=T1(9,h);t21=T2(10,s2);
        t22=T2(11,d2);m11=M(12,g);m12=M(13,kg);tt1=TT(14,C);tt2=TT(15,K);
        g1=G(l11,div,t11);g2=G(t11,mul,m1);i1=2;i2=(-5)""")
        l11=L1(2,_m);l12=L1(3,_cm);l21=L2(4,_mm2);l22=L2(5,_km2);l31=L3(6,_liter);l32=L3(7,_dl);n1=N(2);n1=N(-3);
        t11=T1(8,_s);t12=T1(9,_h);t21=T2(10,_s2);t22=T2(11,_d2);m11=M(12,_g);m12=M(13,_kg);tt1=TT(14,_C);tt2=TT(15,_K);
        g1=G(l11,div,t11);g2=G(t11,mul,m11);i1=2;i2=(-5)
        if e in ["","__add__", "+"]:                                               # __add__
            print("__add__ oder +",L3.__add__.__doc__)
            for f in [l32]: print(_qqq+str(l31)+"+" +str(f)+" --> ", l31+f)
        if e in ["","__eq__", "=="]:                                               # __eq__
            print("__eq__ oder ==",L3.__eq__.__doc__)
            for f in [l32]: print(_qqq+str(l31)+"==" +str(f)+" --> ", l31==f)
        if e in ["","__ge__", ">="]:                                               # __ge__
            print("__ge__ oder >=",L3.__ge__.__doc__)
            for f in [l32]: print(_qqq+str(l31)+">=" +str(f)+" --> ", l31>=f)
        if e in ["","__gt__", ">"]:                                                # __gt__
            print("__gt__ oder >",L3.__gt__.__doc__)
            for f in [l32]: print(_qqq+str(l31)+">" +str(f)+" --> ", l31>f)
        if e in ["","__le__", "<="]:                                               # __le__
            print("__le__ oder <=",L3.__le__.__doc__)
            for f in [l32]: print(_qqq+str(l31)+"<=" +str(f)+" --> ", l31<=f)
        if e in ["","__lt__", "<"]:                                                # __lt__
            print("__lt__ oder <",L3.__lt__.__doc__)
            for f in [l32]: print(_qqq+str(l31)+"<" +str(f)+" --> ", l31<f)
        if e in ["","__mul__", "*"]:                                               # __mul__
            print("__mul__ oder *",L3.__mul__.__doc__)
            for f in [i1,l11,l32,l21,l31,n1,t11,t21,m11,tt1,g1,g2]: print(_qqq+str(l31)+"*" +str(f)+" --> ", l31*f)
        if e in ["","__ne__", "!="]:                                               # __ne__
            print("__ne__ oder !=",L3.__ne__.__doc__)
            for f in [l32]: print(_qqq+str(l31)+"!=" +str(f)+" --> ", l31!=f)
        if e in ["","__neg__", "Vorzeichen -"]:                                    # __neg__
            print("__neg__ oder Vorzeichen -",L3.__neg__.__doc__)
            print(_qqq+"-"+str(l31)+ " --> ", -l31)
        if e in ["","__pos__", "Vorzeichen +"]:                                    # __pos__
            print("__pos__ oder Vorzeichen +",L3.__pos__.__doc__)
            print(_qqq+"+"+str(l31)+ " --> ", +l31)
        if e in ["","__pow__", "**"]:                                              # __pow__
            print("__pow__ oder **",L3.__pow__.__doc__)
            print(_qqq+str(l31)+"**0 --> ", l31**0)
            print(_qqq+str(l32)+"**1 --> ", l32**1)
        if e in ["","__repr__", "repr"]:                                           # __repr__
            print("__repr__ oder repr",L3.__repr__.__doc__)
            print(_qqq+"repr(l31), repr(l32) --> ", repr(l31), repr(l32))
        if e in ["","__str__", "str"]:                                             # __str__
            print("__str__ oder str",L3.__str__.__doc__)
            print(_qqq+"str(l31), str(l32) --> ", str(l31), str(l32))
        if e in ["","__sub__", "-"]:                                               # __sub__
            print("__sub__ oder -",L3.__sub__.__doc__)
            for f in [l32]: print(_qqq+str(l31)+"-" +str(f)+" --> ", l31-f)
        if e in ["","__truediv__", "/"]:                                           # __truediv__
            print("__truediv__ oder /",L3.__truediv__.__doc__)
            for f in [i1,l11,l32,l21,l31,n1,t11,t21,m11,tt1]: print(_qqq+str(l31)+"/" +str(f)+" --> ", l31/f)
        if e in ["","description"]:                                                # description
            print("description",L3.description.__doc__)
            print(_qqq+"L3.description() --> ", L3.description())
        if e in ["","info"]:                                                       # info
            print("info",L3.info.__doc__)
            print(_qqq+str(l31)+".info() --> ");l31.info()
            print(_qqq+str(l32)+".info(lang) --> ");l32.info(lang)
        if e in ["","to"]:                                                         # to
            print("to",L3.to.__doc__)
            print(_qqq+str(l31)+".to(km3) --> ",l31.to(_km3))
            print(_qqq+str(l32)+".to(mm3) --> ",l32.to(_mm3))

# ----------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse L3 und ihren Methoden aus.

        Aufruf: L3.classInfo(m=art) oder L3.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles     : alles [Voreinstellung]
        + "H"/Kopf      : globale Informationen
        + "V"/Variablen : Variablen/Eigenschaften
        + "M"/Methoden  : Methoden
        + "E"/Einheiten : Einheiten"""
        
        # lokale Hilfsvariable: s1, s2, s3
        
        s1 = "L3."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class L3\n", L3.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der L3-Instanzen:

    l.v        Wert der Instanz (gemessen in l.u)
    l.u        Maßeinheit der Instanz (L3-Maßeinheit)
    l.name     Name der Instanz
    l.internal interner Wert
    """)
        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(L3):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)
        if m in ["A", "E"]:
            print('Einheiten\n')
            au("L3")

# ---------------------------------------------------------
    def description():
        """
        Liefert eine Kurzbeschreibung der Klasse L3.

        Aufruf: description()"""
        
        return "Operationen mit L3-Instanzen (Volumenmaße)"

# ---------------------------------------------------------
    def info(self, m=kurz):
        """
        Gibt Informationen über eine L3-Instanz aus.

        Aufruf: a.info(m)
        m Modus
          kurz  nur Grund-Eigenschaften
                [Voreinstellung]
          lang  auch Darstellung in anderen Einheiten"""

        # lokale Hilfsvariable: mm, mmm, ss, sss
        
        ss  = _str_aus(self.v)
        sss = _str_aus(self.internal)
        print("Name         :", self.name)
        print("Art          :", "L3-Instanz (Volumenmaß)")
        print("Wert         :", ss, "(in " + self.u + ")")
        print("Einheit      :", self.u, "["+_descript[self.u]+"]")
        print("interner Wert:", sss, "(in m3)")
        if m == lang:
            print("Darstellung in anderen Einheiten:")
            for f in sorted(_lengths3):
                mm  = self.to(f)
                mmm = _str_aus(mm.v)
                print(leer, f.ljust(5), str(mmm).ljust(17), "(" + _descript[f] + ")")
        print(_q)

# ---------------------------------------------------------
    def to(self, unit):
        """
        Realisiert die Konvertierung einer L3-Instanz in eine andere Maßeinheit.

        Aufruf: a.to(u)
        erlaubter Typ des Operanden:
        - eine der zulässigen L3-Maßeinheiten
        mögliche Fehlermeldung:
        - Unit ist hier nicht bekannt/zulässig"""
        
        # lokale Hilfsvariable: z, name
        
        if not (unit in _lengths3):
            raise ValueError(_fehler2 + str(unit))
        z = self.internal / _lengths3[unit]
        name = str(self) + "--->" + unit
        return L3(z, unit, n=name)

    ci = classInfo # Alias für classInfo()

# =========================================================
class M:
    """
    Realisiert das Rechnen mit M-Instanzen (Gewichtsmaße).

    Aufruf: M.__init__(value=1, unit=kg, n="")

    Parameter:

    value=1 : Wert;
              Voreinstellung: 1
    unit=kg : M-Maßeinheit;
              Voreinstellung: kg
    n=""    : Name der M-Instanz;
              Voreinstellung: leere Zeichenkette

    Methoden:

    m : M-Instanz (Gewicht)
    n : Zahl(Integer/Float)
    p : Integer
    o : Instanz
    u : eine der zulässigen M-Maßeinheiten

    m.__abs__() oder abs(m)    Liefert den Absolut-Betrag der M-Instanz.
    m.__add__(m) oder m + m    Realisiert die Addition zweier M-Instanzen.
    m.__eq__(m) oder m == m    Realisiert den Vergleich == in M.
    m.__ge__(m) oder m >= m    Realisiert den Vergleich >= in M.
    m.__gt__(m) oder m > m     Realisiert den Vergleich > in M.
    M.__init__(value=1,unit=kg,n="") Initialisiert eine M-Instanz.
    m.__le__(m) oder m <= m    Realisiert den Vergleich <= in M.
    m.__lt__(m) oder m < m     Realisiert den Vergleich < in M.
    m.__mul__(o) oder m * o    Realisiert die Multiplikation einer M-Instanz.
    m.__ne__(m) oder m != m    Realisiert den Vergleich != in M.
    m.__neg__() oder -(m)      Realisiert negatives Vorzeichen in M.
    m.__pos__() oder +(m)      Realisiert positives Vorzeichen in M.
    m.__pow__(p) oder m ** p   Realisiert das Potenzieren einer M-Instanz.
    m.__repr__() oder repr(m)  Repräsentiert eine M-Instanz.
    m.__str__() oder str(m)    Repräsentiert eine M-Instanz.
    m.__sub__(m) oder m - m    Realisiert die Subtraktion zweier M-Instanzen.
    m.__truediv__(o) oder m / o Realisiert die Division einer M-Instanz.
    M.beispiel(e)              Liefert Beispiele für die Methoden der Klasse M.
    M.classInfo(m=art)         Gibt Informationen zur Klasse M und ihre Methoden
                               aus.
    M.ci(m=art)                Alias für M.classInfo(m=art)
    M.description()            Gibt eine Kurzbeschreibung der Klasse M aus.
    m.info(modus)              Gibt Informationen über eine M-Instanz aus.
    m.to(u)                    Realisiert die Konvertierung einer M-Instanz in
                               eine andere Maßeinheit.
    m.toLongweights()          Liefert lton, cwt, qu, stone, lb, oz, dr, grain
                               der aktuellen Instanz als Liste.
"""

    global eps, trennz

# ---------------------------------------------------------
    def __abs__(self):
        """
        Liefert den Absolut-Betrag der M-Instanz.

        Aufruf: m.__abs__() oder abs(m)"""
        
        name = "abs(" + str(self) + ")"
        return M(abs(self.v), self.u, n=name)

# ---------------------------------------------------------
    def __add__(self, m):
        """
        Realisiert die Addition zweier M-Instanzen.

        Aufruf: m.__add__(m) oder m + m
        erlaubter Typ des Operanden:
        - M
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(m, M)):
            raise TypeError(_fehler3 + str(m))
        name = str(self) + " + " + m.name
        return M(self.internal + m.internal, _kg, n=name)

# ---------------------------------------------------------
    def __eq__(self, m):
        """
        Realisiert den Vergleich == in M.

        Aufruf: m.__eq__(m) oder m == m
        erlaubter Typ des Operanden:
        - M
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(m, M)):
            raise TypeError(_fehler3 + str(m))
        return abs(self.internal - m.internal) <= eps

# ---------------------------------------------------------
    def __ge__(self, m):
        """
        Realisiert den Vergleich >= in M.

        Aufruf: m.__ge__(m) oder m >= m
        erlaubter Typ des Operanden:
        - M
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(m, M)):
            raise TypeError(_fehler3 + str(m))
        return (self.internal > m.internal) or (abs(self.internal - m.internal) <= eps)

# ---------------------------------------------------------
    def __gt__(self, m):
        """
        Realisiert den Vergleich > in M.

        Aufruf: m.__gt__(m) oder m > m
        erlaubter Typ des Operanden:
        - M
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(m, M)):
            raise TypeError(_fehler3 + str(m))
        return (self.internal > m.internal)

# ---------------------------------------------------------
    def __init__(self, value=1, unit=_kg, n=""):
        """
        Initialisiert eine M-Instanz.

        Aufruf: M.__init__(value=1, unit=kg, n="")
        Parameter:
        - value: Wert der M-Instanz;
                 Voreinstellung: 1
        - unit : eine zulässige M-Maßeinheit;
                 Voreinstellung: kg
        - n    : Name der M-Instanz;
                 Voreinstellung: leere Zeichenkette
        mögliche Fehlermeldung:
        - Unit ist hier nicht bekannt/zulässig"""
        
        global trennz
        
        if not (unit in _gewichte):
            raise ValueError(_fehler2 + str(unit))
        self.v = value
        self.u = unit
        self.internal = self.v * _gewichte[self.u]
        if n == "":
            self.name = "M(" + str(_str_aus(self.v)) + trennz + self.u + ")"
        else:
            self.name = n
        MListe.append(self)

# ---------------------------------------------------------
    def __le__(self, m):
        """
        Realisiert den Vergleich <= in M.

        Aufruf: m.__le__(m) oder m <= m
        erlaubter Typ des Operanden:
        - M
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(m, M)):
            raise TypeError(_fehler3 + str(m))
        return (self.internal < m.internal) or (abs(self.internal - m.internal) <= eps)

# ---------------------------------------------------------
    def __lt__(self, m):
        """
        Realisiert den Vergleich < in M.

        Aufruf: m.__lt__(m) oder m < m
        erlaubter Typ des Operanden:
        - M
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(m, M)):
            raise TypeError(_fehler3 + str(m))
        return (self.internal < m.internal)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert die Multiplikation einer M-Instanz.

        Aufruf: m.__mul__(o) oder m * o
        mögliche Typen des Operanden:
        - - L1, L2, L3, T1, T2, TT, M, int, float, N, G, V, B, F1, W, P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]
        # lokale Hilfsvariable: name
        
        name = str(self) + " * (" + str(o) + ")"
        if typ(o) in ["int", "float"]:
            return M(self.v * o, self.u, n=name)
        elif isinstance(o, N):
            return M(self.v * o.v, self.u, n=name)
        elif isinstance(o, B): 
            zwi = G(self, mul, N(1)) * o
            return newton(zwi.internal, n=name)
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "V", "F1", "W", "P", "G"]:
            return G(self, mul, o, n=name)
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __ne__(self, m):
        """
        Realisiert den Vergleich != in M.

        Aufruf: m.__ne__(m) oder m != m
        erlaubter Typ des Operanden:
        - M
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(m, M)):
            raise TypeError(_fehler3 + str(m))
        return abs(self.internal - m.internal) > eps

# ---------------------------------------------------------
    def __neg__(self):
        """
        Realisiert negatives Vorzeichen für eine M-Instanz.

        Aufruf: m.__neg__() oder -(m)"""
        
        return M(-self.v, self.u)

# ---------------------------------------------------------
    def __pos__(self):
        """
        Realisiert positives Vorzeichen für eine M-Instanz.

        Aufruf: m.__pos__() oder +(m)"""
        
        return M(self.v, self.u)

# ---------------------------------------------------------
    def __pow__(self, p):
        """
        Realisiert das Potenzieren einer M-Instanz.

        Aufruf: m.__pow__(p) oder m ** p
        erlaubter Typ des Operanden p:
        - int, float
        erlaubte Werte für p:
        - 0, 1
        mögliche Fehlermeldungen:
        - unsupported operand type(s) for ** or pow(): 'M' and 'int'
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(p, int) or isinstance(p, float)):
            raise TypeError(_fehler3 + str(p))
        name = str(self) + " ** (" + str(p) + ")"
        if abs(p) <= eps:
            return 1
        elif abs(p - 1) <= eps:
            return M(self.v, self.u, n=name)
        else:
            return NotImplemented

# ---------------------------------------------------------
    def __repr__(self):
        """
        Repräsentiert eine M-Instanz.

        Aufruf: m.__repr__() oder repr(m)"""
        
        global trennz
        
        return "M(" + _repr_aus(self.v) + trennz + self.u + ")"

# ---------------------------------------------------------
    def __str__(self):
        """
        Repräsentiert eine M-Instanz.

        Aufruf: m.__str__() oder str(m)"""
        
        global trennz
        
        return "M(" + _str_aus(self.v) + trennz + self.u + ")"

# ---------------------------------------------------------
    def __sub__(self, m):
        """
        Realisiert die Subtraktion zweier M-Instanzen.

        Aufruf: m.__sub__(m) oder m - m
        erlaubter Typ des Operanden:
        - M
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(m, M)):
            raise TypeError(_fehler3 + str(m))
        name = str(self) + " - " + m.name
        return M(self.internal - m.internal, _kg, n=name)

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert die Division einer M-Instanz.

        Aufruf: m.__truediv__(o) oder m / o
        möglicher Typ des Operanden:
        - int, float, N, M, L1, L2, L3, T1, T2, TT, V, B, F1, W, P
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - Operand hat den Wert Null."""
        
        global eps
        
        # lokale Hilfsvariable: name
        
        name = str(self) + " / (" + str(o) + ")"

        if typ(o) in ["int", "float"]:
            if abs(o) <= eps:
                raise ValueError(_fehler4 + str(o))
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P"]:
            if abs(o.internal) <= eps:
                raise ValueError(_fehler4 + str(o))

        if typ(o) in ["int", "float"]:
            return M(self.internal / o, self.u, n=name)          # M/Skalar ---> M
        elif isinstance(o, M):
            return self.internal / o.internal                    # M/M ---> Skalar
        elif isinstance(o, N):
            return M(self.internal / o.internal, self.u, n=name) # M/N ---> M
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "TT", "T1", "T2", "V", "B", "F1", "W", "P"]:
            return G(self, div, o, n=name)                       # M/sonst ---> Skalar
        else:
            raise TypeError(_fehler3 + str(o))

# ----------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse M.

        Aufruf: M.beispiel(e)
        für e kann
        "!=", "-", "*", "**", "/", "__add__", "__eq__", "__ge__", "__gt__",
        "__le__", "__lt__", "__mul__", "__ne__", "__neg__", "__pos__",
        "__pow__", "__repr__", "__str__", "__sub__", "__truediv__", "+", "<",
        "<=", "==", ">", ">=", "description", "info", "repr", "str", "to",
        "toLongweights", "Vorzeichen -", "Vorzeichen +", leere Zeichenkette
        [Voreinstellung] angegeben werden"""
        
        print("""
        l11=L1(2,m);l12=L1(3,cm);l21=L2(4,mm2);l22=L2(5,km2);l31=L3(6,liter);
        l32=L3(7,dl);n1=N(2);n1=N(-3);t11=T1(8,s);t12=T1(9,h);t21=T2(10,s2);
        t22=T2(11,d2);m11=M(12,g);m12=M(13,kg);tt1=TT(14,C);tt2=TT(15,K);#
        g1=G(l11,div,t11);g2=G(t11,mul,m1);i1=2;i2=(-5)""")
        l11=L1(2,_m);l12=L1(3,_cm);l21=L2(4,_mm2);l22=L2(5,_km2);l31=L3(6,_liter);l32=L3(7,_dl);n1=N(2);n1=N(-3);
        t11=T1(8,_s);t12=T1(9,_h);t21=T2(10,_s2);t22=T2(11,_d2);m11=M(12,_g);m12=M(13,_kg);tt1=TT(14,_C);tt2=TT(15,_K);
        g1=G(l11,div,t11);g2=G(t11,mul,m11);i1=2;i2=(-5)
        if e in ["","__add__", "+"]:                                               # __add__
            print("__add__ oder +",M.__add__.__doc__)
            for f in [m12]: print(_qqq+str(m11)+"+" +str(f)+" --> ", m11+f)
        if e in ["","__eq__", "=="]:                                               # __eq__
            print("__eq__ oder ==",M.__eq__.__doc__)
            for f in [m12]: print(_qqq+str(m11)+"==" +str(f)+" --> ", m11==f)
        if e in ["","__ge__", ">="]:                                               # __ge__
            print("__ge__ oder >=",M.__ge__.__doc__)
            for f in [m12]: print(_qqq+str(m11)+">=" +str(f)+" --> ", m11>=f)
        if e in ["","__gt__", ">"]:                                                # __gt__
            print("__gt__ oder >",M.__gt__.__doc__)
            for f in [m12]: print(_qqq+str(m11)+">" +str(f)+" --> ", m11>f)
        if e in ["","__le__", "<="]:                                               # __le__
            print("__le__ oder <=",M.__le__.__doc__)
            for f in [m12]: print(_qqq+str(m11)+"<=" +str(f)+" --> ", m11<=f)
        if e in ["","__lt__", "<"]:                                                # __lt__
            print("__lt__ oder <",M.__lt__.__doc__)
            for f in [m12]: print(_qqq+str(m11)+"<" +str(f)+" --> ", m11<f)
        if e in ["","__mul__", "*"]:                                               # __mul__
            print("__mul__ oder *",M.__mul__.__doc__)
            for f in [i1,l11,l21,l31,n1,t11,t21,m11,tt1,tt2,g1,g2]: print(_qqq+str(m11)+"*" +str(f)+" --> ", m11*f)
        if e in ["","__ne__", "!="]:                                               # __ne__
            print("__ne__ oder !=",M.__ne__.__doc__)
            for f in [m12]: print(_qqq+str(m11)+"!=" +str(f)+" --> ", m11!=f)
        if e in ["","__neg__", "Vorzeichen -"]:                                    # __neg__
            print("__neg__ oder Vorzeichen -",M.__neg__.__doc__)
            print(_qqq+ "-"+str(m11)+" --> ", -m11)
        if e in ["","__pos__", "Vorzeichen +"]:                                    # __pos__
            print("__pos__ oder Vorzeichen +",M.__pos__.__doc__)
            print(_qqq+"+"+str(m11)+" --> ", +m11)
        if e in ["","__pow__", "**"]:                                              # __pow__
            print("__pow__ oder **",M.__pow__.__doc__)
            print(_qqq+str(m11)+"**1 --> ", m11**1)
            print(_qqq+str(m12)+"**0 --> ", m12**0)
        if e in ["","__repr__", "repr"]:                                           # __repr__
            print("__repr__ oder repr",M.__repr__.__doc__)
            print(_qqq+"repr(m11), repr(m12) --> ", repr(m11), repr(m12))
        if e in ["","__str__", "str"]:                                             # __str__
            print("__str__ oder str",M.__str__.__doc__)
            print(_qqq+"str(m11), str(m12) --> ", str(m11), str(m12))
        if e in ["","__sub__", "-"]:                                               # __sub__
            print("__sub__ oder -",M.__sub__.__doc__)
            for f in [m12]: print(_qqq+str(m11)+"-" +str(f)+" --> ", m11-f)
        if e in ["","__truediv__", "/"]:                                           # __truediv__
            print("__truediv__ oder /",M.__truediv__.__doc__)
            for f in [i1,l11,l21,l31,n1,t11,t21,m12,tt1,tt2]: print(_qqq+str(m12)+"/" +str(f)+" --> ", m12/f)
        if e in ["","description"]:                                                # description
            print("description",M.description.__doc__)
            print(_qqq+"M.description() --> ", M.description())
        if e in ["","info"]:                                                       # info
            print("info",M.info.__doc__)
            print(_qqq+str(m11)+".info() --> ");m11.info()
            print(_qqq+str(m12)+".info(lang) --> ");m12.info(lang)
        if e in ["","to"]:                                                         # to
            print("to",M.to.__doc__)
            print(_qqq+str(m11)+".to(kg) --> ",m11.to(_kg))
            print(_qqq+str(m12)+".to(t) --> ",m12.to(_t))
        if e in ["","toLongweights"]:                                             # toLongweights
            print("toLongweights",M.toLongweights.__doc__)
            print(_qqq+str(M(2,_t))+".toLongweights() --> ",M(2,_t).toLongweights())
            print(_qqq+"("+str(M(1,cwt))+"+"+str(M(1,lb))+").toLongweights() --> ",(M(1,_cwt)+M(1,_lb)).toLongweights())

# ----------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse M und ihre Methoden aus.

        Aufruf: M.classInfo(m=art) oder M.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles    : alles [Voreinstellung]
        + "H"/Kopf     : globale Informationen
        + "V"/Variablen: Variablen/Eigenschaften
        + "M"/Methoden : Methoden
        + "E"/Einheiten; Einheiten"""
        
        # lokale Hilfsvariable: s1, s2, s3
        
        s1 = "M."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class M\n", M.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der M-Instanzen:

    m.v        Wert der Instanz (gemessen in m.u)
    m.u        Maßeinheit der Instanz (M-Maßeinheit)
    m.name     Name der Instanz
    m.internal interner Wert
    """)
        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(M):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)
        if m in ["A", "E"]:
            print('Einheiten\n')
            au("M")

# ---------------------------------------------------------
    def description():
        """
        Liefert eine Kurzbeschreibung der Klasse M.

        Aufruf: description()"""
        
        return "Operationen mit M-Instanzen  (Gewichtsmaße)"

# ---------------------------------------------------------
    def info(self, m=kurz):
        """
        Gibt Informationen über eine M-Instanz aus.

        Aufruf: m.info(modus)
        m Modus
          kurz  nur Grund-Eigenschaften
                [Voreinstellung]
          lang  auch Darstellung in anderen Einheiten"""

        # lokale Hilfsvariable: mm, mmm, ss, sss
        
        ss  = _str_aus(self.v)
        sss = _str_aus(self.internal)
        print("Name         :", self.name)
        print("Art          :", "M-Instanz (Gewicht)")
        print("Wert         :", ss, "(in " + self.u + ")")
        print("Einheit      :", self.u, "["+_descript[self.u]+"]")
        print("interner Wert:", sss, "(in kg)")
        if m == lang:
            print("Darstellung in anderen Einheiten:")
            for f in sorted(_gewichte, key=str.lower):
                mm  = self.to(f)
                mmm = _str_aus(mm.v)
                print(leer, f.ljust(7), str(mmm).ljust(22), "(" + _descript[f] + ")")
        print(_q)

# ---------------------------------------------------------
    def to(self, unit):
        """
        Realisiert die Konvertierung einer M-Instanz in eine andere Maßeinheit.

        Aufruf: m.to(u)
        erlaubter Typ des Operanden:
        - eine der zulässigen M-Maßeinheiten
        mögliche Fehlermeldung:
        - Unit ist hier nicht bekannt/zulässig"""
        
        # lokale Hilfsvariable: z, name
        
        if not (unit in _gewichte):
            raise ValueError(_fehler2 + str(unit))
        z = self.internal / _gewichte[unit]
        name = str(self) + "--->" + unit
        return M(z, unit, n=name)

# ---------------------------------------------------------
    def toLongweights(self):
        """
        Liefert lton, cwt, qu, stone, lb, oz, dr, grain der aktuellen Instanz als
        Liste.

        Aufruf: t.toLongweights()"""
        
        #lokale Variable: ll, zz, zlton, zcwt, zqu, zstone, zlb, zounce, zdrain, zgrain
        
        ll     = [0, 0, 0, 0, 0, 0, 0, 0]
        vorz   = sign(self.internal)
        zz     = abs(self.internal/_gewichte[_grain]) # jetzt alles in grain-Einheiten
        zlton  = 15680000
        zcwt   = 784000
        zqu    = 196000
        zstone = 98000
        zlb    = 7000
        zounce = 437.5
        zdrain = 27.34375
        zgrain = _gewichte[_grain]
        ll[0] = M(int(zz // zlton), _lton) * vorz;   zz = zz % zlton;
        ll[1] = M(int(zz // zcwt), _cwt) * vorz;     zz = zz % zcwt;
        ll[2] = M(int(zz // zqu), _qu) * vorz;       zz = zz % zqu;
        ll[3] = M(int(zz // zstone), _stone) * vorz; zz = zz % zstone;
        ll[4] = M(int(zz // zlb), _lb) * vorz;       zz = zz % zlb;
        ll[5] = M(int(zz // zounce), _oz) * vorz;    zz = zz % zounce;
        ll[6] = M(int(zz // zdrain), _dr) * vorz;    zz = zz % zdrain;
        ll[7] = M(zz, _grain) * vorz
        return ll

    ci = classInfo # Alias für classInfo()

# =========================================================
class N:
    """
    Realisiert den linksseitigen Operator (*, /) für (int, float, L1, L2, L3, M,
    T1, T2, TT, N, U, V, B, F1, W, P).

    Aufruf: N.__init__(value=1, n='')

    n : N-Instanz
    o : Instanz
    p : Zahl (int, Float)

    n.__abs__() oder abs(n)   Liefert den Absolut-Betrag der N-Instanz.
    n.__add__(n) oder n + n   Realisiert die Addition zweier N-Instanzen in N.
    n.__eq__(n)               Realisiert den Vergleich == in N.
    n.__ge__(n)               Realisiert den Vergleich >= in N.
    n.__gt__(n)               Realisiert den Vergleich > in N.
    N.__init__(value, n='')   Initialisiert eine N-Instanz in N.
    n.__le__(n)               Realisiert den Vergleich <= in N.
    n.__lt__(n)               Realisiert den Vergleich < in N.
    n.__mul__(o) oder n * o   Realisiert die Multiplikation mit einem Operanden
                              in N.
    n.__ne__(n)               Realisiert den Vergleich != in N.
    n.__neg__(n) oder -(n)    Realisiert negatives Vorzeichen für eine N-Instanz.
    n.__pos__(n) oder +(n)    Realisiert positives Vorzeichen für eine N-Instanz.
    n.__pow__(p) oder t ** p  Realisiert das Potenzieren von N-Instanzen.
    n.__repr__() oder repr(n) Repräsentiert eine N-Instanz.
    n.__str__() oder str(n)   Repräsentiert eine N-Instanz.
    n.__sub__(n) oder n - n   Realisiert die Subtraktion zweier N-Instanzen
    n.__truediv__(o) oder n / o Realisiert die Divion durch einen Operanden in N.
    N.beispiel(e)             Liefert Beispiele für die Methoden der Klasse N.
    N.classInfo(m=art)        Gibt Informationen zur Klasse N und ihre Methoden
                              aus.
    N.ci(m=art)               Alias für N.classInfo(m=art)
    N.description()           Kurzbeschreibung der Klasse N.
    n.info()                  Gibt Informationen über eine N-Instanz aus.
"""

    global eps, trennz

# ---------------------------------------------------------
    def __abs__(self):
        """
        Liefert den Absolut-Betrag der N-Instanz.

        Aufruf: n.__abs__() oder abs(n)"""
        name = "abs(" + str(self) + ")"
        return N(abs(self.v), n=name)
                 
# ---------------------------------------------------------
    def __add__(self, n):
        """
        Realisiert die Addition zweier N-Instanzen.

        Aufruf: n.__add__(n) oder n + n
        erlaubter Typ des Operanden:
        - N
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(n, N)):
            raise TypeError(_fehler3 + str(n))
        name = str(self) + " + " + n.name
        return N(self.v + n.v, n=name)

# ---------------------------------------------------------
    def __eq__(self, n):
        """
        Realisiert den Vergleich == in N.

        Aufruf: n.__eq__(n) oder n == n
        erlaubter Typ des Operanden:
        - N
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(n, N)):
            raise TypeError(_fehler3 + str(n))
        return abs(self.v - n.v) <= eps

# ---------------------------------------------------------
    def __ge__(self, n):
        """
        Realisiert den Vergleich >= in N.

        Aufruf: n.__ge__(n) oder n >= n
        erlaubter Typ des Operanden:
        - N
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(n, N)):
            raise TypeError(_fehler3 + str(n))
        return (self.v > n.v) or (abs(self.v - n.v) <= eps)

# ---------------------------------------------------------
    def __gt__(self, n):
        """
        Realisiert den Vergleich > in N.

        Aufruf: n.__gt__(n) oder n > n
        erlaubter Typ des Operanden:
        - N
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        if not (isinstance(n, N)):
            raise TypeError(_fehler3 + str(n))
        return (self.v > n.v)

# ---------------------------------------------------------
    def __init__(self, value=1, n=""):
        """
        Initialisiert eine N-Instanz.

        Aufruf: N.__init__(value, n='')"""
        
        self.v        = value
        self.internal = value
        if n != "":
            self.name = n
        else:
            self.name ="N(" + str(_str_aus(self.v)) + ")"
        NListe.append(self)

# ---------------------------------------------------------
    def __le__(self, n):
        """
        Realisiert den Vergleich <= in N.

        Aufruf: n.__le__(n) oder n <= n
        erlaubter Typ des Operanden:
        - N
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(n, N)):
            raise TypeError(_fehler3 + str(n))
        return (self.v < n.v) or (abs(self.v - n.v) <= eps)

# ---------------------------------------------------------
    def __lt__(self, n):
        """
        Realisiert den Vergleich < in N.

        Aufruf: n.__lt__(n) oder n < n
        erlaubter Typ des Operanden:
        - N
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(n, N)):
            raise TypeError(_fehler3 + str(n))
        return (self.v < n.v)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert die Multiplikation in N.

        Aufruf: n.__mul__(o) oder n * o.
        mögliche Typen des Operanden:
        - L1, L2, L3, T1, T2, TT, M, int, float, N, G, V, B, F1, W, P
        mögliche Fehlermeldungen:
        - Unit ist hier nicht bekannt/zulässig
        - Parameter hat unzulässigen Wert"""
        
        # typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]
        # lokale Hilfsvariable: name
        
        name = str(self) + " * " + str(o)
        if typ(o) in ["int", "float"]:
            return self.v * o
        elif isinstance(o, N):
            return N(self.v * o.v, n=name)
        elif isinstance(o, V):
            return V(o.links * self.v, o.rechts, n=name)
        elif isinstance(o, B):
            return B(o.links * self.v, o.rechts, n=name)
        elif isinstance(o, F1):
            return newton(o.internal * self.v, n=name)
        elif isinstance(o, W):
            return joule(o.internal * self.v, n=name)
        elif isinstance(o, P):
            return watt(o.internal * self.v, n=name)
        elif isinstance(o, G):
            return G(self, mul, o, n=name)
        elif isinstance(o, L1):
            return L1(self.v * o.v, o.u, n=name)
        elif isinstance(o, L2):
            return L2(self.v * o.v, o.u, n=name)
        elif isinstance(o, L3):
            return L3(self.v * o.v, o.u, n=name)
        elif isinstance(o, M):
            return M(self.v * o.v, o.u, n=name)
        elif isinstance(o, U):
            zwi  = T1(o.internal * self.v, _s)
            zwi2 = zwi.toYMD()
            if abs(zwi2[2].v) > 0:
                raise ValueError(_fehler6 + str(o) + " (ergibt mehr als 24h)")
            del zwi
            return U(zwi2[3].v, zwi2[4].v, zwi2[5].v, n=name)
        elif isinstance(o, T1):
            return T1(self.v * o.v, o.u, n=name)
        elif isinstance(o, T2):
            return T2(self.v * o.v, o.u, n=name)
        elif isinstance(o, TT):
            if o.u == _K:
                return TT(self.v * o.internal, _K, n=name)
            else:
                raise ValueError(_fehler2 + o.u)
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __ne__(self, n):
        """
        Realisiert den Vergleich != in N.

        Aufruf: n.__ne__(n) oder n != n
        erlaubter Typ des Operanden:
        - N
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(n, N)):
            raise TypeError(_fehler3 + str(n))
        return abs(self.v - n.v) > eps

# ---------------------------------------------------------
    def __neg__(self):
        """
        Realisiert negatives Vorzeichen für eine N-Instanz.

        Aufruf: n.__neg__() oder -(n)"""
        return N(-self.v)

# ---------------------------------------------------------
    def __pos__(self):
        """
        Realisiert positives Vorzeichen für eine N-Instanz.

        Aufruf: n.__pos__() oder +(n)"""
        
        return N(self.v)

# ---------------------------------------------------------
    def __pow__(self, p):
        """
        Realisiert das Potenzieren von N-Instanzen.

        Aufruf: n.__pow__(p) oder N ** p
        erlaubter Typ des Opreranden:
        - int, float
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(p, int) or isinstance(p, float)):
            raise TypeError(_fehler3 + str(n))
        name = str(self) + " ** " + str(p)
        return N(self.v**p, n=name)

# ---------------------------------------------------------
    def __repr__(self):
        """
        Repräsentiert eine N-Instanz.

        Aufruf: n.__repr__() oder repr(n)"""
        
        return "N(" + _repr_aus(self.v) + ")"

# ---------------------------------------------------------
    def __str__(self):
        """
        Repräsentiert eine N-Instanz.

        Aufruf: n.__str__() oder str(n)"""
        
        return "N(" + _str_aus(self.v) + ")"

# ---------------------------------------------------------
    def __sub__(self, n):
        """
        Realisiert die Subtraktion zweier N-Instanzen.

        Aufruf: n.__sub__(n) oder n - n
        erlaubter Typ des Operanden:
        - N
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(n, N)):
            raise TypeError(_fehler3 + str(t))
        name = str(self) + " - " + n.name
        return N(self.v - n.v, n=name)

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert die Divion durch einen Operanden in N.

        Aufruf: n.__truediv__(o) oder n / o.
        möglicher Typ des Operanden:
        - L1, L2, L3, T1, T2, M, TT, T1, T2, G, V, B, F1, W, P
        mögliche Fehlerfmeldung:
        - Operand hat den Wert Null
        - Operand hat keinen zulässigen Typ"""
        
        global eps
        
        # lokale Hilfsvariable: name
        
        name = str(self) + " / " + "( " + str(o) + " )"
        if typ(o) in ["int", "float"]:
            if abs(o) <= eps:
                raise ValueError(_fehler4 + str(o))
        else:
            if abs(o.internal) <= eps:
                raise ValueError(_fehler4 + str(o))
            
        if typ(o) in ["int", "float"]:
            return self.internal / o                     # N/Skalar ---> Skalar
        elif isinstance(o, N):
            return N(self.internal / o.internal, n=name) # N/N ---> N
        elif isinstance(o, V) or isinstance(o, B) or isinstance(o, F1) or isinstance(o, W) or isinstance(o, P):
            return G(N(self.v), div, o, n=name)          # N/(V, B, F1, W, P) ---> G
        elif isinstance(o, G):
            return G(N(self.v), div, o, n=name)          # N/G ---> G
        elif isinstance(o, L1) or isinstance(o, L2) or isinstance(o, L3):
            return G(N(self.v), div, o, n=name)          # N/(L1, L2 oder L3) ---> G
        elif isinstance(o, M):
            return G(N(self.v), div, o, n=name)          # N/M ---> G
        elif isinstance(o, T1) or isinstance(o, T2):
            return G(N(self.v), div, o, n=name)          # N/(T1 oder T2) ---> G
        elif isinstance(o, TT):
            return G(N(self.v), div, o, n=name)          # N/TT ---> G
        else:
            raise TypeError(_fehler3 + str(o))

# ----------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse N.

        Aufruf: N.beispiel(e)
        für e kann
        "!=", "-", "*", "**", "/", "__add__", "__eq__", "__ge__", "__gt__",
        "__le__", "__lt__", "__mul__", "__ne__", "__neg__", "__pos__", "__pow__",
        "__repr__", "__str__", "__sub__", "__truediv__", "+", "<", "<=", "==", ">",
        ">=", "description", "info", "repr", "str", "Vorzeichen -", "Vorzeichen +",
        leere Zeichenkette [Voreinstellung] angegeben werden"""
        
        print("""
        l11=L1(2,m);l12=L1(3,cm);l21=L2(4,mm2);l22=L2(5,km2);l31=L3(6,liter);
        l32=L3(7,dl);n1=N(2);n2=N(-3);t11=T1(8,s);t12=T1(9,h);t21=T2(10,s2);
        t22=T2(11,d2);m11=M(12,g);m12=M(13,kg);tt1=TT(14,C);tt2=TT(15,K);
        g1=G(l11,div,t11);g2=G(t11,mul,m1);i1=2;i2=(-5)""")
        l11=L1(2,_m);l12=L1(3,_cm);l21=L2(4,_mm2);l22=L2(5,_km2);l31=L3(6,_liter);l32=L3(7,_dl);n1=N(2);n2=N(-3);
        t11=T1(8,_s);t12=T1(9,_h);t21=T2(10,_s2);t22=T2(11,_d2);m11=M(12,_g);m12=M(13,_kg);tt1=TT(14,_C);tt2=TT(15,_K);
        g1=G(l11,div,t11);g2=G(t11,mul,m11);i1=2;i2=(-5)
        if e in ["","__add__", "+"]:                                               # __add__
            print("__add__ oder +",N.__add__.__doc__)
            for f in [n2]: print(_qqq+str(n1)+"+" +str(f)+" --> ", n1+f)
        if e in ["","__eq__", "=="]:                                               # __eq__
            print("__eq__ oder ==",N.__eq__.__doc__)
            for f in [n2]: print(_qqq+str(n1)+"==" +str(f)+" --> ", n1==f)
        if e in ["","__ge__", ">="]:                                               # __ge__
            print("__ge__ oder >=",N.__ge__.__doc__)
            for f in [n2]: print(_qqq+str(n1)+">=" +str(f)+" --> ", n1>=f)
        if e in ["","__gt__", ">"]:                                                # __gt__
            print("__gt__ oder >",N.__gt__.__doc__)
            for f in [n2]: print(_qqq+str(n1)+">" +str(f)+" --> ", n1>f)
        if e in ["","__le__", "<="]:                                               # __le__
            print("__le__ oder <=",N.__le__.__doc__)
            for f in [n2]: print(_qqq+str(n1)+"<=" +str(f)+" --> ", n1<=f)
        if e in ["","__lt__", "<"]:                                                # __lt__
            print("__lt__ oder <",N.__lt__.__doc__)
            for f in [n2]: print(_qqq+str(n1)+"<" +str(f)+" --> ", n1<f)
        if e in ["","__mul__", "*"]:                                               # __mul__
            print("__mul__ oder *",N.__mul__.__doc__)
            for f in [i1,l11,l21,l31,n1,n2,t11,t21,m12,tt2,g1]: print(_qqq+str(n1)+"*" +str(f)+" --> ", n1*f)
        if e in ["","__ne__", "!="]:                                               # __ne__
            print("__ne__ oder !=",N.__ne__.__doc__)
            for f in [n2]: print(_qqq+str(n1)+"!=" +str(f)+" --> ", n1!=f)
        if e in ["","__neg__", "Vorzeichen -"]:                                    # __neg__
            print("__neg__ oder Vorzeichen -",N.__neg__.__doc__)
            print(_qqq+"-"+str(n1)+" --> ", -n1)
        if e in ["","__pos__", "Vorzeichen +"]:                                    # __pos__
            print("__pos__ oder Vorzeichen +",N.__pos__.__doc__)
            print(_qqq+"+"+str(n1)+" --> ", +n1)
        if e in ["","__pow__", "**"]:                                              # __pow__
            print("__pow__ oder **",N.__pow__.__doc__)
            print(_qqq+"n1**2, n2**0 --> ", n1**2, n2**0)
        if e in ["","__repr__", "repr"]:                                           # __repr__
            print("__repr__ oder repr",N.__repr__.__doc__)
            print(_qqq+"repr(n1), repr(n2) --> ", repr(n1), repr(n2))
        if e in ["","__str__", "str"]:                                             # __str__
            print("__str__ oder str",N.__str__.__doc__)
            print(_qqq+"str(n1), str(n2) --> ", str(n1), str(n2))
        if e in ["","__sub__", "-"]:                                               # __sub__
            print("__sub__ oder -",N.__sub__.__doc__)
            for f in [n2]: print(_qqq+str(n1)+"-" +str(f)+" --> ", n1-f)
        if e in ["","__truediv__", "/"]:                                           # __truediv__
            print("__truediv__ oder /",N.__truediv__.__doc__)
            for f in [i1,l11,l21,l31,n1,n2,t11,t21,m12,tt2,g1]: print(_qqq+str(n1)+"/" +str(f)+" --> ", n1/f)
        if e in ["","description"]:                                                # description
            print("description",N.description.__doc__)
            print(_qqq+"N.description() --> ", N.description())
        if e in ["","info"]:                                                       # info
            print("info",N.info.__doc__)
            print(_qqq+str(n1)+".info() --> ");n1.info()
            print(_qqq+str(n2)+".info() --> ");n2.info()

# ---------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse N und ihre Methoden aus.

        Aufruf: N.classInfo(m=art) oder N.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles     : alles [Voreinstellung]
        + "H"/Kopf      : globale Informationen
        + "V"/Variablen : Variablen/Eigenschaften
        + "M"/Methoden  : Methoden"""
        
        # lokale Hilfsvariable: s1, s2, s3
        
        s1 = "N."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class N\n", N.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der N-Instanzen:

    n.v        Wert der Instanz
    n.internal interner Wert
    n.name     Name der Instanz
    """)
        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(N):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)

# ---------------------------------------------------------
    def description():
        """
        Kurzbeschreibung der Klasse N.

        Aufruf: N.description()"""
        
        return "Operationen mit N-Instanzen  (linkseitige Skalare)"

# ---------------------------------------------------------
    def info(self):
        """
        Gibt Informationen über eine N-Instanz aus.

        Aufruf: n.info()"""
        
        # lokale Hilfsvariable: selfv
        
        selfv = _str_aus(self.v)
        print("Name         :", self.name)
        print("Art          :", "N-Instanz")
        print("interner Wert:", selfv)
        print(_q)

    ci = classInfo # Alias für classInfo()

# =========================================================
class T1:
    """
    Realisiert das Rechnen mit T1-Instanzen (Zeiten).

    Aufruf: T1.__init__(value=1, unit=s, n="")

    Parameter:

    value=1 : Wert;
              Voreinstellung: 1
    unit=s  : T1-Maßeinheit;
              Voreinstellung: s
    n=""    : Name der T1-Instanz;
              Voreinstellung: leere Zeichenkette

    Methoden:

    t : T1-Instanz (Zeit)
    o : Instanz
    n : Zahl(Integer/Float)
    p : Integer
    u : eine der zulässigen T1-Maßeinheiten

    t.__abs__() oder abs(t)    Liefert den Absolut-Betrag der T1-Instanz.
    t.__add__(t) oder t + t    Realisiert die Addition zweier T1-Instanzen.
    t.__eq__(t) oder t == t    Realisiert den Vergleich == in T1.
    t.__ge__(t) oder t >= t    Realisiert den Vergleich >= in T1.
    t.__gt__(t) oder t > t     Realisiert den Vergleich > in T1.
    t.__le__(t) oder t <= t    Realisiert den Vergleich <= in T1.
    t.__lt__(t) oder t < t     Realisiert den Vergleich < in T1.
    t.__mul__(o) oder t * o    Realisiert die Multiplikation.
    t.__ne__(t) oder t != t    Realisiert den Vergleich != in T1.
    t.__neg__() oder -(t)      Realisiert negatives Vorzeichen in T1.
    t.__pos__() oder +(t)      Realisiert positives Vorzeichen in T1.
    t.__pow__(p) oder t ** p   Realisiert das Potenzieren einer T1-Instanz.
    t.__repr__() oder repr(t)  Repräsentiert eine T1-Instanz.
    t.__str__() oder str(t)    Repräsentiert eine T1-Instanz.
    t.__sub__(t) oder t - t    Realisiert die Subtraktion in T1.
    t.__truediv__(o) oder t / o Realisiert die Division einer T1-Instanz.
    t.info(modus)              Gibt Informationen über eine T1-Instanz aus.
    t.to(u)                    Realisiert die Konvertierung einer T1-Instanz in
                               eine andere Maßeinheit.
    t.toYMD()                  Liefert Jahr, Monat, Tag, Stunde, Minute, Sekunde
                               der aktuellen T1-Instanz als Liste.
    t.toU()                    Konvertiert die aktuelle Zeit in die Uhrzeit U.
    T1.__init__(value=1,unit=s,n="") Initialisiert eine T1-Instanz.
    T1.beispiel(e)             Liefert Beispiele für die Methoden der Klasse T1.
    T1.classInfo(m=art)        Gibt Informationen zur Klasse T1 und ihre
                               Methoden aus.
    T1.ci(m=art)               Alias für T1.classInfo(m=art)
    T1.description()           Gibt eine Kurzbeschreibung der Klasse T1 aus.
    """

    global eps, trennz

# ---------------------------------------------------------
    def __abs__(self):
        """
        Liefert den Absolut-Betrag der T1-Instanz.

        Aufruf: t.__abs__() oder abs(t)"""
        
        name = "abs(" + str(self) + ")"
        return T1(abs(self.v), self.u, n=name)

# ---------------------------------------------------------
    def __add__(self, t):
        """
        Realisiert die Addition zweier T1-Instanzen.

        Aufruf: t.__add__(t) oder t + t
        erlaubter Typ des Operanden:
        - T1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(t, T1)):
            raise TypeError(_fehler3 + str(t))
        name = str(self) + " + " + t.name
        return T1(self.internal + t.internal, _s, n=name)

# ---------------------------------------------------------
    def __eq__(self, t):
        """
        Realisiert den Vergleich == in T1.

        Aufruf: t.__eq__(t) oder t == t
        erlaubter Typ des Operanden:
        - T1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ.""" # Fehlermeldung
        
        global eps
        
        if not (isinstance(t, T1)):
            raise TypeError(_fehler3 + str(t))
        return abs(self.internal - t.internal) <= eps

# ---------------------------------------------------------
    def __ge__(self, t):
        """
        Realisiert den Vergleich >=  in T1.

        Aufruf: t.__ge__(t) oder t >= t
        erlaubter Typ des Operanden:
        - T1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(t, T1)):
            raise TypeError(_fehler3 + str(t))
        return (self.internal > t.internal) or (abs(self.internal - t.internal) <= eps)

# ---------------------------------------------------------
    def __gt__(self, t):
        """
        Realisiert den Vergleich > in T1.

        Aufruf: t.__gt__(t) oder t > t
        erlaubter Typ des Operanden:
        - T1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(t, T1)):
            raise TypeError(_fehler3 + str(t))
        return (self.internal > t.internal)

# ---------------------------------------------------------
    def __init__(self, value=1, unit=_s, n=""):
        """
        Initialisiert eine T1-Instanz.

        Aufruf: T1.__init__(value=1, unit=s, n="")
        Parameter:
        - value: Wert der T1-Instanz;
                 Voreinstellung: 1
        - unit : eine zulässige T1-Maßeinheit;
                 Voreinstellung: s
        - n    : Name der T1-Instanz;
                 Voreinstellung: leere Zeichenkette
        mögliche Fehlermeldung:
        - Unit ist hier nicht bekannt/zulässig"""
        
        if not (unit in _time1):
            raise ValueError(_fehler2 + str(unit))
        self.v = value
        self.u = unit
        self.internal = self.v * _time1[self.u]
        if n == "":
            self.name = "T1(" + str(_str_aus(self.v)) + trennz + self.u + ")"
        else:
            self.name = n
        T1Liste.append(self)

# ---------------------------------------------------------
    def __le__(self, t):
        """
        Realisiert den Vergleich <= in T1.

        Aufruf: t.__le__(t) oder t <= t
        erlaubter Typ des Operanden:
        - T1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(t, T1)):
            raise TypeError(_fehler3 + str(t))
        return (self.internal < t.internal) or (abs(self.internal - t.internal) <= eps)

# ---------------------------------------------------------
    def __lt__(self, t):
        """
        Realisiert den Vergleich < in T1.

        Aufruf: t.__lt__(t) oder t < t
        erlaubter Typ des Operanden:
        - T1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(t, T1)):
            raise TypeError(_fehler3 + str(t))
        return (self.internal < t.internal)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert die Multiplikation einer T1-Instanz.

        Aufruf: t.__mul__(o) oder t * o
        mögliche Typen des Operanden:
        - L1, L2, L3, T1, T2, TT, M, int, float, N, G, V, B, F1, W, P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]
        # lokale Hilfsvariable: name
        
        name = str(self) + " * (" + str(o) + ")"
        if typ(o) in ["int", "float"]:
            return T1(self.v * o, self.u, n=name)
        elif isinstance(o, T1):
            return T2(self.internal * o.internal, _s2, n=name)
        elif isinstance(o, N):
            return T1(self.v * o.v, self.u, n=name)
        elif isinstance(o, V): 
            zwi = G(self, mul, N(1)) * o
            return meter(zwi.internal, n=name)
        elif isinstance(o, B): 
            zwi = G(self, mul, N(1)) * o
            return meterS(zwi.internal, n=name)
        elif isinstance(o, P): 
            zwi = G(self, mul, N(1)) * o
            return joule(zwi.internal, n=name)
        elif typ(o) in ["L1", "L2", "L3", "T2", "M", "TT", "T2", "F1", "W", "G"]:
            return G(self, mul, o, n=name)
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __ne__(self, t):
        """
        Realisiert den Vergleich != in T1.

        Aufruf: t.__ne__(t) oder t != t
        erlaubter Typ des Operanden:
        - T1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(t, T1)):
            raise TypeError(_fehler3 + str(t))
        return abs(self.internal - t.internal) > eps

# ---------------------------------------------------------
    def __neg__(self):
        """
        Realisiert negatives Vorzeichen für eine T1-Instanz.

        Aufruf: t.__neg__() oder -(t)"""
        
        return T1(-self.v, self.u)

# ---------------------------------------------------------
    def __pos__(self):
        """
        Realisiert positives Vorzeichen für eine T1-Instanz.

        Aufruf: t.__pos__() oder +(t)"""
        return T1(self.v, self.u)

# ---------------------------------------------------------
    def __pow__(self, p):
        """
        Realisiert das Potenzieren einer T1-Instanz.

        Aufruf: t.__pow__(p) oder t ** p
        erlaubter Typ des Operanden:
        - int, float
        erlaubte Werte für p:
        - 0, 1, 2
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - unsupported operand type(s) for ** or pow(): 'T1' and 'int'"""
        
        if not (isinstance(p, int) or isinstance(p, float)):
            raise TypeError(_fehler3 + str(p))
        name = str(self) + " ** (" + str(p) + ")"
        if abs(p) <= eps:
            return 1
        elif abs(p - 1) <= eps:
            return T1(self.v, self.u, n=name)
        elif abs(p - 2) <= eps:
            return T2(self.internal * self.internal, _s2, n=name)
        else:
            return NotImplemented

# ---------------------------------------------------------
    def __repr__(self):
        """
        Repräsentiert eine T1-Instanz.

        Aufruf: t.__repr__() oder repr(t)"""
        
        global trennz
        
        return "T1(" + _repr_aus(self.v) + trennz + self.u + ")"

# ---------------------------------------------------------
    def __str__(self):
        """
        Repräsentiert eine T1-Instanz.

        Aufruf: t.__str__() oder str(t)"""
        
        global trennz
        
        return "T1(" + _str_aus(self.v) + trennz + self.u + ")"

# ---------------------------------------------------------
    def __sub__(self, t):
        """
        Realisiert die Subtraktion zweier T1-Instanzen.

        Aufruf: t.__sub__(t) oder t - t
        erlaubter Typ des Operanden:
        - T1
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(t, T1)):
            raise TypeError(_fehler3 + str(t))
        name = str(self) + " - " + t.name
        return T1(self.internal - t.internal, _s, n=name)

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert die Division einer T1-Instanz.

        Aufruf: t.__truediv__(o) oder t / o
        möglicher Typ des Operanden:
        - int, float, T1, T2, L1, L2, L3, M, N, TT, G, V, B, F1, W, P
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - Operand hat den Wert Null."""
        
        global eps
        
        # lokale Hilfsvariable: name
        
        name = str(self) + " / (" + str(o) + ")"
        if typ(o) in ["int", "float"]:
            if abs(o) <= eps:
                raise ValueError(_fehler4 + str(o))
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P"]:
            if abs(o.v) <= eps:
                raise ValueError(_fehler4 + str(o))
            
        if typ(o) in ["int", "float"]:
            return T1(self.v / o, self.u, n=name)          # T1/Skalar ---> T1
        elif isinstance(o, T1):
            return self.internal / o.internal                     # T1/T1 ---> Skalar
        elif isinstance(o, N):
            return T1(self.internal / o.internal, self.u, n=name) # T1/N ---> T1
        elif typ(o) in ["L1", "L2", "L3", "T2", "M", "TT", "T1", "T2", "V", "B", "F1", "W", "P"]:
            return G(self, div, o, n=name)                        # T1/sonst ---> G
        else:
            raise TypeError(_fehler3 + str(o))

# ----------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse T1.

        Aufruf: T1.beispiel(e)
        für e kann
        "!=", "-", "*", "**", "/", "__add__", "__eq__", "__ge__", "__gt__",
        "__le__", "__lt__", "__mul__", "__ne__", "__neg__", "__pos__", "__pow__",
        "__repr__", "__str__", "__sub__", "__truediv__", "+", "<", "<=", "==", ">",
        ">=", "description", "info", "repr", "str", "to", "toYMD", "Vorzeichen -",
        "Vorzeichen +", leere Zeichenkette [Voreinstellung] angegeben werden"""
        
        print("""
        l11=L1(2,m);l12=L1(3,cm);l21=L2(4,mm2);l22=L2(5,km2);l31=L3(6,liter);
        l32=L3(7,dl);n1=N(2);n1=N(-3);t11=T1(8,s);t12=T1(9,h);t21=T2(10,s2);
        t22=T2(11,d2);m11=M(12,g);m12=M(13,kg);tt1=TT(14,C);tt2=TT(15,K);
        g1=G(l11,div,t11);g2=G(t11,mul,m1);i1=2;i2=(-5)""")
        l11=L1(2,_m);l12=L1(3,_cm);l21=L2(4,_mm2);l22=L2(5,_km2);l31=L3(6,_liter);l32=L3(7,_dl);n1=N(2);n1=N(-3);
        t11=T1(8,_s);t12=T1(9,_h);t21=T2(10,_s2);t22=T2(11,_d2);m11=M(12,_g);m12=M(13,_kg);tt1=TT(14,_C);tt2=TT(15,_K);
        g1=G(l11,div,t11);g2=G(t11,mul,m11);i1=2;i2=(-5)
        if e in ["","__add__", "+"]:                                               # __add__
            print("__add__ oder +",T1.__add__.__doc__)
            for f in [t12]: print(_qqq+str(t11)+"+" +str(f)+" --> ", t11+f)
        if e in ["","__eq__", "=="]:                                               # __eq__
            print("__eq__ oder ==",T1.__eq__.__doc__)
            for f in [t12]: print(_qqq+str(t11)+"==" +str(f)+" --> ", t11==f)
        if e in ["","__ge__", ">="]:                                               # __ge__
            print("__ge__ oder >=",T1.__ge__.__doc__)
            for f in [t12]: print(_qqq+str(t11)+">=" +str(f)+" --> ", t11>=f)
        if e in ["","__gt__", ">"]:                                                # __gt__
            print("__gt__ oder >",T1.__gt__.__doc__)
            for f in [t12]: print(_qqq+str(t11)+">" +str(f)+" --> ", t11>f)
        if e in ["","__le__", "<="]:                                               # __le__
            print("__le__ oder <=",T1.__le__.__doc__)
            for f in [t12]: print(_qqq+str(t11)+"<=" +str(f)+" --> ", t11<=f)
        if e in ["","__lt__", "<"]:                                                # __lt__
            print("__lt__ oder <",T1.__lt__.__doc__)
            for f in [t12]: print(_qqq+str(t11)+"<" +str(f)+" --> ", t11<f)
        if e in ["","__mul__", "*"]:                                               # __mul__
            print("__mul__ oder *",T1.__mul__.__doc__)
            for f in [i1,l11,l21,l31,n1,t11,t12,t21,m11,tt1,g1]: print(_qqq+str(t11)+"*" +str(f)+" --> ", t11*f)
        if e in ["","__ne__", "!="]:                                               # __ne__
            print("__ne__ oder !=",T1.__ne__.__doc__)
            for f in [t12]: print(_qqq+str(t11)+"!=" +str(f)+" --> ", t11!=f)
        if e in ["","__neg__", "Vorzeichen -"]:                                    # __neg__
            print("__neg__ oder Vorzeichen -",T1.__neg__.__doc__)
            print(_qqq+"-"+str(t11)+ " --> ", -t11)
        if e in ["","__pos__", "Vorzeichen +"]:                                    # __pos__
            print("__pos__ oder Vorzeichen +",T1.__pos__.__doc__)
            print(_qqq+"+"+str(t11)+" --> ", +t11)
        if e in ["","__pow__", "**"]:                                              # __pow__
            print("__pow__ oder **",T1.__pow__.__doc__)
            print(_qqq+str(t11)+"**2 --> ", t11**2)
            print(_qqq+str(t12)+"**0 --> ", t12**0)
        if e in ["","__repr__", "repr"]:                                           # __repr__
            print("==> __repr__ oder repr",T1.__repr__.__doc__)
            print(_qqq+"repr(t11), repr(t12) --> ", repr(t11), repr(t12))
        if e in ["","__str__", "str"]:                                             # __str__
            print("==> __str__ oder str",T1.__str__.__doc__)
            print(_qqq+"str(t11), str(t12) --> ", str(t11), str(t12))
        if e in ["","__sub__", "-"]:                                               # __sub__
            print("__sub__ oder -",T1.__sub__.__doc__)
            for f in [t12]: print(_qqq+str(t11)+"-" +str(f)+" --> ", t11-f)
        if e in ["","__truediv__", "/"]:                                           # __truediv__
            print("__truediv__ oder /",T1.__truediv__.__doc__)
            for f in [i1,l11,l21,l31,n1,t11,t12,t21,m11,tt1]: print(_qqq+str(t11)+"/" +str(f)+" --> ", t11/f)
        if e in ["","description"]:                                                # description
            print("description",T1.description.__doc__)
            print(_qqq+"T1.description() --> ", T1.description())
        if e in ["","info"]:                                                       # info
            print("info",T1.info.__doc__)
            print(_qqq+str(t11)+".info() --> ");t11.info()
            print(_qqq+str(t12)+".info(lang) --> ");t12.info(lang)
        if e in ["","to"]:                                                         # to
            print("to",T1.to.__doc__)
            print(_qqq+str(t11)+".to(h) --> ",t11.to(_h))
            print(_qqq+str(t12)+".to(s) --> ",t12.to(_s))
        if e in ["","toYMD"]:                                                     # toYMD
            print("toYMD",T1.toYMD.__doc__)
            print(_qqq+"T(21345.75,h).toYMD() --> ",T(21345.75,_h).toYMD())

# ----------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse T1 und ihre Methoden aus.

        Aufruf: T1.classInfo(m=art) oder T1.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles    : alles [Voreinstellung]
        + "H"/Kopf     : globale Informationen
        + "V"/Variablen: Variablen/Eigenschaften
        + "M"/Methoden : Methoden
        + "E"/Einheiten: Einheiten"""

        # lokale Hilfsvariable: s1, s2, s3
        
        s1 = "T1."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class T1\n", T1.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der T1-Instanzen:

    t.v        Wert der Instanz (gemessen in t.u)
    t.u        Maßeinheit der Instanz (T1-Maßeinheit)
    t.name     Name der Instanz
    t.internal interner Wert
    """)
        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(T1):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)
        if m in ["A", "E"]:
            print('Einheiten\n')
            au("T1")

# ---------------------------------------------------------
    def description():
        """
        Liefert eine Kurzbeschreibung der Klasse T1.

        Aufruf: description()"""
        
        return "Operationen mit T1-Instanzen (Zeiteinheiten)"

# ---------------------------------------------------------
    def info(self, m=kurz):
        """
        Gibt Informationen über eine T1-Instanz aus.

        Aufruf: t.info(modus)
        m Modus
          kurz  nur Grund-Eigenschaften
                [Voreinstellung]
          lang  auch Darstellung in anderen Einheiten"""

        # lokale Hilfsvariable: mm, mmm, ss, sss
        
        ss  = _str_aus(self.v)
        sss = _str_aus(self.internal)
        print("Name         :", self.name)
        print("Art          :", "T1-Instanz (Zeit)")
        print("Wert         :", ss, "(in " + self.u + ")")
        print("Einheit      :", self.u, "["+_descript[self.u]+"]")
        print("interner Wert:", sss, "(in s)")
        if m == lang:
            print("Darstellung in anderen Einheiten:")
            for f in sorted(_time1, key=str.lower):
                mm  = self.to(f)
                mmm = _str_aus(mm.v)
                print(leer, f.ljust(8), str(mmm).ljust(22), "(" + _descript[f] + ")")
        print(_q)

# ---------------------------------------------------------
    def to(self, unit):
        """
        Realisiert die Konvertierung einer T1-Instanz in eine andere Maßeinheit.

        Aufruf: t.to(unit)
        erlaubter Typ des Operanden:
        - eine der zulässigen T1-Maßeinheiten
        mögliche Fehlermeldung:
        - Unit ist hier nicht bekannt/zulässig"""
        
        # lokale Hilfsvariable: z, name
        
        if not (unit in _time1):
            raise ValueError(_fehler2 + str(unit))
        z = self.internal / _time1[unit]
        name = str(self) + "--->" + unit
        return T1(z, unit, n=name)

# ---------------------------------------------------------
    def toU(self):
        """
        Konvertiert die aktuelle Zeit in die Uhrzeit U.

        Aufruf: t.toU()
        mögliche Fehlermeldung:
        - Parameter ist unzulässig"""
        
        # lokale Größen: ll, name
        
        if abs(self.internal) >= 86400:
            raise ValueError(_fehler5 + str(self.v) + " " + str(self.u))
        ll   = self.toYMD()
        name = str(self) + "---> U"
        return U(ll[3].v, ll[4].v, ll[5].v, n=name)

# ---------------------------------------------------------
    def toYMD(self):
        """
        Liefert Jahr, Monat, Tag, Stunde, Minute, Sekunde der aktuellen Instanz
        als Liste.

        Aufruf: t.toYMD()"""
        
        # lokale Hilfsvariable: ll, zz, zrest, zy, zd, zmin, vorz

        vorz = sign(self.internal)
        ll = [0, 0, 0, 0, 0, 0]
        zz   = abs(self.internal)
        zy   = _time1[_y];    zm = _time1[_mon];
        zd   = _time1[_d];    zh = _time1[_h];
        zmin = _time1[_minute]
        ll[0] = T1(int(zz // zy), _y) * vorz;       zz = zz % zy
        ll[1] = T1(int(zz // zm), _mon) * vorz;     zz = zz % zm
        ll[2] = T1(int(zz // zd), _d) * vorz;       zz = zz % zd
        ll[3] = T1(int(zz // zh), _h) * vorz;       zz = zz % zh
        ll[4] = T1(int(zz // zmin), _minute) * vorz;zz = zz % zmin
        ll[5] = T1(zz, _s) * vorz
        return ll

    ci = classInfo # Alias für classInfo()


# =========================================================
class U(T1):
    """
    U ist eine Subklasse von T1 und realisiert das Rechnen mit U-Instanzen
    (Uhrzeiten). Sie erbt damit alle Eigenschaften und Methoden von T1
    (außer denen, die überschrieben werden.

    Aufruf: U.__init__(v1=0, v2=0, V3=0, n="")

    Parameter:

    v1=0 : Wert der Stunden;   Voreinstellung: 0
    v2=0 : Wert der Minuten;   Voreinstellung: 0
    v3=0 : Wert der Sekunden;  Voreinstellung: 0
    n="" : Name der U-Instanz; Voreinstellung: leere Zeichenkette

    Methoden:

    u : U-Instanz (Uhrzeit)
    e : eine Methode der Klasse U
    m : eine der zulässigen U-Maßeinheiten
    o : c

    u.__abs__() oder abs(u)    Liefert den Absolut-Betrag der U-Instanz.
    u.__add__(u) oder u + u    Realisiert die Addition zweier U-Instanzen.
    u.__eq__(u) oder u == u    Realisiert den Vergleich == in U.
    u.__ge__(u) oder u >= u    Realisiert den Vergleich >= in U.
    u.__gt__(u) oder u > u     Realisiert den Vergleich > in U.
    U.__init__(v1=0, v2=0, v3=0, n="") Initialisiert eine U-Instanz.
    u.__le__(u) oder u <= u    Realisiert den Vergleich <= in U.
    u.__lt__(u) oder u < u     Realisiert den Vergleich < in U.
    u.__mul__(o) oder u * o    Realisiert die Multiplikation einer U-Instanz.
    u.__ne__(u) oder u != u    Realisiert den Vergleich != in U.
    u.__neg__() oder -(u)      Realisiert negatives Vorzeichen in U.
    u.__pos__() oder +(u)      Realisiert positives Vorzeichen in U.
    u.__repr__() oder repr(u)  Repräsentiert eine U-Instanz.
    u.__str__() oder str(u)    Repräsentiert eine U-Instanz.
    u.__sub__(u) oder u - u    Realisiert die Subtraktion in U.
    u.__truediv__(o) oder u / o Realisiert die Division einer U-Instanz.
    U.beispiel(e)              Liefert Beispiele für die Methoden der Klasse U.
    U.classInfo(m=art)         Gibt Informationen zur Klasse U und ihre Methoden
                               aus.
    U.ci(m=art)                Alias für U.classInfo(m=art)
    U.description()            Gibt eine Kurzbeschreibung der Klasse U aus.
    u.info(modus)              Gibt Informationen über eine U-Instanz aus.
    u.to(m)                    Realisiert die Konvertierung einer U-Instanz in
                               eine andere Maßeinheit.
    u.toYMD()                  Liefert Jahr, Monat, Tag, Stunde, Minute, Sekunde
                               der aktuellen U-Instanz als Liste.
    """

# ---------------------------------------------------------
    def __abs__(self):
        """
        Liefert den Absolut-Betrag der U-Instanz.

        Aufruf: u.__abs__() oder abs(u)"""
        name = "abs(" + str(self) + ")"
        return U(abs(self.v1), abs(self.v2), abs(self.v3), n=name)

# ----------------------------------------------------------
    def __add__(self, u):
        """
        Realisiert die Addition zweier U-Instanzen.

        Aufruf: u.__add__(u) oder u + u
        zulässiger Typ des Operanden:
        - U
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # lokale Größen: zwi, ll
        
        if not(isinstance(u, U)):
            raise TypeError(_fehler3 + str(u))
        zwi  = T1(self.internal + u.internal, _s)
        ll   = zwi.toYMD()
        name = str(self) + " + " + u.name
        del zwi
        return U(ll[3].v, ll[4].v, ll[5].v, n=name)

# ---------------------------------------------------------
    def __init__(self, ph=0, pm=0, ps=0, n=""):
        """
        Initialisiert eine U-Instanz.

        Aufruf: U.__init__(ph=0, pm=0, ps=0, n="")
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ
        - Parameter ist unzulässig"""

        # lokale Größe: zwi
        
        if not (isinstance(ph, int) and isinstance(pm, int) and (isinstance(ps, int) or isinstance(ps, float))):
            raise TypeError(_fehler3 + str(ph) + "/" + str(pm) + "/" + str(ps))
        if not (-24 <= ph and ph  <= 24):
            raise ValueError(_fehler5 + str(ph))
        if not (-60 <= pm and pm  < 60):
            raise ValueError(_fehler5 + str(pm))
        if not (-60 <= ps and ps  < 60):
            raise ValueError(_fehler5 + str(ps))
        zwi           = T1(ph, _h) + T1(pm, _minute) + T1(ps, _s) 
        self.internal = zwi.internal
        self.v1       = ph
        self.v2       = pm
        self.v3       = ps
        del zwi
        if n == "":
            self.name = "U(" + repr(self) + ")"
        else:
            self.name = n
        T1.__init__(self, self.internal, _s, self.name)
        UListe.append(self)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert die Multiplikation einer U-Instanz.

        Aufruf: u.__mul__(o) oder u * o
        mögliche Fehlermeldungen:
        - Parameter hat unzulässigen Wert
        - unsupported operand type(s) for *: 'U' and 'M'
        mögliche Typen des Operanden:
        - int, float, N"""

        global rndg
        
        # lokale Größe: zwi, vo
        
        if typ(o) in ["int", "float"] or isinstance(o, N):
            if isinstance(o, N):
                vo = o.v
            else:
                vo = o
            zwi  = T1(self.internal * vo, _s)
            zwi2 = zwi.toYMD()
            if abs(zwi2[2].v) > 0:
                raise ValueError(_fehler6 + str(o) + " (ergibt mehr als 24h)")
            del zwi
            name = str(self) + " * " + str(o)
            return U(zwi2[3].v, zwi2[4].v, zwi2[5].v, n=name)
        else:
            return NotImplemented

# ---------------------------------------------------------
    def __pow__(self, u):
        """
        Realisiert die Potenzierung einer U-Instanz.

        Aufruf: u.__pow__(i) oder u ** i
        mögliche Fehlermeldung:
        - unsupported operand type(s) for ** or pow(): 'U' and 'int'"""
        
        return NotImplemented

# ---------------------------------------------------------
    def __repr__(self):
        """
        Liefert die Darstellung einer U-Instanz.

        Aufruf: repr(u)"""
        
        # lokale Größen: zwi, sv1, sv2, sv3
        
        zwi = ""
        if self.v1 < 0:
            zwi = "-"
        sv1 = abs(self.v1)
        sv2 = abs(self.v2)
        sv3 = abs(self.v3)
        if sv1 < 10:
            zwi = zwi + repr(0)
        zwi = zwi + repr(sv1) + ":"
        if sv2 < 10:
            zwi = zwi + repr(0)
        zwi = zwi + repr(sv2) + ":"
        if sv3 < 10:
            zwi = zwi + repr(0)
        zwi = zwi + repr(round(sv3, rndg))
        return zwi

# ---------------------------------------------------------
    def __str__(self):
        """
        Liefert die Darstellung einer U-Instanz.

        Aufruf: str()"""
        
        # lokale Größen: zwi, sv1, sv2, sv3
        
        zwi = ""
        if self.v1 < 0:
            zwi = "-"
        sv1 = abs(self.v1)
        sv2 = abs(self.v2)
        sv3 = abs(self.v3)
        if sv1 < 10:
            zwi = zwi + str(0)
        zwi = zwi + str(sv1) + ":"
        if sv2 < 10:
            zwi = zwi + str(0)
        zwi = zwi + str(sv2) + ":"
        if sv3 < 10:
            zwi = zwi + str(0)
        zwi = zwi + str(round(sv3, rndg))
        return zwi

# ---------------------------------------------------------
    def __sub__(self, u):
        """
        Realisiert die Subtraktion zweier U-Instanzen.

        Aufruf: u.__sub__(u) oder u - u
        zulässiger Typ des Operanden:
        - U
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ"""
        
        # lokale Größen: zwi, ll
        
        if not(isinstance(u, U)):
            raise TypeError(_fehler3 + str(u))
        zwi  = T1(self.internal - u.internal, _s)
        ll   = zwi.toYMD()
        name = str(self) + " - " + u.name
        del zwi
        return U(ll[3].v, ll[4].v, ll[5].v, n=name)

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert die Division einer U-Instanz.

        Aufruf: u.__truediv__(o) oder u / o
        mögliche Fehlermeldungen:
        - Parameter hat unzulässigen Wert
        - Operand hat den Wert Null
        - unsupported operand type(s) for /: 'U' and 'M'
        möglicher Typ des Operanden:
        - int, float, N, U"""
        
        global eps
        
        # lokale Größe: zwi, vo
        
        if typ(o) in ["int", "float", "N"]:
            if isinstance(o, N):
                vo = o.v
            else:
                vo = o
            if abs(vo) <= eps:
                raise ValueError(_fehler4 + str(o))
            zwi  = T1(self.internal / vo, _s)
            zwi2 = zwi.toYMD()
            if abs(zwi2[2].v) > 0:
                raise ValueError(_fehler6 + str(o) + " (ergibt mehr als 24h)")
            del zwi
            name = str(self) + " + " + str(o)
            return U(zwi2[3].v, zwi2[4].v, zwi2[5].v, n=name)
        elif isinstance(o, U):
            if abs(o.internal) <= eps:
                raise ValueError(_fehler4 + str(o))
            return self.internal / o.internal
        else:
            return NotImplemented

# ---------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse U.

        Aufruf: U.beispiel(e)
        für e kann
        "!=", "-", "*", "/", "__add__", "__eq__", "__ge__", "__gt__", "__le__",
        "__lt__", "__mul__", "__ne__", "__neg__", "__pos__", "__repr__", "__str__",
        "__sub__", "__truediv__", "+", "<", "<=", "==", ">", ">=", "description",
        "info", "repr", "str", "to", "Vorzeichen -", "Vorzeichen +", leere
        Zeichenkette [Voreinstellung] angegeben werden"""
        
        print("""
        i1=2;i2=(-1);n1=N(1);n2=N(-2);r1=0.5;r2=(-1.5);u1=U(10,11,12);u2=U(20,21,22)""")
        i1=2;i2=(-1);n1=N(1);n2=N(-2);r1=0.5;r2=(-1.5);u1=U(10,11,12);u2=U(20,21,22)
        if e in ["", "__add__", "+"]:                                               # __add__
            print("__add__ oder +",U.__add__.__doc__)
            for f in [u1, u2]: print(_qqq+str(u1)+"+" +str(f)+" --> ", u1+f)
        if e in ["", "__eq__", "=="]:                                               # __eq__
            print("__eq__ oder ==",U.__eq__.__doc__)
            for f in [u1,u2]: print(_qqq+str(u1)+"==" +str(f)+" --> ", u1==f)
        if e in ["", "__ge__", ">="]:                                               # __ge__
            print("__ge__ oder >=",U.__ge__.__doc__)
            for f in [u1,u2]: print(_qqq+str(u1)+">=" +str(f)+" --> ", u1>=f)
        if e in ["", "__gt__", ">"]:                                                # __gt__
            print("__gt__ oder >",U.__gt__.__doc__)
            for f in [u1,u2]: print(_qqq+str(u1)+">" +str(f)+" --> ", u1>f)
        if e in ["", "__le__", "<="]:                                               # __le__
            print("__le__ oder <=",U.__le__.__doc__)
            for f in [u1,u2]: print(_qqq+str(u1)+"<=" +str(f)+" --> ", u1<=f)
        if e in ["","__lt__", "<"]:                                                 # __lt__
            print("__lt__ oder <",U.__lt__.__doc__)
            for f in [u1,u2]: print(_qqq+str(u1)+"<" +str(f)+" --> ", u1<f)
        if e in ["","__mul__", "*"]:                                                # __mul__
            print("__mul__ oder *",U.__mul__.__doc__)
            for f in [i1,i2,n1,n2]: print(_qqq+str(u1)+"*(" +str(f)+") --> ", u1*(f))
        if e in ["","__ne__", "!="]:                                                # __ne__
            print("__ne__ oder !=",U.__ne__.__doc__)
            for f in [u1,u2]: print(_qqq+str(u1)+"!=" +str(f)+" --> ", u1!=f)
        if e in ["","__neg__", "Vorzeichen -"]:                                     # __neg__
            print("__neg__ oder Vorzeichen -",U.__neg__.__doc__)
            print(_qqq+"-"+str(u1)+" --> ", -u1)
        if e in ["","__pos__", "Vorzeichen +"]:                                     # __pos__
            print("__pos__ oder Vorzeichen +",U.__pos__.__doc__)
            print(_qqq+"+"+str(u1)+" --> ", +u1)
        if e in ["","__repr__", "repr"]:                                            # __repr__
            print("__repr__ oder repr",U.__repr__.__doc__)
            print(_qqq+"repr(u1), repr(u2) --> ", repr(u1), repr(u2))
        if e in ["","__str__", "str"]:                                              # __str__
            print("__str__ oder str",U.__str__.__doc__)
            print(_qqq+"str(u1), str(u2) --> ", str(u1), str(u2))
        if e in ["", "__sub__", "-"]:                                               # __sub__
            print("__sub__ oder -",U.__sub__.__doc__)
            for f in [u1,u2]: print(_qqq+str(u1)+"-" +str(f)+" --> ", u1-f)
        if e in ["","__truediv__", "/"]:                                            # __truediv__
            print("__truediv__ oder /",U.__truediv__.__doc__)
            for f in [i1,i2,r1,r2,u1,u2]: print(_qqq+str(u1)+"/(" +str(f)+") --> ", u1/f)
        if e in ["","description"]:                                                 # description
            print("description",U.description.__doc__)
            print(_qqq+"U.description() --> ", U.description())
        if e in ["","info"]:                                                        # info
            print("info",U.info.__doc__)
            print(_qqq+str(u1)+".info() --> ");u1.info()
            print(_qqq+str(u2)+".info(lang) --> ");u2.info(lang)
        if e in ["","to"]:                                                          # to
            print("to",U.to.__doc__)
            print(_qqq+str(u1)+".to(s) --> ",u1.to(_s))
            print(_qqq+str(u2)+".to(h) --> ",u2.to(_h))
            print(_qqq+str(u1)+".to(minute) --> ",u1.to(_minute))

# ----------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse U und ihre Methoden aus.

        Aufruf: U.classInfo(m=art) oder U.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles     : alles [Voreinstellung]
        + "H"/Kopf      : globale Informationen
        + "V"/Variablen : Variablen/Eigenschaften
        + "M"/Methoden  : Methoden"""
        
        # lokale Hilfsvariable: s1, s2, s3
        
        s1 = "U."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class U\n", U.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der U-Instanzen:

    u.v        Wert der Instanz  (gemessen in s)
    u.u        Maßeinheit der Instanz: s
    u.v1       Wert der Stunden  (gemessen in h)
    u.v2       Wert der Minuten  (gemessen in minute)
    u.v3       Wert der Sekunden (gemessen in s)
    u.name     Name der Instanz
    u.internal interner Wert
    """)
        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(U):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)

# ---------------------------------------------------------
    def description():
        """
        Liefert eine Kurzbeschreibung der Klasse U.

        Aufruf: description()"""
        
        return "Operationen mit U-Instanzen (Uhrzeiten)"
    
# ---------------------------------------------------------
    def info(self, m=kurz):
        """
        Gibt Informationen über eine U-Instanz aus.

        Aufruf: u.info(modus)
        mögliche Angaben für m:
        - kurz  nur Grundangaben
                [Voreinstellung]
        - lang  zusätzlich auch Darstellung in anderen Einheiten"""
        
        # lokale Hilfsvariable: mm, mmm, ss, sss
        
        sss = _str_aus(self.internal)
        print("Name           :", self.name)
        print("Art            :", "U-Instanz (Uhrzeit)")
        print("Wert (Stunden) :", self.v1)
        print("Wert (Minuten) :", self.v2)
        print("Wert (Sekunden):", self.v3)
        print("interner Wert  :", sss, "(in s)")
        if m == lang:
            print("Darstellung in anderen Einheiten:")
            for f in sorted(_time1, key=str.lower):
                mm  = self.to(f)
                mmm = _str_aus(mm.v)
                del mm
                print(leer, f.ljust(8), str(mmm).ljust(22), "(" + _descript[f] + ")")
        print(_q)

    ci = classInfo # Alias für classInfo()


# =========================================================
class T2:
    """
    Realisiert das Rechnen mit T2-Instanzen (Zeiten hoch 2).

    Aufruf: T2.__init__(value=1, unit=s2, n="")

    Parameter:

    value=1: Wert;
             Voreinstellung: 1
    unit=s2: T2-Maßeinheit;
             Voreinstellung: s2
    n=""   : Name der T2-Instanz;
             Voreinstellung: leere Zeichenkette

    Methoden:

    t : T2-Instanz (Zeit hoch 2)
    o : Instanz
    n : Zahl(Integer/Float)
    p : Integer
    u : eine der zulässigen T2-Maßeinheiten

    t.__abs__() oder abs(t)    Liefert den Absolut-Betrag der T2-Instanz.
    t.__add__(t) oder t + t    Realisiert die Addition zweier T2-Instanzen.
    t.__eq__(t) oder t == t    Realisiert den Vergleich == in T2.
    t.__ge__(t) oder t >= t    Realisiert den Vergleich >= in T2.
    t.__gt__(t) oder t > t     Realisiert den Vergleich > in T2.
    t.__le__(t) oder t <= t    Realisiert den Vergleich <= in T2.
    t.__lt__(t) oder t < t     Realisiert den Vergleich < in T2.
    t.__mul__(o) oder t * o    Realisiert die Multiplikation einer T2-Instanz.
    t.__ne__(t) oder t != t    Realisiert den Vergleich != in T2.
    t.__neg__() oder -(t)      Realisiert negatives Vorzeichen für eine
                               T2-Instanz.
    t.__pos__() oder +(t)      Realisiert positives Vorzeichen für eine
                               T2-Instanz.
    t.__pow__(p) oder t ** p   Realisiert das Potenzieren einer T2-Instanz.
    t.__repr__() oder repr(t)  Repräsentiert eine T2-Instanz.
    t.__str__() oder str(t)    Repräsentiert eine T2-Instanz.
    t.__sub__(t) oder t - t    Realisiert die Subtraktion.
    t.__truediv__(o) oder t / o Realisiert die Division einer T2-Instanz.
    t.info(modus)              Gibt Informationen über eine T2-Instanz aus.
    t.to(u)                    Realisiert die Konvertierung einer T2-Instanz in
                               eine andere Maßeinheit.
    T2.__init__(value=1,unit=s2,n="") Initialisiert eine T2-Instanz.
    T2.beispiel(e)             Liefert Beispiele für die Methoden der Klasse T2.
    T2.classInfo(m=art)        Gibt Informationen zur Klasse T2 und ihre Methoden
                               aus.
    T2.ci(m=art)               Alias für T2.classInfo(m=art)
    T2.description()           Gibt eine Kurzbeschreibung der Klasse T2 aus.
"""

    global eps, trennz

# ---------------------------------------------------------
    def __abs__(self):
        """
        Liefert den Absolut-Betrag der T2-Instanz.

        Aufruf: t.__abs__() oder abs(t)"""
        
        name = "abs(" + str(self) + ")"
        return T2(abs(self.v), self.u, n=name)

# ---------------------------------------------------------
    def __add__(self, t):
        """
        Realisiert die Addition zweier T2-Instanzen.

        Aufruf: t.__add__(t) oder t + t
        erlaubter Typ des Operanden:
        - T2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(t, T2)):
            raise TypeError(_fehler3 + str(t))
        name = str(self) + " + " + t.name
        return T2(self.internal + t.internal, _s2, n=name)

# ---------------------------------------------------------
    def __eq__(self, t):
        """
        Realisiert den Vergleich == in T2.

        Aufruf: t.__eq__(t) oder t == t
        erlaubter Typ des Operanden:
        - T2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(t, T2)):
            raise TypeError(_fehler3 + str(t))
        return abs(self.internal - t.internal) <= eps

# ---------------------------------------------------------
    def __ge__(self, t):
        """
        Realisiert den Vergleich >= in T2.

        Aufruf: t.__ge__(t) oder t >= t
        erlaubter Typ des Operanden:
        - T2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(t, T2)):
            raise TypeError(_fehler3 + str(t))
        return (self.internal > t.internal) or (abs(self.internal - t.internal) <= eps)

# ---------------------------------------------------------
    def __gt__(self, t):
        """
        Realisiert den Vergleich > in T2.

        Aufruf: t.__gt__(t) oder t > t
        erlaubter Typ des Operanden:
        - T2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(t, T2)):
            raise TypeError(_fehler3 + str(t))
        return (self.internal > t.internal)

# ---------------------------------------------------------
    def __init__(self, value=1, unit=_s2, n=""):
        """
        Initialisiert eine T2-Instanz.

        Aufruf: T2.__init__(value=1, unit=s2, n="")
        Parameter:
        - value: Wert der T2-Instanz;
                 Voreinstellung: 1
        - unit : eine zulässige T2-Maßeinheit;
                 Voreinstellung: s2
        - n    : Name der T2-Instanz;
                 Voreinstellung: leere Zeichenkette
        mögliche Fehlermeldung:
        - Unit ist hier nicht bekannt/zulässig"""
        
        global trennz
        
        if not (unit in _time2):
            raise ValueError(_fehler2 + str(unit))
        self.v = value
        self.u = unit
        self.internal = self.v * _time2[self.u]
        if n == "":
            self.name = "T2(" + str(_str_aus(self.v)) + trennz + self.u + ")"
        else:
            self.name = n
        T2Liste.append(self)

# ---------------------------------------------------------
    def __le__(self, t):
        """
        Realisiert den Vergleich <= in T2.

        Aufruf: t.__le__(t) oder t <= t
        erlaubter Typ des Operanden:
        - T2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(t, T2)):
            raise TypeError(_fehler3 + str(t))
        return (self.internal < t.internal) or (abs(self.internal - t.internal) <= eps)

# ---------------------------------------------------------
    def __lt__(self, t):
        """
        Realisiert den Vergleich < in T2.

        Aufruf: t.__lt__(t) oder t < t
        erlaubter Typ des Operanden:
        - T2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        if not (isinstance(t, T2)):
            raise TypeError(_fehler3 + str(t))
        return (self.internal < t.internal)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert die Multiplikation einer T2-Instanz.

        Aufruf: t.__mul__(o) oder t * o
        mögliche Typen des Operanden:
        - L1, L2, L3, T1, T2, TT, M, int, float, N, G, V, B, F1, W, P
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]
        # lokale Hilfsvariable: name
        
        name = str(self) + " * (" + str(o) + ")"
        if typ(o) in ["int", "float"]:
            return T2(self.v * o, self.u, n=name)
        elif isinstance(o, N):
            return T2(self.v * o.v, self.u, n=name)
        elif isinstance(o, B):  
            zwi = G(self, mul, N(1)) * o
            return meter(zwi.internal, n=name)
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "V", "F1", "W", "P", "G"]:
            return G(self, mul, o, n=name)
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __ne__(self, t):
        """
        Realisiert den Vergleich != in T2.

        Aufruf: t.__ne__(t) oder t != t
        erlaubter Typ des Operanden:
        - T2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(t, T2)):
            raise TypeError(_fehler3 + str(t))
        return abs(self.internal - t.internal) > eps

# ---------------------------------------------------------
    def __neg__(self):
        """
        Realisiert negatives Vorzeichen für eine T2-Instanz.

        Aufruf: t.__neg__() oder -(t)"""
        
        return T2(-self.v, self.u)

# ---------------------------------------------------------
    def __pos__(self):
        """
        Realisiert positives Vorzeichen für eine T2-Instanz.

        Aufruf: t.__pos__() oder +(t)"""
        return T2(self.v, self.u)

# ---------------------------------------------------------
    def __pow__(self, p):
        """
        Realisiert das Potenzieren einer T2-Instanz.

        Aufruf: t.__pow__(p) oder t ** p
        erlaubter Typ des Operanden:
        - int, float
        erlaubte Werte für p:
        - 0, 0.5, 1
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - unsupported operand type(s) for ** or pow(): 'T2' and 'int'"""
        
        # lokale Hilfsvariable: name
        
        global eps
        if not (isinstance(p, int) or isinstance(p, float)):
            raise TypeError(_fehler3 + str(p))
        name = str(self) + " ** (" + str(p) + ")"
        if abs(p) <= eps:
            return 1
        elif abs(p - 1) <= eps:
            return T2(self.v, self.u, n=name)
        elif abs(p - 0.5) <= eps:
            return T1(math.sqrt(self.internal), _s, n=name)
        else:
            return NotImplemented

# ---------------------------------------------------------
    def __repr__(self):
        """
        Repräsentiert eine T2-Instanz.

        Aufruf: t.__repr__() oder repr(t)"""
        
        global trennz
        
        return "T2(" + _repr_aus(self.v) + trennz + self.u + ")"

# ---------------------------------------------------------
    def __str__(self):
        """
        Repräsentiert eine T2-Instanz.

        Aufruf: t.__str__() oder str(t)"""
        
        global trennz
        
        return "T2(" + _str_aus(self.v) + trennz + self.u + ")"

# ---------------------------------------------------------
    def __sub__(self, t):
        """
        Realisiert die Subtraktion zweier T2-Instanzen.

        Aufruf: t.__sub__(t) oder t - t
        erlaubter Typ des Operanden:
        - T2
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(t, T2)):
            raise TypeError(_fehler3 + str(t))
        name = str(self) + " - " + t.name
        return T2(self.internal - t.internal, _s2, n=name)

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert die Division einer T2-Instanz.

        Aufruf: t.__truediv__(o) oder t / o
        möglicher Typ des Operanden:
        - T2, T1, int, float, L1, L2, L3, M, TT, N, G, V, B, F1, W, P
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - Operand hat den Wert Null."""
        
        global eps
        
        # lokale Hilfsvariable: name
        
        name = str(self) + " / (" + str(o) + ")"
        if typ(o) in ["int", "float"]:
            if abs(o) <= eps:
                raise ValueError(_fehler4 + str(o))
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P"]:
            if abs(o.internal) <= eps:
                raise ValueError(_fehler4 + str(o))

        if typ(o) in ["int", "float"]:
            return T2(self.internal / o, self.u, n=name)          # T2/Skalar --> T2
        elif isinstance(o, T1):
            return T1(self.internal / o.internal, _s, n=name)     # T2/T1 --> T1
        elif isinstance(o, T2):
            return self.internal / o.internal                     # T2/T2 --> Skalar
        elif isinstance(o, N):
            return T2(self.internal / o.internal, self.u, n=name) # T2/N --> T2
        elif typ(o) in ["L1", "L2", "L3", "M", "TT", "T1", "T2", "V", "B", "F1", "W", "P"]:
            return G(self, div, o, n=name)                        # T2/sonst --> G
        else:
            raise TypeError(_fehler3 + str(t))

# ----------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse T2.

        Aufruf: T2.beispiel(e)
        für e kann "!=", "-", "*", "**", "/", "__add__", "__eq__", "__ge__",
        "__gt__", "__le__", "__lt__", "__mul__", "__ne__", "__neg__", "__pos__",
        "__pow__", "__repr__", "__str__", "__sub__", "__truediv__", "+", "<",
        "<=", "==", ">", ">=", "description", "info", "repr", "str", "to",
        "Vorzeichen -", "Vorzeichen +", leere Zeichenkette [Voreinstellung]
        angegeben werden"""
        
        print("""
        l11=L1(2,m);l12=L1(3,cm);l21=L2(4,mm2);l22=L2(5,km2);l31=L3(6,liter);
        l32=L3(7,dl);n1=N(2);n1=N(-3);t11=T1(8,s);t12=T1(9,h);t21=T2(10,s2);
        t22=T2(11,d2);m11=M(12,g);m12=M(13,kg);tt1=TT(14,C);tt2=TT(15,K);
        g1=G(l11,div,t11);g2=G(t11,mul,m1);i1=2;i2=(-5)""")
        l11=L1(2,_m);l12=L1(3,_cm);l21=L2(4,_mm2);l22=L2(5,_km2);l31=L3(6,_liter);l32=L3(7,_dl);n1=N(2);n1=N(-3);
        t11=T1(8,_s);t12=T1(9,_h);t21=T2(10,_s2);t22=T2(11,_d2);m11=M(12,_g);m12=M(13,_kg);tt1=TT(14,_C);tt2=TT(15,_K);
        g1=G(l11,div,t11);g2=G(t11,mul,m11);i1=2;i2=(-5)
        if e in ["","__add__", "+"]:                                               # __add__
            print("__add__ oder +",T2.__add__.__doc__)
            for f in [t22]: print(_qqq+str(t21)+"+" +str(f)+" --> ", t21+f)
        if e in ["","__eq__", "=="]:                                               # __eq__
            print("__eq__ oder ==",T2.__eq__.__doc__)
            for f in [t22]: print(_qqq+str(t21)+"==" +str(f)+" --> ", t21==f)
        if e in ["","__ge__", ">="]:                                               # __ge__
            print("__ge__ oder >=",T2.__ge__.__doc__)
            for f in [t22]: print(_qqq+str(t21)+">=" +str(f)+" --> ", t21>=f)
        if e in ["","__gt__", ">"]:                                                # __gt__
            print("__gt__ oder >",T2.__gt__.__doc__)
            for f in [t22]: print(_qqq+str(t21)+">" +str(f)+" --> ", t21>f)
        if e in ["","__le__", "<="]:                                               # __le__
            print("__le__ oder <=",T2.__le__.__doc__)
            for f in [t22]: print(_qqq+str(t21)+"<=" +str(f)+" --> ", t21<=f)
        if e in ["","__lt__", "<"]:                                                # __lt__
            print("__lt__ oder <",T2.__lt__.__doc__)
            for f in [t22]: print(_qqq+str(t21)+"<" +str(f)+" --> ", t21<f)
        if e in ["","__mul__", "*"]:                                               # __mul__
            print("__mul__ oder *",T2.__mul__.__doc__)
            for f in [i1,l11,l21,l31,n1,t11,t21,t22,m11,tt1,g1,g2]: print(_qqq+str(t21)+"*" +str(f)+" --> ", t21*f)
        if e in ["","__ne__", "!="]:                                               # __ne__
            print("__ne__ oder !=",T2.__ne__.__doc__)
            for f in [t22]: print(_qqq+str(t21)+"!=" +str(f)+" --> ", t21!=f)
        if e in ["","__neg__", "Vorzeichen -"]:                                    # __neg__
            print("__neg__ oder Vorzeichen -",T2.__neg__.__doc__)
            print(_qqq+"-"+str(t21)+" --> ", -t21)
        if e in ["","__pos__", "Vorzeichen +"]:                                    # __pos__
            print("__pos__ oder Vorzeichen +",T2.__pos__.__doc__)
            print(_qqq+"+"+str(t21)+" --> ", +t21)
        if e in ["","__pow__", "**"]:                                              # __pow__
            print("__pow__ oder **",T2.__pow__.__doc__)
            print(_qqq+str(t21)+"**0.5 --> ", t21**0.5)
            print(_qqq+str(t22)+"**0 --> ", t22**0)
        if e in ["","__repr__", "repr"]:                                           # __repr__
            print("__repr__ oder repr",T2.__repr__.__doc__)
            print(_qqq+"repr(t21), repr(t22) --> ", repr(t21), repr(t22))
        if e in ["","__str__", "str"]:                                             # __str__
            print("__str__ oder str",T2.__str__.__doc__)
            print(_qqq+"str(t21), str(t22) --> ", str(t21), str(t22))
        if e in ["","__sub__", "-"]:                                               # __sub__
            print("__sub__ oder -",T2.__sub__.__doc__)
            for f in [t22]: print(_qqq+str(t21)+"-" +str(f)+" --> ", t21-f)
        if e in ["","__truediv__", "/"]:                                           # __truediv__
            print("__truediv__ oder /",T2.__truediv__.__doc__)
            for f in [i1,l11,l21,l31,n1,t11,t21,t22,m11,tt1]: print(_qqq+str(t21)+"/" +str(f)+" --> ", t21/f)
        if e in ["","description"]:                                                # description
            print("description",T2.description.__doc__)
            print(_qqq+"T2.description() --> ", T2.description())
        if e in ["","info"]:                                                       # info
            print("info",T2.info.__doc__)
            print(_qqq+str(t21)+".info() --> ");t21.info()
            print(_qqq+str(t22)+".info(lang) --> ");t22.info(lang)
        if e in ["","to"]:                                                         # to
            print("to",T2.to.__doc__)
            print(_qqq+str(t21)+".to(h2) --> ",t21.to(_h2))
            print(_qqq+str(t22)+".to(s2) --> ",t22.to(_s2))

# ----------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse T2 und ihre Methoden aus.

        Aufruf: T2.classInfo(m=art) oder T2.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles    : alles [Voreinstellung]
        + "H"/Kopf     : globale Informationen
        + "V"/Variablen: Variablen/Eigenschaften
        + "M"/Methoden : Methoden
        + "E"/Einheiten: Einheiten"""
        
        # lokale Hilfsvariable: s1, s2, s3
        
        s1 = "T2."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class T2\n", T2.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der T2-Instanzen:

    t.v        Wert der Instanz (gemessen in t.u)
    t.u        Maßeinheit der Instanz (T2-Maßeinheit)
    t.name     Name der Instanz
    t.internal interner Wert
    """)
        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(T2):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)
        if m in ["A", "E"]:
            print('Einheiten\n')
            au("T2")

# ---------------------------------------------------------
    def description():
        """
        Liefert eine Kurzbeschreibung der Klasse T2.

        Aufruf: description()"""
        
        return "Operationen mit T2-Instanzen (Zeiteinheiten hoch 2)"

# ---------------------------------------------------------
    def info(self, m=kurz):
        """
        Gibt Informationen über eine T2-Instanz aus.

        Aufruf: t.info(modus)
        m Modus
          kurz  nur Grund-Eigenschaften
                [Voreinstellung]
          lang  auch Darstellung in anderen Einheiten"""

        # lokale Hilfsvariable: mm, mmm, ss, sss
        
        ss  = _str_aus(self.v)
        sss = _str_aus(self.internal)
        print("Name         :", self.name)
        print("Art          :", "T2-Instanz (Zeit hoch 2)")
        print("Wert         :", ss, "(in " + self.u + ")")
        print("Einheit      :", self.u, "["+_descript[self.u]+"]")
        print("interner Wert:", sss, "(in s2)")
        if m == lang:
            print("Darstellung in anderen Einheiten:")
            for f in sorted(_time2, key=str.lower):
                mm  = self.to(f)
                mmm = _str_aus(mm.v)
                print(leer, f.ljust(7), str(mmm).ljust(21), "(" + _descript[f] + ")")
        print(_q)

# ---------------------------------------------------------
    def to(self, unit):
        """
        Realisiert die Konvertierung einer T2-Instanz in eine andere Maßeinheit.

        Aufruf: t.to(unit)
        erlaubter Typ des Operanden:
        - eine der zulässigen T2-Maßeinheiten
        mögliche Fehlermeldung:
        - Unit ist hier nicht bekannt/zulässig"""
        
        # lokale Hilfsvariable: z, name
        
        if not (unit in _time2):
            raise ValueError(_fehler2 + str(unit))
        z = self.internal / _time2[unit]
        name = str(self) + "--->" + unit
        return T2(z, unit, n=name)

    ci = classInfo # Alias für classInfo()

# =========================================================
class TT:
    """
    Realisiert das Rechnen mit TT-Instanzen (Temperaturen).

    Aufruf: TT.__init__(value=1, unit=K, n="")

    Parameter:

    value=1: Wert;
             Voreinstellung: 1
    unit=K : TT-Maßeinheit;
             Voreinstellung: K
    n=""   : Name der TT-Instanz;
             Voreinstellung: leere Zeichenkette

    Methoden:

    tt : TT-Instanz (Temperatur)
    o  : Instanz
    n  : Zahl(Integer/Float)
    p  : Integer
    u  : eine der zulässigen TT-Maßeinheiten

    (alle Operationen beziehen sich auf Grad Kelvin)

    tt.__add__(tt) oder tt + tt  Realisiert die Addition zweier TT-Instanzen.
    tt.__eq__(tt) oder tt == tt  Realisiert den Vergleich == in TT.
    tt.__ge__(tt) oder tt >= tt  Realisiert den Vergleich >= in TT.
    tt.__gt__(tt) oder tt > tt   Realisiert den Vergleich > in TT.
    TT.__init__(value=1,unit=K,n="") Initialisiert eine TT-Instanz.
    tt.__le__(tt) oder tt <= tt  Realisiert den Vergleich <= in TT.
    tt.__lt__(tt) oder tt < tt   Realisiert den Vergleich < in TT.
    tt.__mul__(o) oder tt * o    Realisiert die Multiplikation in TT.
    tt.__ne__(tt) oder tt != tt  Realisiert den Vergleich != in TT.
    tt.__neg__() oder -(tt)      Realisiert negatives Vorzeichen für eine
                                 TT-Instanz. (nicht verfügbar)
    tt.__pos__() oder +(tt)      Realisiert positives Vorzeichen für eine
                                 TT-Instanz. (nicht verfügbar)
    tt.__pow__(p) oder tt ** p   Realisiert das Potenzieren einer TT-Instanz.
    tt.__repr__() oder repr(tt)  Repräsentiert eine TT-Instanz.
    tt.__str__() oder str(tt)    Repräsentiert eine TT-Instanz.
    tt.__sub__(tt) oder tt - tt  Realisiert die Subtraktion zweier TT-Instanzen.
    tt.__truediv__(o) oder tt / o Realisiert die Division einer TT-Instanz.
    TT.beispiel(e)               Liefert Beispiele für die Methoden der Klasse TT.
    TT.classInfo(m=art)          Gibt Informationen zur Klasse TT und ihre
                                 Methoden aus.
    TT.ci(m=art)                 Alias für TT.classInfo(m=art)
    TT.description()             Gibt eine Kurzbeschreibung der Klasse TT aus.
    tt.info(modus)               Gibt Informationen über eine TT-Instanz aus.
    tt.to(u)                     Realisiert die Konvertierung einer TT-Instanz in
                                 eine andere Maßeinheit.
    """

    global eps, trennz

# ---------------------------------------------------------
    def __abs__(self):
        """
        Liefert den Absolut-Betrag der TT-Instanz.

        Aufruf: t.__abs__() oder abs(t)
        mögliche Fehlermeldung:
        - NotImplemented"""
        
        return NotImplemented

# ---------------------------------------------------------
    def __add__(self, tt):
        """
        Realisiert die Addition zweier TT-Instanzen.

        Aufruf: tt.__add__(tt) oder tt + tt
        erlaubter Typ des Operanden:
        - TT
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - Unit ist hier nicht bekannt/zulässig."""
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(tt, TT)):
            raise TypeError(_fehler3 + str(tt))
        if self.u != tt.u:
            raise ValueError(_fehler2 + str(tt.u))
        name = str(self) + " + " + tt.name
        return TT(self.v + tt.v, self.u, n=name)

# ---------------------------------------------------------
    def __eq__(self, tt):
        """
        Realisiert den Vergleich == in TT.

        Aufruf: tt.__eq__(tt) oder tt == tt
        erlaubter Typ des Operanden:
        - TT
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(tt, TT)):
            raise TypeError(_fehler3 + str(tt))
        return abs(self.internal - tt.internal) <= eps

# ---------------------------------------------------------
    def __ge__(self, tt):
        """
        Realisiert den Vergleich >= in TT.

        Aufruf: tt.__ge__(tt) oder tt >= tt
        erlaubter Typ des Operanden:
        - TT
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(tt, TT)):
            raise TypeError(_fehler3 + str(tt))
        return (self.internal > tt.internal) or (abs(self.internal - tt.internal) <= eps)

# ---------------------------------------------------------
    def __gt__(self, tt):
        """
        Realisiert den Vergleich > in TT.

        Aufruf: tt.__gt__(tt) oder tt > tt
        erlaubter Typ des Operanden:
        - TT
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(tt, TT)):
            raise TypeError(_fehler3 + str(tt))
        return (self.internal > tt.internal)

# ---------------------------------------------------------
    def __init__(self, value=1, unit=_K, n=""):
        """
        Initialisiert eine TT-Instanz.

        Aufruf: TT.__init__(value=1, unit=K, n="")
        Parameter:
        - value: Wert der TT-Instanz;
                 Voreinstellung: 1
        - unit : eine zulässige TT-Maßeinheit;
                 Voreinstellung: K
        - n    : Name der TT-Instanz;
                 Voreinstellung: leere Zeichenkette
        mögliche Fehlermeldung:
        - Unit ist hier nicht bekannt/zulässig"""
        
        global trennz
        
        if not (unit in _temp):
            raise ValueError(_fehler2 + str(unit))
        self.v = value
        self.u = unit
        if unit == _K:
            self.internal = self.v
        elif unit == _C:
            self.internal = self.v + _absK
        elif unit == _R:
            self.internal = 5 / 4 * self.v + _absK
        elif unit == _F:
            self.internal = (self.v - 32) * 5 / 9 + _absK
        if n == "":
            self.name = "TT(" + str(_str_aus(self.v)) + trennz + self.u + ")"
        else:
            self.name = n
        TTListe.append(self)

# ---------------------------------------------------------
    def __le__(self, tt):
        """
        Realisiert den Vergleich <= in TT.

        Aufruf: tt.__le__(tt) oder tt <= tt
        erlaubter Typ des Operanden:
        - TT
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(tt, TT)):
            raise TypeError(_fehler3 + str(tt))
        return (self.internal < tt.internal) or (abs(self.internal - tt.internal) <= eps)

# ---------------------------------------------------------
    def __lt__(self, tt):
        """
        Realisiert den Vergleich < in TT.

        Aufruf: tt.__lt__(tt) oder tt < tt
        erlaubter Typ des Operanden:
        - TT
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        if not (isinstance(tt, TT)):
            raise TypeError(_fehler3 + str(tt))
        return (self.internal < tt.internal)

# ---------------------------------------------------------
    def __mul__(self, o):
        """
        Realisiert die Multiplikation einer TT-Instanz.

        Aufruf: tt.__mul__(o) oder tt * o
        funktioniert nur für self.u == K
        mögliche Typen des Operanden:
        - L1, L2, L3, T1, T2, TT, M, int, float, N, G, V, B, F1, W, P
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - unsupported operand type(s) for ..."""
        
        # typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P", "G"]
        # lokale Hilfsvariable: name, b1, b2
        
        name = str(self) + " * (" + str(o) + ")"
        if self.u != _K:
            return NotImplemented
        if isinstance(o, TT):
            if (o.u != _K):
                return NotImplemented
        if typ(o) in ["int", "float"]:
            return TT(self.internal * o, _K, n=name)
        elif isinstance(o, N):
            return TT(self.internal * o.internal, _K, n=name)
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "V", "B", "F1", "W", "P", "G"]:
            return G(self, mul, o, n=name)
        else:
            raise TypeError(_fehler3 + str(o))

# ---------------------------------------------------------
    def __ne__(self, tt):
        """
        Realisiert den Vergleich != in TT.

        Aufruf: tt.__ne__(tt) oder tt != tt
        erlaubter Typ des Operanden:
        - TT
        mögliche Fehlermeldung:
        - Operand hat keinen zulässigen Typ."""
        
        global eps
        
        if not (isinstance(tt, TT)):
            raise TypeError(_fehler3 + str(tt))
        return abs(self.internal - tt.internal) > eps

# ---------------------------------------------------------
    def __neg__(self):
        """
        Realisiert negatives Vorzeichen für eine TT-Instanz. (nicht verfügbar)

        Aufruf: tt.__neg__() oder -(tt)
        mögliche Fehlermeldung:
        - NotImplemented"""
        
        return NotImplemented

# ---------------------------------------------------------
    def __pos__(self):
        """
        Realisiert positives Vorzeichen für eine TT-Instanz. (nicht verfügbar)

        Aufruf: tt.__pos__() oder +(tt)
        mögliche fehlerfmeldung:
        - NotImplemented"""
        
        return NotImplemented

# ---------------------------------------------------------
    def __pow__(self, p):
        """
        Realisiert das Potenzieren einer TT-Instanz.

        Aufruf: tt.__pow__(p) oder tt ** p
        erlaubter Typ des Operanden:
        - int, float
        erlaubter Wert des Operanden p:
        - 0, 1
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - unsupported operand type(s) for ** or pow(): 'TT' and 'int'"""
        
        global eps
        
        if not (isinstance(p, int) or isinstance(p, float)):
            raise TypeError(_fehler3 + str(p))
        if abs(p) <= eps:
            return 1
        elif abs(p - 1) <= eps:
            name = str(self) + " ** " + str(p)
            return TT(self.v, self.u, n=name)
        else:
            return NotImplemented

# ---------------------------------------------------------
    def __repr__(self):
        """
        Repräsentiert eine TT-Instanz.

        Aufruf: tt.__repr__() oder repr(tt)"""
        
        global trennz
        
        return "TT(" + _repr_aus(self.v) + trennz + self.u + ")"

# ---------------------------------------------------------
    def __str__(self):
        """
        Repräsentiert eine TT-Instanz.

        Aufruf: tt.__str__() oder str(tt)"""
        
        global trennz
        
        return "TT(" + _str_aus(self.v) + trennz + self.u + ")"

# ---------------------------------------------------------
    def __sub__(self, tt):
        """
        Realisiert die Subtraktion zweier TT-Instanzen.

        Aufruf: tt.__sub__(tt) oder tt - tt
        erlaubter Typ des Operanden:
        - TT
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - Unit ist hier nicht bekannt/zulässig."""
        
        # lokale Hilfsvariable: name
        
        if not (isinstance(tt, TT)):
            raise TypeError(_fehler3 + str(tt))
        if self.u != tt.u:
            raise ValueError(_fehler2 + str(tt.u))
        name = str(self) + " - " + tt.name
        return TT(self.v - tt.v, self.u, n=name)

# ---------------------------------------------------------
    def __truediv__(self, o):
        """
        Realisiert die Division einer TT-Instanz.

        Aufruf: tt.__truediv__(o) oder tt / o
        funktioniert nur für self.u == K
        möglicher Typ des Operanden:
        - int, float, TT, L1, L2, L3, M, T1, T2, N, G, V, B, F1, W, P
        mögliche Fehlermeldungen:
        - Operand hat keinen zulässigen Typ.
        - Operand hat den Wert Null.
        - unsupported operand type(s) for /: 'TT' and 'TT'"""
        
        global eps
        
        # lokale Hilfsvariable: name
        
        name = str(self) + " / (" + str(o) + ")"
        if typ(o) in ["int", "float"]:
            if abs(o) <= eps:
                raise ValueError(_fehler4 + str(o))
        elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "TT", "T1", "T2", "N", "V", "B", "F1", "W", "P"]:
            if abs(o.internal) <= eps:
                raise ValueError(_fehler4 + str(o))

        if self.u == _K:
            if typ(o) in ["int", "float"]:
                return TT(self.internal / o, _K, n=name)          # TT/Skalar ---> TT
            elif isinstance(o, TT):
                if o.u == _K:
                    return self.internal / o.internal             # TT/TT ---> Skalar
                else:
                    return NotImplemented
            elif isinstance(o, N):
                return TT(self.internal / o.internal, _K, n=name) # TT/N ---> TT
            elif typ(o) in ["L1", "L2", "L3", "T1", "T2", "M", "T1", "T2", "V", "B", "F1", "W", "P"]:
                return G(self, div, o, n=name)                    # TT/sonst ---> G
            else:
                raise TypeError(_fehler3 + str(o))
        else:
            return NotImplemented

# ----------------------------------------------------------
    def beispiel(e=""):
        """
        Liefert Beispiele für die Methoden der Klasse TT.

        Aufruf: TT.beispiel(e)
        für e kann "__add__", "+", "__eq__", "==", "__ge__", ">=", "__gt__", ">",
        "__le__", "<=", "__lt__", "<", "__mul__", "*", "__ne__", "!=", "__neg__",
        "Vorzeichen -", "__pos__", "Vorzeichen +", _pow__", "**", "__repr__",
        "repr", "__str__", "str", "__sub__", "-", "__truediv__", "/",
        "description", "info", "to", leere Zeichenkette [Voreinstellung] angegeben
        werden"""
        
        print("""
        l11=L1(2,m);l12=L1(3,cm);l21=L2(4,mm2);l22=L2(5,km2);l31=L3(6,liter);
        l32=L3(7,dl);n1=N(2);n1=N(-3);t11=T1(8,s);t12=T1(9,h);t21=T2(10,s2);
        t22=T2(11,d2);m11=M(12,g);m12=M(13,kg);tt1=TT(104,K);tt2=TT(15,K);
        g1=G(l11,div,t11);g2=G(t11,mul,m1);i1=2;i2=(-5)""")
        l11=L1(2,_m);l12=L1(3,_cm);l21=L2(4,_mm2);l22=L2(5,_km2);l31=L3(6,_liter);l32=L3(7,_dl);n1=N(2);n1=N(-3);
        t11=T1(8,_s);t12=T1(9,_h);t21=T2(10,_s2);t22=T2(11,_d2);m11=M(12,_g);m12=M(13,_kg);tt1=TT(104,_K);tt2=TT(15,_K);
        g1=G(l11,div,t11);g2=G(t11,mul,m11);i1=2;i2=(-5)
        if e in ["","__add__", "+"]:                                               # __add__
            print("__add__ oder +",TT.__add__.__doc__)
            for f in [tt2]: print(_qqq+str(tt1)+"+" +str(f)+" --> ", tt1+f)
        if e in ["","__eq__", "=="]:                                               # __eq__
            print("__eq__ oder ==",TT.__eq__.__doc__)
            for f in [tt2]: print(_qqq+str(tt1)+"==" +str(f)+" --> ", tt1==f)
        if e in ["","__ge__", ">="]:                                               # __ge__
            print("__ge__ oder >=",TT.__ge__.__doc__)
            for f in [tt2]: print(_qqq+str(tt1)+">=" +str(f)+" --> ", tt1>=f)
        if e in ["","__gt__", ">"]:                                                # __gt__
            print("__gt__ oder >",TT.__gt__.__doc__)
            for f in [tt2]: print(_qqq+str(tt1)+">" +str(f)+" --> ", tt1>f)
        if e in ["","__le__", "<="]:                                               # __le__
            print("__le__ oder <=",TT.__le__.__doc__)
            for f in [tt2]: print(_qqq+str(tt1)+"<=" +str(f)+" --> ", tt1<=f)
        if e in ["","__lt__", "<"]:                                                # __lt__
            print("__lt__ oder <",TT.__lt__.__doc__)
            for f in [tt2]: print(_qqq+str(tt1)+"<" +str(f)+" --> ", tt1<f)
        if e in ["","__mul__", "*"]:                                               # __mul__
            print("__mul__ oder *",TT.__mul__.__doc__)
            for f in [i1,l11,l21,l31,n1,t11,t21,m11,g1,g2]: print(_qqq+str(tt2)+"*" +str(f)+" --> ", tt2*f)
        if e in ["","__ne__", "!="]:                                               # __ne__
            print("__ne__ oder !=",TT.__ne__.__doc__)
            for f in [tt2]: print(_qqq+str(tt1)+"!=" +str(f)+" --> ", tt1!=f)
        if e in ["","__neg__", "Vorzeichen -"]:                                    # __neg__
            print("__neg__ oder Vorzeichen -",TT.__neg__.__doc__)
            print(_qqq+"-"+str(tt1)+" --> ", -tt1)
        if e in ["","__pos__", "Vorzeichen +"]:                                    # __pos__
            print("__pos__ oder Vorzeichen +",TT.__pos__.__doc__)
            print(_qqq+"+"+str(tt1)+ " --> ", +tt1)
        if e in ["","__pow__", "**"]:                                              # __pow__
            print("__pow__ oder **",TT.__pow__.__doc__)
            print(_qqq+str(tt1)+"**0 --> ", tt1**0)
            print(_qqq+str(tt2)+"**1 --> ", tt2**1)
        if e in ["","__repr__", "repr"]:                                           # __repr__
            print("__repr__ oder repr",TT.__repr__.__doc__)
            print(_qqq+"repr(tt1), repr(tt2) --> ", repr(tt1), repr(tt2))
        if e in ["","__str__", "str"]:                                             # __str__
            print("__str__ oder str",TT.__str__.__doc__)
            print(_qqq+"str(tt1), str(tt2) --> ", str(tt1), str(tt2))
        if e in ["","__sub__", "-"]:                                               # __sub__
            print("__sub__ oder -",TT.__sub__.__doc__)
            for f in [tt2]: print(_qqq+str(tt1)+"-" +str(f)+" --> ", tt1-f)
        if e in ["","__truediv__", "/"]:                                           # __truediv__
            print("__truediv__ oder /",TT.__truediv__.__doc__)
            for f in [i1,l11,l21,l31,n1,t11,t21,m11]: print(_qqq+str(tt2)+"/" +str(f)+" --> ", tt2/f)
        if e in ["","description"]:                                                # description
            print("description",TT.description.__doc__)
            print(_qqq+"TT.description() --> ", TT.description())
        if e in ["","info"]:                                                       # info
            print("info",TT.info.__doc__)
            print(_qqq+str(tt1)+".info() --> ");tt1.info()
            print(_qqq+str(tt2)+".info(lang) --> ");tt2.info(lang)
        if e in ["","to"]:                                                         # to
            print("to",TT.to.__doc__)
            print(_qqq+str(tt1)+".to(C) --> ",tt1.to(_C))
            print(_qqq+str(tt2)+".to(F) --> ",tt2.to(_F))

# ----------------------------------------------------------
    def classInfo(m="A"):
        """
        Gibt Informationen zur Klasse TT und ihre Methoden aus.

        Aufruf: TT.classInfo(m=art) oder TT.ci(m=art)
        mögliche Angaben für m:
        + "A"/alles    : alles [Voreinstellung]
        + "H"/Kopf     : globale Informationen
        + "V"/Variablen: Variablen/Eigenschaften
        + "M"/Methoden : Methoden"""
        
        # lokale Hilfsvariable: s1, s2, s3
        
        s1 = "TT."
        s3 = ".__doc__"
        if m in ["A", "H"]:
            print("Class TT\n", TT.__doc__, _q)
        if m in ["A", "V"]:
            print("""Eigenschaften der TT-Instanzen:

    t.v        Wert der Instanz (gemessen in t.u)
    t.u        Maßeinheit der Instanz (TT-Maßeinheit)
    t.name     Name der Instanz
    t.internal interner Wert
    """)
        if m in ["A", "M"]:
            print('Methoden\n')
            for f in dir(TT):
                if not (f in _standard):
                    s2 = str(f); print(f, eval(s1 + s2 + s3)); print(_q)

# ---------------------------------------------------------
    def description():
        """
        Liefert eine Kurzbeschreibung der Klasse TT.

        Aufruf: description()"""
        
        return "Operationen mit TT-Instanzen (Temperaturen)"

# ---------------------------------------------------------
    def info(self, m=kurz):
        """
        Gibt Informationen über eine TT-Instanz aus.

        Aufruf: tt.info(m)
        m Modus
          kurz  nur Grund-Eigenschaften
                [Voreinstellung]
          lang  auch Darstellung in anderen Einheiten"""
        
        # lokale Hilfsvariable: mm, mmm, ss, sss
        
        ss  = _str_aus(self.v)
        sss = _str_aus(self.internal)
        print("Name         :", self.name)
        print("Art          :", "TT-Instanz (Temperatur)")
        print("Wert         :", ss, "(in " + self.u + ")")
        print("Einheit      :", self.u, "["+_descript[self.u]+"]")
        print("interner Wert:", sss, "(in K)")
        if m == lang:
            print("Darstellung in anderen Einheiten:")
            for f in sorted(_temp, key=str.lower):
                mm  = self.to(f)
                mmm = _str_aus(mm.v)
                print(leer, f.ljust(2), str(mmm).ljust(7), "(" + _descript[f] + ")")
        print(_q)

# ---------------------------------------------------------
    def to(self, unit):
        """
        Realisiert die Konvertierung einer TT-Einheit in eine andere TT-Maßeinheit.

        Aufruf: tt.to(unit)
        erlaubter Typ des Operanden:
        - eine der zulässigen TT-Maßeinheiten
        mögliche Fehlermeldung:
        - Unit ist hier nicht bekannt/zulässig"""
        
        # lokale Hilfsvariable: name
        
        if not (unit in _temp):
            raise ValueError(_fehler2 + str(unit))
        name = str(self) + "--->" + unit
        if unit == _K:
            return TT(self.internal, _K, n=name)
        elif unit == _C:
            return TT(self.internal - _absK, _C, n=name)
        elif unit == _R:
            return TT(4 / 5 * (self.internal - _absK), _R, n=name)
        elif unit == _F:
            return TT(32 + 9 / 5 * (self.internal - _absK), _F, n=name)
        else:
            raise ValueError(_fehler2 + str(unit))

    ci = classInfo # Alias für classInfo()

# =========================================================
# Anwendungen:

# gprocm3(m, vol)       Berechnet g/cm3.
# km_h(s, t)            Berechnet km/h.
# literpro100km(vol, s) Berechnet liter/(100km).
# literprom2(l, f)      Berechnet liter/m2.
# longweightsToM(l)     Erzeugt aus der Liste [lton, cwt, qu, stone, lb, oz, dr, grain] eine M-Instanz.
# mpros(s, t)           Berechnet m/s.
# mgprodl(m, vol)       Berechnet mg/dl.
# myfiToL1(l)           Erzeugt aus der Liste [mi, yd, ft, inch] eine L1-Instanz.
# strecke(v, t)         Berechnet die Strecke, die mit der Geschwindigkeit v in der Zeit t zurückgelegt wird.
# Upromin(anz, t)       Berechnet U/min.
# ymdToT1(l)            Erzeugt aus der Liste [zy, zmo, zd, zh, zmi, zs] eine T1-Instanz.

# ---------------------------------------------------------
def druck(k, f):
    """
    Anwendung: Berechnet (=Kraft/Fläche).

    Aufruf: druck(k, f)
    k : F1-Instanz (Kraft)
    f : L2-Instanz (Fläche)
    mögliche Fehlermeldungen:
    - Operand hat keinen zulässigen Typ.
    - Operand hat den Wert Null."""

    global eps
    
    if abs(f.internal) <= eps:
        raise ValueError(_fehler4 + str(f))
    if not isinstance(k, F1):
        raise TypeError(_fehler3 + str(k))
    if not isinstance(f, L2):
        raise TypeError(_fehler3 + str(f))
    return (k/f).to(mks)
    
# ---------------------------------------------------------
def gprocm3(m, vol):
    """
    Anwendung: Berechnet g/cm3.
    [spezifisches Gewicht]

    Aufruf: gprocm3(m, vol)
    m  : M-Instanz (Gewicht)
    vol: L3-Instanz (Volumen)
    mögliche Fehlermeldungen:
    - Operand hat keinen zulässigen Typ.
    - Operand hat den Wert Null."""

    global eps
    
    if not isinstance(m, M):
        raise TypeError(_fehler3 + str(m))
    if not isinstance(vol, L3):
        raise TypeError(_fehler3 + str(vol))
    if abs(vol.internal) <= eps:
        raise ValueError(_fehler4 + str(vol))
    return (m.to(_g) / vol.to(_cm3)).to()
    
# ---------------------------------------------------------
def impuls(m, v):
    """
    Anwendung: Berechnet den Impuls (=Masse*Geschwindigkeit)

    Aufruf: impuls(m, v)
    - m : M-Instanz (Masse)
    - v : V-Instanz (Geschwindigkeit)
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ."""
    
    if not isinstance(m, M):
        raise TypeError(_fehler3 + str(vol))
    if not isinstance(v, V):
        raise TypeError(_fehler3 + str(vol))
    return (m*v).to(_mks)
    
# ---------------------------------------------------------
##def km_h(s, t):
##    """
##    Anwendung: Berechnet km/h.
##
##    Aufruf: km_h(m, t)
##    m: L1-Instanz (Länge)
##    t: T1-Instanz (Zeit)
##    mögliche Fehlermeldungen:
##    - Operand hat keinen zulässigen Typ.
##    - Operand hat den Wert Null.
##    """
##
##    global eps
##    if not isinstance(s, L1):
##        raise TypeError(_fehler3 + str(s))
##    if not isinstance(t, T1):
##        raise TypeError(_fehler3 + str(t))
##    if abs(t.internal) <= eps:
##        raise ValueError(_fehler4 + str(t))
##    return (s/t).to(_kmh)

# ---------------------------------------------------------
def literpro100km(vol, s):
    """
    Anwendung: Berechnet liter/(100km).
    [z.B. Kraftstoffverbrauch]

    Aufruf: literpro100km(vol, s)
    vol: L3-Instanz (Volumen)
    s  : L1-Instanz (Strecke)
    mögliche Fehlermeldungen:
    - Operand hat keinen zulässigen Typ.
    - Operand hat den Wert Null."""

    global eps
    
    if not isinstance(vol, L3):
        raise TypeError(_fehler3 + str(vol))
    if not isinstance(s, L1):
        raise TypeError(_fehler3 + str(s))
    if abs(s.internal) <= eps:
        raise ValueError(_fehler4 + str(s))
    return G(vol.to(_liter), div, s.to(_hkm)).to()

# ---------------------------------------------------------
def literprom2(l, f):
    """
    Anwendung: Berechnet liter/m2.
    [Niderschlagsmenge]

    Aufruf: literprom2(l, f)
    l: L3-Instanz (Volumen)
    f: L2-Instanz (Fläche)
    mögliche Fehlermeldungen:
    - Operand hat keinen zulässigen Typ.
    - Operand hat den Wert Null."""

    global eps
    
    if not isinstance(l, L3):
        raise TypeError(_fehler3 + str(l))
    if not isinstance(f, L2):
        raise TypeError(_fehler3 + str(f))
    if abs(f.internal) <= eps:
        raise ValueError(_fehler4 + str(f))
    return G(l.to(_liter), div, f.to(_m2)).to()

# ---------------------------------------------------------
def longweightsToM(l):
    """
    Anwendung: Erzeugt aus der Liste [lton, cwt, qu, stone, lb, oz, dr, grain] ein
    M-Instanz.

    Aufruf: longweightsToM(l)   
    erlaubter Typ des Parameters:
    - Liste mit 8 Elementen
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    # lokale Hilfsvariable: lton, cwt, qu, stone, lb, oz, dr, grain, zinternal, ll, anz
    
    if not isinstance(l, list):
        raise TypeError(_fehler3 + str(l))
    anz = 8
    if len(l) > anz:
        ll = l[0:anz]
    elif len(l) == anz:
        ll = l[:]
    if len(l) < anz:
        ll = [0 for x in range(anz)]
        for f in range(len(l)):
            ll[f] = l[f]
    zlton, zcwt, zqu, zstone, zlb, zoz, zdr, zgrain = ll
    zinternal  = zlton  * _gewichte[_lton]
    zinternal += zcwt   * _gewichte[_cwt]
    zinternal += zqu    * _gewichte[_qu]
    zinternal += zstone * _gewichte[_stone]
    zinternal += zlb    * _gewichte[_lb]
    zinternal += zoz    * _gewichte[_oz]
    zinternal += zdr    * _gewichte[_dr]
    zinternal += zgrain * _gewichte[_grain]
    return M(zinternal, _kg)

# ---------------------------------------------------------
def mpros(s, t):
    """
    Anwendung: Berechnet m/s.

    Aufruf: mpros(s, t)
    s: L1-Instanz (Strecke)
    t: T1-Instanz (zeit)
    mögliche Fehlermeldungen:
    - Operand hat keinen zulässigen Typ.
    - Operand hat den Wert Null."""

    global eps
    
    if not isinstance(s, L1):
        raise TypeError(_fehler3 + str(s))
    if not isinstance(t, T1):
        raise TypeError(_fehler3 + str(t))
    if abs(t.internal) <= eps:
        raise ValueError(_fehler4 + str(t))
    return (s/t).to(_mks)

# ---------------------------------------------------------
def mgprodl(m, vol):
    """
    Anwendung: Berechnet mg/dl.
    [z.B. Insulin-Messung]

    Aufruf: mgprodl(m, vol)
    m  : M-Instanz (Masse)
    vol: L3-Instanz (Volumen)
    mögliche Fehlermeldungen:
    - Operand hat keinen zulässigen Typ.
    - Operand hat den Wert Null."""

    global eps
    
    if not isinstance(m, M):
        raise TypeError(_fehler3 + str(m))
    if not isinstance(vol, L3):
        raise TypeError(_fehler3 + str(vol))
    if abs(vol.internal) <= eps:
        raise ValueError(_fehler4 + str(vol))
    return (m.to(_mg) / vol.to(_dl)).to()

# ---------------------------------------------------------
def myfiToL1(l):
    """
    Anwendung: Erzeugt aus der Liste [mi, yd, ft, inch] eine L1-Instanz.

    Aufruf: myfiToL1(l)
    erlaubter Typ des Parameters:
    - Liste mit 4 Elementen [mi, yd, ft, inch]
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    # lokale Hilfsvariable: zmi, zyd, zft, zinch, zinternal, ll, anz
    
    if not isinstance(l, list):
        raise TypeError(_fehler3 + str(l))
    anz = 4
    if len(l) > anz:
        ll = l[0:anz]
    elif len(l) == anz:
        ll = l[:]
    if len(l) < anz:
        ll = [0 for x in range(anz)]
        for f in range(len(l)):
            ll[f] = l[f]
    zmi, zyd, zft, zinch = ll
    zinternal  = zmi   * _lengths1[_mi]
    zinternal += zyd   * _lengths1[_yd]
    zinternal += zft   * _lengths1[_ft]
    zinternal += zinch * _lengths1[_inch]
    return L1(zinternal, _m)

# ---------------------------------------------------------
##def strecke(v, t):
##    """
##    Anwendung: Berechnet die Strecke, die mit der Geschwindigkeit v in der Zeit t zurückgelegt wird.
##
##    Aufruf: strecke(v, t)
##    v: G-Instanz
##    t: T1-Instanz (Zeit)
##    mögliche Fehlermeldungen:
##    - Operand hat keinen zulässigen Typ.
##    - Operand hat den Wert Null.
##    """
##    
##    global eps
##    if not isinstance(v, G):
##        raise TypeError(_fehler3 + str(v))
##    if not isinstance(t, T1):
##        raise TypeError(_fehler3 + str(t))
##    if not isinstance(v.links, L1):
##        raise TypeError(_fehler3 + str(v.links))
##    if not isinstance(v.rechts, T1):
##        raise TypeError(_fehler3 + str(v.rechts))
##    if abs(v.links.internal) <= eps:
##        raise ValueError(_fehler4 + str(v.links))
##    return (v * t).to(_kmh)

# ---------------------------------------------------------
def Upromin(anz, t):
    """
    Anwendung: Berechnet Umdrehung/min.

    Aufruf: Upromin(anz, t)
    anz: Skalar
    t  : T1-Instanz (Zeit)
    mögliche Fehlermeldungen:
    - Operand hat keinen zulässigen Typ.
    - Operand hat den Wert Null."""
    
    global eps
    
    if not (isinstance(anz, int) or isinstance(anz, float)):
        raise TypeError(_fehler3 + str(anz))
    if not isinstance(t, T1):
        raise TypeError(_fehler3 + str(t))
    if abs(t.internal) <= eps:
        raise ValueError(_fehler4 + str(t))
    return G(N(anz), div, t.to(_minute)).to()

# ---------------------------------------------------------
def ymdToT1(l):
    """
    Anwendung: Erzeugt aus der Liste [zy, zmo, zd, zh, zmi, zs] eine T1-Instanz.

    Aufruf: ymdToT1(l)
    erlaubter Typ des Parameters:
    - Liste mit 6 Elementen [zy, zmo, zd, zh, zmi, zs]
    mögliche Fehlermeldung:
    - Operand hat keinen zulässigen Typ"""
    
    # lokale Hilfsvariable: zy, zmo, zd, zh, zmi, zs, zinternal, ll, anz
    
    if not isinstance(l, list):
        raise TypeError(_fehler3 + str(l))
    anz = 6
    if len(l) > anz:
        ll = l[0:anz]
    elif len(l) == anz:
        ll = l[:]
    if len(l) < anz:
        ll = [0 for x in range(anz)]
        for f in range(len(l)):
            ll[f] = l[f]
    zy, zmo, zd, zh, zmi, zs = ll
    zinternal  = zy  * _time1[_y]
    zinternal += zmo * _time1[_mon]
    zinternal += zd  * _time1[_d]
    zinternal += zh  * _time1[_h]
    zinternal += zmi * _time1[_minute]
    zinternal += zs  * _time1[_s]
    return T1(zinternal, _s)

# =========================================================
# externe Bezeichner für interne der Art _aa, ...

aa   = _aa;   aa2    = _aa2;    absK    = _absK;    am   = _am;   am2    = _am2;    ar      = _ar;      bbl   = _bbl; 
bp   = _bp;   C      = _C;      cc      = _cc;      ccm  = _ccm;  cental = _cental; cl      = _cl;      cm    = _cm;  
cm2  = _cm2;  cm3    = _cm3;    cwt     = _cwt;     d    = _d;    d2     = _d2;     dd      = _dd;      dl    = _dl; 
dm   = _dm;   dm2    = _dm2;    dm3     = _dm3;     dr   = _dr;   dz     = _dz;     F       = _F;       fl    = _fl; 
fm   = _fm;   fm2    = _fm2;    fs      = _fs;      fs2  = _fs2;  ft     = _ft;     ft2     = _ft2;     ft3   = _ft3; 
g    = _g;    gal    = _gal;    Gm      = _Gm;      Gm2  = _Gm2;  grain  = _grain;  Gt      = _Gt;      h     = _h; 
h2   = _h2;   ha     = _ha;     hl      = _hl;      inch = _inch; inch2  = _inch2;  inch3   = _inch3;   K     = _K; 
kg   = _kg;   km     = _km;     km2     = _km2;     km3  = _km3;  kt     = _kt;     lb      = _lb;      liter = _liter; 
lton = _lton; ly     = _ly;     m       = _m;       m2   = _m2;   m3     = _m3;     mg      = _mg;      mi    = _mi; 
mi2  = _mi2;  minute = _minute; minute2 = _minute2; ml   = _ml;   mm     = _mm;     Mm      = _Mm;      Mm2   = _Mm2; 
mm2  = _mm2;  mm3    = _mm3;    mon     = _mon;     mon2 = _mon2; ms     = _ms;     ms2     = _ms2;     Mt    = _Mt; 
my   = _my;   my2    = _my2;    myg     = _myg;     myl  = _myl;  mys    = _mys;    mys2    = _mys2;    ng    = _ng; 
nl   = _nl;   nm     = _nm;     nm2     = _nm2;     ns   = _ns;   ns2    = _ns2;    oz      = _oz;      pc    = _pc; 
pfd  = _pfd;  pg     = _pg;     pint    = _pint;    pl   = _pl;   pm     = _pm;     Pm      = _Pm;      pm2   = _pm2; 
Pm2  = _Pm2;  ps     = _ps;     ps2     = _ps2;     pt   = _pt;   qu     = _qu;     quarter = _quarter; R     = _R; 
s    = _s;    s2     = _s2;     sm      = _sm;      sm2  = _sm2;  sp     = _sp;     stone   = _stone;   t     = _t; 
Tm   = _Tm;   Tm2    = _Tm2;    ton     = _ton;     week = _week; week2  = _week2;  y       = _y;       y2    = _y2; 
yd   = _yd;   yd2    = _yd2;    ze      = _ze;      Zoll = _Zoll; Ztr    = _Ztr;    hkm     = _hkm;     ct    = _ct;
yd3  = _yd3;

# externe Bezeichner für interne der Art _format_e, ...
format_e     = __format_e
ueberschrift = __ueberschrift
str_aus      = _str_aus
repr_aus     = _repr_aus

# externe Bezeichner für interne der Art _mks, ...
mks = _mks
cgs = _cgs
kmh = _kmh
mph = _mph

# andere externe Bezeichner für interne
date    = _date
version = _version
modul   = _modul

# =========================================================
dmodule   = dir()                # Tupel  : Namensraum des Moduls
Lclass    = getClassNames()      # Liste  : enthält alle Klassen im Modul
Lfunction = getFunctionNames()   # Liste  : enthält alle globalen Methoden im Modul
L         = L1                   # Klasse : Alias für L1 (Länge)
T         = T1                   # Klasse : Alias für T1 (Zeit)
au        = allUnits             # Methode: Alias für allUnits
gcn       = getClassNames        # Methode: Alias für getClassNames
gfn       = getFunctionNames     # Methode: Alias für getFunctionNames
gi        = globalInfo           # Methode: Alias für globalInfo
mS        = meterS               # Methode: Alias für meterS (Geschwindigkeit)
mS2       = meterS2              # Methode: Alias für meterS2 (Beschleunigung)
sv        = setVar               # Methode: Alias für setVar
Nm        = joule

# V=L1/T1       B=L1/T2       F1=M*B=B*M   W=F1*L1=L1*F1  P=W/T1
# L1=V*T1=T1*V  L1=B*T2=T2*B  M=F1/B       B=F1/M         F1=W/L1  L1=W/F1  W=P*T1=T1*P
# V=B*T1=T1*B
#
# in L1: L1/T1 -->V; L1/T2 -->B;   L1*F1 -->W       L1/V --->T1   L1/B --->T2     L1*L1 -->L2 L1*L2 -->L3 L1*F1 -->W L1/L1 -->Skalar
# in L2: L2/L1 -->L1 L2*L1 -->L3   L2/L2 -->Skalar
# in L3: L3/L2 -->L1 L3/L1 --->L2  L3/L3 -->Skalar
# in T1: T1*V -->L1; T1*B -->V;    T1*P -->W        T1*T1 -->T2   T1/T1 -->Skalar
# in T2: T2*B -->L1; T2/T1 --->T1  T2/T2 -->Skalar
# in M:  M*B --> F1; M/M -->Skalar
# in V:  V*T1 -->L1; V/T1 --> B;   V/B --> T1;      V*F1 -->P     V/V -->Skalar
# in B:  B*M -->F1;  B*T2 -->L1;   B*T1 -->V;       B/B -->Skalar
# in F1: F1*L1 -->W; F1/B -->M;    F1/M -->B;       F1*V -->P     F1/F1 -->Skalar
# in W:  W/T1 -->P;  W/L1 -->F1;   W/F1 -->L1;      W/W -->Skalar
# in P:  P*T1 -->W;  P/F1 -->V     P/V -->F1        P/P -->Skalar


# *  | B  F1 G  L1 L2 L3 M  N  P  T1 T2 TT V  W  Sk
# ---+---------------------------------------------
# B  |       G           F1 B     V  L1          B
# F1 |       G  W           F1             P     F1
# G  | G  G  G  G  G  G  G  G  G  G  G  G  G  G  G
# L1 |    W  G  L2 L3       L1                   L1
# L2 |       G  L3          L2                   L2
# L3 |       G              L3                   L3
# M  | F1    G              M                    M
# N  | B  F1 G  L1 L2 L3 M  N  P  T1 T2 TT V  W  N
# P  |       G              P     W              P
# T1 | V     G              T1 W  T2       L1    T1
# T2 | L1    G              T2                   T2
# TT |       G              TT                   TT
# V  |    P  G              V     L1             V
# W  |       G              W                    W


# /  | B  F1 G  L1 L2 L3 M  N  P  T1 T2 TT V  W  Sk
# ---+---------------------------------------------
# B  | Sk    G              B                    B
# F1 | V  Sk G           B  F1                   F1
# G  | G  G  G  G  G  G  G  G  G  G  G  G  G  G  G
# L1 | T2    G  Sk          L1    V  B     T1    L1
# L2 |       G  L1 Sk       L2                   L2
# L3 |       G  L2 L1 Sk    L3                   L3
# M  |       G           Sk M                    M
# N  |       G              N                    N
# P  |    V  G              P  Sk          F1    P
# T1 |       G              T1    Sk             T1
# T2 |       G              T2    T1 Sk          T2
# TT |       G              TT          Sk       TT
# V  | T1    G              V     B        Sk    V
# W  |    L1 G  F1          W     P           Sk W
