__readme.txt

ZiP-Archiv: in ein geeignetes Verzeichnis auspacken

+ enth�lt den eigentlichen Vortrag context-latex.pdf
+ enth�lt alle PDF-Dateien f�r den Vortrag
+ enth�lt alle LuaLaTeX- und ConTeXt-Dateien (Mk IV):
-- mittels pdfLaTeX und context k�nnen alle PDF-Dateien erzeugt werden.
+ enth�lt eine Reihe von MS-DOS-Batch-Dateien
-- mit dem Aufruf alles k�nnen alle LuaLaTeX- und ConTeXt-Dateien compiliert werden.