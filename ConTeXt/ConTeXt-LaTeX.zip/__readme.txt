__readme.txt

ZiP-Archiv: in ein geeignetes Verzeichnis auspacken

+ enth�lt den eigentlichen Vortrag context-latex.pdf
+ enth�lt alle PDF-Dateien f�r den Vortrag
+ enth�lt alle LaTeX- und ConTeXt-Dateien (Mk II):
-- mittels pdfLaTeX und texexec (ConTeXt) k�nnen alle PDF-Dateien erzeugt werden.
+ enth�lt eine Reihe von MS-DOS-Batch-Dateien
-- mit dem Aufruf alles k�nnen alle LaTeX- und ConTeXt-Dateien compiliert werden.