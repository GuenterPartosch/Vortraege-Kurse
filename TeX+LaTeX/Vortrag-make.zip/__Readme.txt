﻿vortrag-make.pdf       eigentlicher Vortrag
Vortrag-make-alles.pdf zusätzlich mit allen eingebetteten PDF-Dateien
versuch1               Beispiel 1 (mit uebersetze.bat und Makefile)
versuch2               Beispiel 2 (mit uebersetze.bat und Makefile)
versuch3               Beispiel 3 (mit uebersetze.bat und Makefile)
versuch4               Beispiel 4 (mit uebersetze.bat und Makefile)
versuch5               Beispiel 5 (mit uebersetze.bat und Makefile)
versuch6               Beispiel 6 (mit uebersetze.bat und Makefile)
versuch7               Beispiel 7 (mit uebersetze.bat und Makefile)
zeige.bat              Batch-Datei zum Prozessieren eines Beispiels
CTAN.bib               Ergebnis einer Suche auf CTAN mit dem Topic "compilation"; bib-Datei
CTAN.pdf               Ergebnis einer Suche auf CTAN mit dem Topic "compilation"; PDF-Datei
CTAN.ris               Ergebnis einer Suche auf CTAN mit dem Topic "compilation"; RIS-Datei
CTAN.tex               Ergebnis einer Suche auf CTAN mit dem Topic "compilation"; LaTeX-Datei

