#!/usr/bin/python
# -*- coding: utf-8 -*-
# python24a.py
# Modul sympy, Gleichungssystem, solve
print(r"\documentclass[parskip=half,fontsize=11,paper=a4]{scrartcl}")
print(r"\usepackage{fontspec}")
print(r"\usepackage{amsmath}   % Mathematik à la AMS")
print(r"\usepackage{graphicx}  % Einbinden von Graphiken")

print(r"\begin{document}")

print(r"\section*{Python24a: sympy, Gleichungssystem}")

import sympy as sy         # symbolische Mathematik
h, z, e = sy.var('h z e')  # Sympy-Variablen initiieren

gls = [(z + h + e - 18),   # Gleichungssystem formulieren
(h - 6 - 2 * z),
(e - 6 - 3 * z)]

print(r"\subsection*{Gleichungssystem}")

print(r"\begin{align*}")   # Gleichungssystem ausgeben in align*-Umgebung
for f in range(len(gls)): 
    print(gls[f], r'&= 0\\')
print(r"\end{align*}")

print(r"\subsection*{Loesung}")

ergebnis = sy.solve(gls)  # Gleichungssystem lösen
for f in ergebnis:
    print(f, ":", ergebnis[f], r"\\")
print(r"\end{document}")
