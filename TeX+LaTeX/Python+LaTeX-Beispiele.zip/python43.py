#!/usr/bin/python
# -*- coding: utf-8 -*-
# python43.py
# Poore 2015 - PythonTeX: Reproducible Documents with PythonTeX
# Modul sympy, Ableitung, eq.replace, latex, Derivative
print(r"\documentclass[parskip=half, fontsize=11, paper=a4]{scrartcl}")
print(r"\usepackage[ngerman]{babel}")
print(r"\usepackage{fontspec}")
print(r"\usepackage{amsmath}")

print(r"\begin{document}")

print(r"\section*{Python43: Ableitung, replace}")

from sympy import *
x = symbols('x')                            # sympy-Variable

print(r'\begin{align*}')
for funk in [sin(x), sinh(x), csc(x)]:
    links  = Derivative(funk, x)               # Ableitung, formal
    rechts = Derivative(funk, x).doit()        # Ableitung ausführen
    zeile  = latex(links) + '&=' + latex(rechts) + r'\\'
    print(zeile.replace('d', r'\mathrm{d} '))  # d austauschen
print(r'\end{align*}')

print(r"\end{document}")
