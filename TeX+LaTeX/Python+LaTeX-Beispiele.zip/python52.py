#!/usr/bin/python
# -*- coding: utf-8 -*-
# python52.py
# nach https://kite.com/python/examples/665/scipy-compute-the-spearman-correlation
# + https://kite.com/python/examples/656/scipy-compute-the-pearson-correlation-coefficient
# Modul scipy.stats, Korrelationkoeffizienten nach Pearson und Spearman
print(r"\documentclass[parskip=half,fontsize=11,paper=a4]{scrartcl}")
print(r"\usepackage{fontspec}")
print(r"\usepackage{graphicx}")

print(r"\begin{document}")
print(r"\section*{Python52: Modul scipy.stats, Korrelationkoeffizienten}")

from scipy.stats import spearmanr, pearsonr
name = "rohdaten2.csv"; X = []; Y = []
daten = open(name, "r")
for zeile in daten:
    einezeile = zeile.rstrip(); werte = einezeile.split(",")
    X = X + [float(werte[0])]; Y = Y + [float(werte[1])]
daten.close()
sc, sp = spearmanr(X, Y); pc, pp = pearsonr(X, Y)

l2 = len(X) // 2

print(r"\begin{tabular}[t]{r|ll}")
print("$i$ & $X_i$ & $Y_i$", r"\\ \hline")
for f in range(l2):
    print(f, "&", X[f], "&", Y[f], r"\\")
print(r"\end{tabular}")

print(r"\begin{tabular}[t]{r|ll}")
print("$i$ & $X_i$ & $Y_i$", r"\\ \hline")
for f in range(l2, len(X)):
    print(f, "&", X[f], "&", Y[f], r"\\")
print(r"\end{tabular}")

print(r"\begin{tabular}{ll}")
print("Anzahl der Wertepaare &", len(X), r"\\")
print("Pearson-Korrelationskoeffizient &", pc, r"\\")
print("Spearman-Korrelationskoeffizient &", sc, r"\\")
print(r"\end{tabular}")

print(r"\end{document}")



