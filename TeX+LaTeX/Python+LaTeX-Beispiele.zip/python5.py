#!/usr/bin/python
# -*- coding: utf-8 -*-
# python5.py
# aus Mertz, Slough 2013 - A Gentle Introduction to PythonTeX
# Schleife, Tabelle, Zweierpotenzen
print(r"\documentclass[parskip=half,fontsize=11,paper=a4]{scrartcl}")
print(r"\usepackage{fontspec}")

print(r"\begin{document}")
print(r"\section*{Python5: Schleife, Tabelle, Zweierpotenzen}")

anfang, ende = 1, 40               # Grenzen
print(r"\begin{tabular}{r|r}")     # tabular-Umgebung in einer Schleife
print(r"$m$ & $2^m$ \\ \hline")    # Tabellenkopf
for m in range(anfang, ende + 1):  # Schleife 1-40
    print(m, "&", 2**m, r"\\")
print(r"\end{tabular}")

print(r"\end{document}")
