#!/usr/bin/python
# -*- coding: utf-8 -*-
# python14.py
# Modul sympy, unbestimmtes und bestimmtes Integral, doit, latex, Tabelle
print(r"\documentclass[parskip=half,fontsize=11,paper=a4]{scrartcl}")
print(r"\usepackage{fontspec}")
print(r"\usepackage[intlimits]{amsmath}        % Mathematik à la AMS")
print(r"\begin{document}")

print(r"\section*{Python14: Modul sympy, unbestimmtes und bestimmtes Integral, Tabelle}")

from sympy import *                        # smbolische Mathematik
var('x')                                   # symbolische Variable
phi = Symbol(r'\phi')                      # Symbol phi
pi  = Symbol(r'\pi')                       # Symbol pi
f   = x**3 + cos(x)**5                     # zu untersuchende erste Funktion 
g   = Integral(f, x)                       # unbestimmtes Integral dazu
gi  = Integral(f, (x, 0, pi/2))            # bestimmtes Integral dazu
hi  = Integral(exp(-phi**2), (phi, 0, oo)) # bestimmtes Integral für 2. Funktion

# align*-Umgebung wird erstellt
print(r"\begin{align*}")                   # Tabelle; LaTeX-Ausgabe mittels latex()
print(latex(g)  + "&=" + latex(g.doit()) + r"\\")
print(latex(gi) + "&=" + latex(gi.doit()) + r"\\")
print(            "&=" + latex(N(gi.doit())) + r"\\")
print(latex(hi) + "&=" + latex(hi.doit()) + r"\\")
print(            "&=" + latex(N(hi.doit())) + r"\\")
print(r"\end{align*}")

print(r"\end{document}")
