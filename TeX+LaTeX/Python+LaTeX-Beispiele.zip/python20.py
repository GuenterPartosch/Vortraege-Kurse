#!/usr/bin/python
# -*- coding: utf-8 -*-
# python20.py
# Tabellen, Schleife, $(2,3,4,5)^m$, $m*n$, $m+n$, $m^n$, session
print(r"\documentclass[parskip=half,fontsize=11,paper=a4]{scrartcl}")
print(r"\usepackage{fontspec}")

print(r"\begin{document}")
print(r"\section*{Python20: Tabellen, Schleife, $(2,3,4,5)^m$, $m*n$, $m+n$, $m^n$}")

print(r"\subsection*{Berechne $(2,3,4,5)^m$}")
# Aufbau einer Tabelle mittels einer tabular-Umgebung:
print(r"\begin{tabular}{r|rrrr}")                       # tabular-Umgebung, Anfang
print(r"$m$ & $2^m$ & $3^m$ & $4^m$ & $5^m$ \\ \hline") # Tabellenkopf
for m in range(31):                                     # eine Zeile
    print(m, "&", 2**m, "&", 3**m, "&", 4**m, "&", 5**m, r"\\")
print(r"\end{tabular}")                                 # tabular-Umgebung, Ende

print(r"\subsection*{Berechne $m*n$}")
# Aufbau einer Tabelle mittels einer tabular-Umgebung
print(r"\begin{tabular}{r|rrrrrrrrrr}")                 # tabular-Umgebung, Anfang
kopf = "$m*n$"                                          # Tabellenkopf
for m in range(10): 
    kopf += " & $" + str(m) + "$"
kopf += r"\\ \hline"
print(kopf)
for n in range(10):                                     # eine Zeile
    print(n)
    for m in range(10):
        print(" & ", n * m) 
    print(r"\\")
print(r"\end{tabular}")                                 # tabular-Umgebung, Ende

print(r"\subsection*{Berechne $m+n$}")
# Aufbau einer Tabelle mittels einer tabular-Umgebung
print(r"\begin{tabular}{r|rrrrrrrrrr}")                 # tabular-Umgebung, Anfang
kopf = "$m+n$"                                          # Tabellenkopf
for m in range(10): 
    kopf += " & $" + str(m) + "$"
kopf += r"\\ \hline"
print(kopf)
for n in range(10):  # eine Zeile
    print(n)
    for m in range(10):
        print(" & ", n + m)
    print(r"\\")
print(r"\end{tabular}")                                 # tabular-Umgebung, Ende

print(r"\subsection*{Berechne $m^n$}")
# Aufbau einer Tabelle mittels einer tabular-Umgebung
print(r"\begin{tabular}{r|rrrrrrrrrr}")                 # tabular-Umgebung, Anfang
kopf = "$m^n$"                                          # Tabellenkopf
for m in range(10): 
    kopf += " & $" + str(m) + "$"
kopf += r"\\ \hline"
print(kopf)
for n in range(10):                                     # eine Zeile
    print(n)
    for m in range(10):
        print(" & ", n ** m)
    print(r"\\")
print(r"\end{tabular}")                                 # tabular-Umgebung, Ende

print(r"\end{document}")
