#!/usr/bin/python
# -*- coding: utf-8 -*-
# python11
# aus Mertz, Slough 2013 - A Gentle Introduction to PythonTeX
print(r"\documentclass[parskip=half,fontsize=11,paper=a4]{scrartcl}")
print(r"\usepackage{fontspec}")

print(r"\begin{document}")
print(r"\section*{python11: sympy, def, Schleife, Primzahl}")

from sympy import prime              # symbolische Mathematik, hier Primzahlen
n = 500

def Primzahlen(n):                   # Annahme n >= 3
    for i in range(1, n):
        print(prime(i), ",")
    print("und", prime(n))

print("Die ersten", n, "Primzahlen sind:")
Primzahlen(n)
print(r"\end{document}")
