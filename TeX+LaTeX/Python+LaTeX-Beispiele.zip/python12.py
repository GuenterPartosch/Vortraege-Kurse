#!/usr/bin/python
# -*- coding: utf-8 -*-
# python12.py
# nach Mertz, Slough 2013 - A Gentle Introduction to PythonTeX
print(r"\documentclass[parskip=half,fontsize=11,paper=a4]{scrartcl}")
print(r"\usepackage{fontspec}")
print(r"\usepackage{amsmath}      % Mathematik à la AMS, hier für align*")

print(r"\begin{document}")
print(r"\section*{python12: sympy, Binome, Schleife, Tabelle}")

from sympy import *           # symbolische Mathematik
var("a, b")                   # sympy-Variable
Binome = []                   # Liste für Binomi-Ausdrücke vorbesetzt

for m in range(1, 10):
    Binome.append((a + b)**m) # Binomi-Ausdrücke erzeugen

print(r"\begin{align*}")      # Aufbau einer Tabelle mit einer align*-Umgebung
for expr in Binome:
    print(latex(expr), "&=", latex(expand(expr)), r"\\") 
print(r"\end{align*}")

print(r"\end{document}")

