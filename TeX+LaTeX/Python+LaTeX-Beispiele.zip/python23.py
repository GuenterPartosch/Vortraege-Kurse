#!/usr/bin/python
# -*- coding: utf-8 -*-
# python23.py
# nach Mertz, Slough 2013 - A Gentle Introduction to PythonTeX
# Modul sympy, Funktionen, Ableitungen, Integrale, derivative, latex, eval
print(r"\documentclass[parskip=half,fontsize=10,DIV=9,paper=a4]{scrartcl}")
print(r"\usepackage{fontspec}")
print(r"\usepackage{amsmath}      % Mathematik à la AMS")

print(r"\begin{document}")
print(r"\section*{Python23: sympy, Funktionen, Ableitungen, Integrale}")

from sympy import *                            # symbolische Mathematik
var('x')                                       # symbolische Variable x

# Liste von Funktionen, die in der Tabelle aufgeführt werden sollen
funktionen = ['acos(x)', 'acosh(x)', 'acot(x)', 'acoth(x)', 'asin(x)', 'asinh(x)', 
             'atan(x)', 'atanh(x)', 'cos(x)**2', 'cos(x)', 'cosh(x)', 'cot(x)**2', 
             'cot(x)', 'coth(x)', 'erf(x)', 'erfc(x)', 'exp(x)', 'gamma(x)','ln(x)',
             'sin(x)**2', 'sin(x)', 'sinh(x)', 'sqrt(x)', 'tan(x)**2', 'tan(x)', 
             'tanh(x)', 'csc(x)']

f          = "f(x) "
fableit    = "f'(x)"  
fint       = r"\int\!\!f(x)\,dx"  

print(r'\begin{align*}')                          # Tabelle
for funk in funktionen:                           # Schleife
    if funk in ['sin(x)**2']:                     # ggf. neue Seite
        print(r"\displaybreak")
    meineableit = 'Derivative(' + funk + ', x)'   # Ableitung
    meinint     = 'Integral(' + funk + ', x)'     # Integral
    print(latex(f),       r"&=", latex(eval(funk)),                    r'&')
    print(latex(fableit), r"&=", latex(eval(meineableit + '.doit()')), r"&")
    print(latex(fint),    r"&=", latex(eval(meinint + '.doit()')),     r'\\')
print(r'\end{align*}')

print(r"\end{document}")
