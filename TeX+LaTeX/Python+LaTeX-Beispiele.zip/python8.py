#!/usr/bin/python
# -*- coding: utf-8 -*-
# python8.py

import math

def tabelliereFunktion(anfang, ende, funct, label): # tabelliert eine Funktion
    print(r"\begin{tabular}[t]{r|r}")               # tabular-Umgebung
    print("$m$", "&", label, r"\\ \hline")          # Kopfzeile
    for m in range(anfang, ende + 1):               # Schleife
        print(m, "&", funct(m), r"\\") 
    print(r"\end{tabular}\hfill")

def fibo(n):                                        # rekursive Berechnung des n-ten Fibonacci-Werts
    a, b = 0, 1                                     # Rekursionsanfang
    for i in range(n):
        a, b = b, a + b                             # Rekursionsbedingung
    return a
    
def summe(n):                                       # summiert die Zahlen 0, ..., n
    return sum(range(n+1))

print(r"\documentclass[parskip=half,fontsize=11,paper=a4]{scrartcl}")
print(r"\usepackage{fontspec}")
print(r"\begin{document}")
print(r"\section*{python8: Modul math, def, Fibonacci, Funktionstabelle}")

tabelliereFunktion(1, 40, summe, r"$\sum_{i=1}^n i$")
tabelliereFunktion(1, 40, fibo, "$F_{m}$")
tabelliereFunktion(1, 25, math.factorial, "$m!$")

print(r"\end{document}")
