#!/usr/bin/python
# -*- coding: utf-8 -*-
# python51.py
# aus https://github.com/chasinginfinity/ml-from-scratch/blob/master/03%20Linear%20Regression%20in%202%20minutes/Linear%20Regression%20In%206%20lines.ipynb
# numpy, Grafik mit matplotlib, sklearn, Regression
print(r"\documentclass[parskip=half,fontsize=11,paper=a4]{scrartcl}")
print(r"\usepackage{fontspec}")
print(r"\usepackage{graphicx}")

print(r"\begin{document}")
print(r"\section*{Python51: numpy, Grafik mit matplotlib, sklearn, Regression}")
import matplotlib.pyplot as plt            # visualisieren
import pandas as pd                        # Daten einlesen
from sklearn.linear_model import LinearRegression

daten= pd.read_csv('rohdaten.csv')         # Daten einlesen
X    = daten.iloc[:, 0].values.reshape(-1, 1)  # in numpy-Liste umwandeln
Y    = daten.iloc[:, 1].values.reshape(-1, 1)  # + Abmessungen berechnen
linear_regressor = LinearRegression()      # Objekt generieren
linear_regressor.fit(X, Y)                 # lineare Regression
Y_pred = linear_regressor.predict(X)       # Predictions
plt.scatter(X, Y)                          # Punkte zeichnen
plt.plot(X, Y_pred, color='red')           # Regressionsgerade zeichnen
plt.grid(True)                             # Gitter zeichnen
plt.savefig("regression.pdf")              # als PDF abspeichern

print(r"\begin{center}")
print(r"\includegraphics[width=0.85\textwidth]{regression.pdf}")
print(r"\end{center}")

print(r"\end{document}")
