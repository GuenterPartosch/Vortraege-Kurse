#!/usr/bin/python
# -*- coding: utf-8 -*-
# python13.py
# nach Mertz, Slough 2013 - A Gentle Introduction to PythonTeX

print(r"\documentclass[parskip=half, fontsize=11, paper=a4]{scrartcl}")
print(r"\usepackage{fontspec}")
print(r"\usepackage{amsmath}     % Mathematik à la AMS")

print(r"\begin{document}")
print(r"\section*{python13: sympy, Funktionen, Integrale, Tabelle}")

##from math import *                                   # mathematische Funktionen
from sympy import *                                  # symbolische Mathematik
var("x")                                             # symbolische Variable

funktionen = [sin(x), cos(x), tan(x), cot(x)]        # zu betrachtende Funktionen

print(r"\begin{align*}")                             # Tabelle mit align*
for f in funktionen:
    i = Integral(f, x)                               # Integral: Integral, formal
    print(latex(i) + "&=" + latex(i.doit()) + r"\\") # .doit():  ausgewertet
print(r"\end{align*}")

print(r"\end{document}")
