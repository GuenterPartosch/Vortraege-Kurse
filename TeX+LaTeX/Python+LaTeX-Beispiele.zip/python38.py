#!/usr/bin/python
# -*- coding: utf-8 -*-
# python38.py
# aus Mertz, Slough 2013 - A Gentle Introduction to PythonTeX
# pyblock, Grafik mit pylab, Graph einer Funktion
print(r"\documentclass[parskip=half,fontsize=11,paper=a4]{scrartcl}")
print(r"\usepackage{fontspec}")
print(r"\usepackage{graphicx}")

print(r"\begin{document}")
print(r"\section*{Python38: Grafik mit pylab, Graph einer Funktion}")

from pylab import *

def f(t):                                       # (1) Funktion f(t) definieren
    return cos(2 * pi * t) * exp(-t)

t = linspace(0, 5, 500)                         # (2) auszugebende Punkte berechnen
y = f(t)

clf()                                           # (3) Anfang: leere Grafik (5 x 3 Zoll)
figure(figsize=(5, 3))

rc("text", usetex=True)                         # (4) TeX-Schriften benutzen

#                                               # (5) eigentliche Grafik (+ Anmerkungen)
plot(t, y)                                      # Funktion ausgeben
title("exponentiell abklingende Schwingung")    # Kopftitel
text(3, 0.15, r"$y = \cos(2 \pi t) e^{-t}$")    # Text bei (3, 0.15)
xlabel("Zeit [s]")                              # Beschriftung der x-Achse
ylabel("Spannung [mV]")                         # Beschriftung der y-Achse

savefig("meinegrafik.pdf", bbox_inches="tight") # (6) Grafik als PDF-Datei speichern

print(r"\begin{center}")                        # (7) Grafik im LaTeX-Dokument ausgeben
print(r"\includegraphics[width=0.85\textwidth]{meinegrafik.pdf}")
print(r"\end{center}")

print(r"\end{document}")
