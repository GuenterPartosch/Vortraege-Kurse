#!/usr/bin/python
# -*- coding: utf-8 -*-
# python16.tex
# Poore 2017 - PythonTeX Gallery
# Modul sympy, bestimmtes Mehrfach-Integral, latex, doit
print(r"\documentclass[parskip=half,fontsize=11,paper=a4]{scrartcl}")
print(r"\usepackage{fontspec}")
print(r"\usepackage[intlimits]{amsmath}   % Mathematik à la AMS")

print(r"\begin{document}")
print(r"\section*{Python16: sympy, bestimmtes Mehrfach-Integral}")

from sympy import *            # symbolische Mathematik
x, y, z = symbols('x, y, z')   # sympy-Variable
f       = Symbol('f(x, y, z)') # sympy-Variable

# Integrationsgrenzen
x_ug  = 0
x_og  = 2
y_ug  = 0
y_og  = 3
z_ug  = 0
z_og  = 4

print(r'\begin{align*}')
links  = Integral(f, (x, x_ug, x_og), (y, y_ug, y_og), (z, z_ug, z_og))

f      = x * y + y * sin(z) + cos(x + y)
rechts = Integral(f, (x, x_ug, x_og), (y, y_ug, y_og), (z, z_ug, z_og))
print(latex(links) + '&=' + latex(rechts) + r'\\')

# Schritt 1: Integral mit bestimmten Grenzen für z
rechts = Integral(Integral(f, (z, z_ug, z_og)).doit(), (x, x_ug, x_og), 
         (y, y_ug, y_og))
print('&=' + latex(rechts) + r'\\')

# Schritt 2: Integral mit bestimmten Grenzen für y
rechts = Integral(Integral(f, (z, z_ug, z_og), (y, y_ug, y_og)).doit(), 
         (x, x_ug, x_og))
print('&=' + latex(rechts) + r'\\')

# Schritt 3: Integral mit bestimmten Grenzen für x (Gesamtintegral)
rechts = Integral(f, (z, z_ug, z_og), (y, y_ug, y_og), 
         (x, x_ug, x_og)).doit()
print('&=' + latex(rechts) + r'\\')

print('&=' + latex(N(rechts)) + r'\\')
print(r'\end{align*}')

print(r"\end{document}")
