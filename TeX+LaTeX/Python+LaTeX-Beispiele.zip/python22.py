#!/usr/bin/python
# -*- coding: utf-8 -*-
# python22.tex
# pyblock, Modul pyx, Graph einer Funktion
print(r"\documentclass[parskip=half,fontsize=11,paper=a4]{scrartcl}")
print(r"\usepackage{fontspec}")
print(r"\usepackage{graphicx}    % Einbinden von Graphiken")
print(r"\usepackage[english, ngerman]{babel}")

print(r"\begin{document}")

print(r"\section*{Python22: Modul pyx, Graph einer Funktion}")

from pyx import *                           # PyX importieren

g = graph.graphxy(width=10)                 # neue Grafik, Größe der Grafik
g.plot(graph.data.function("y(x) = sin(x) / x", min=-20, max=20))
g.writePDFfile("func1")                     # Grafik als PDF-Datei

g = graph.graphxy(width=10)                 # Größe der Grafik
g.plot(graph.data.function("y(x) = cos(x) / x", min=-20, max=20))
g.writePDFfile("func2")                     # Grafik als PDF-Datei

print(r"\begin{figure}[!ht]")
print(r"\centering")
print(r"\includegraphics[width=0.6\textwidth]{func1}")
print(r"\caption{$y(x)=\frac{\sin(x)}{x}$}")
print(r"\end{figure}")

print(r"\begin{figure}[!ht]")
print(r"\centering")
print(r"\includegraphics[width=0.6\textwidth]{func2}")
print(r"\caption{$y(x)=\frac{\cos(x)}{x}$}")
print(r"\end{figure}")
print(r"\end{document}")
